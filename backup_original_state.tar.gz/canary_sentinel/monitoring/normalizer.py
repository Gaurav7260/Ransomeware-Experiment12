"""Normalizes filesystem events from Watchdog into uniform NormalizedEvent objects."""

import os
import time
import uuid
from pathlib import Path
from typing import Dict, Optional, Tuple

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.core.utils import (
    calculate_file_entropy,
    get_iso_timestamp,
)
from canary_sentinel.storage.models import NormalizedEvent


class EventNormalizer:
    """Processes raw filesystem events, deduplicates them, and extracts security features."""

    def __init__(
        self,
        sandbox: SandboxManager,
        canary_manager: CanaryManager,
        debounce_ms: int = 50,
    ):
        self.sandbox = sandbox
        self.canary_manager = canary_manager
        self.debounce_seconds = debounce_ms / 1000.0
        # Map of (relative_path, event_type) -> last_seen_timestamp
        self._last_event_times: Dict[Tuple[str, str], float] = {}

    def is_duplicate(self, path: str, event_type: str, now: float) -> bool:
        """Check if an event is a duplicate within the debounce window."""
        key = (path, event_type)
        last_time = self._last_event_times.get(key)
        if last_time is not None and (now - last_time) < self.debounce_seconds:
            return True
        self._last_event_times[key] = now

        # Housekeeping: prune old entries every 500 keys to prevent memory leak
        if len(self._last_event_times) > 500:
            threshold = now - 5.0
            self._last_event_times = {
                k: v for k, v in self._last_event_times.items() if v >= threshold
            }

        return False

    def normalize(
        self,
        event_type: str,
        src_path: str,
        dest_path: Optional[str] = None,
        scenario_id: Optional[str] = None,
        process_id: Optional[int] = None,
        process_name: Optional[str] = None,
    ) -> Optional[NormalizedEvent]:
        """Convert a raw event into a NormalizedEvent if valid and within sandbox.

        Args:
            event_type: "CREATE", "MODIFY", "DELETE", "MOVE"
            src_path: Source file path
            dest_path: Destination path (for MOVE)
            scenario_id: Optional active simulation scenario ID
            process_id: Optional process ID
            process_name: Optional process name

        Returns:
            NormalizedEvent or None if out of bounds or duplicate.
        """
        now = time.time()

        # Validate that the path is within the sandbox
        try:
            effective_path = dest_path if (event_type == "MOVE" and dest_path) else src_path
            abs_path = self.sandbox.validate_path(effective_path)
            rel_path = self.sandbox.relative_to_sandbox(abs_path)
            norm_path = Path(rel_path).as_posix()
        except Exception:
            # Ignore operations outside the sandbox
            return None

        # Check debouncing
        if self.is_duplicate(norm_path, event_type, now):
            return None

        # Extract features
        extension = abs_path.suffix.lower() if abs_path.suffix else ""
        is_canary = self.canary_manager.is_canary(norm_path)

        size_bytes = 0
        entropy = 0.0
        if event_type in ("CREATE", "MODIFY") and abs_path.exists() and abs_path.is_file():
            try:
                size_bytes = abs_path.stat().st_size
                entropy = calculate_file_entropy(abs_path)
            except (OSError, PermissionError):
                pass

        rel_src = None
        if event_type == "MOVE" and dest_path:
            try:
                rel_src = self.sandbox.relative_to_sandbox(src_path)
            except Exception:
                rel_src = src_path

        return NormalizedEvent(
            event_id=str(uuid.uuid4()),
            timestamp=now,
            iso_timestamp=get_iso_timestamp(now),
            event_type=event_type,
            path=norm_path,
            src_path=rel_src,
            extension=extension,
            is_canary=is_canary,
            size_bytes=size_bytes,
            entropy=entropy,
            process_id=process_id or os.getpid(),
            process_name=process_name or "python",
            scenario_id=scenario_id,
        )

