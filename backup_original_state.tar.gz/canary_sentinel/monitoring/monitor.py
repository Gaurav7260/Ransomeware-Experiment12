"""Filesystem monitor using Watchdog."""

import logging
import threading
from typing import Callable, List, Optional

from watchdog.events import (
    DirCreatedEvent,
    DirDeletedEvent,
    DirModifiedEvent,
    DirMovedEvent,
    FileCreatedEvent,
    FileDeletedEvent,
    FileModifiedEvent,
    FileMovedEvent,
    FileSystemEvent,
    FileSystemEventHandler,
)
from watchdog.observers import Observer

from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.storage.models import NormalizedEvent

logger = logging.getLogger(__name__)


class SentinelEventHandler(FileSystemEventHandler):
    """Handles raw watchdog events and feeds them to the normalizer."""

    def __init__(
        self,
        normalizer: EventNormalizer,
        callback: Callable[[NormalizedEvent], None],
        get_scenario_id: Callable[[], Optional[str]],
    ):
        super().__init__()
        self.normalizer = normalizer
        self.callback = callback
        self.get_scenario_id = get_scenario_id

    def _process_event(
        self,
        event_type: str,
        src_path: str,
        dest_path: Optional[str] = None,
    ) -> None:
        scenario_id = self.get_scenario_id()
        normalized = self.normalizer.normalize(
            event_type=event_type,
            src_path=src_path,
            dest_path=dest_path,
            scenario_id=scenario_id,
        )
        if normalized:
            try:
                self.callback(normalized)
            except Exception as e:
                logger.error(f"Error executing event callback: {e}")

    def on_created(self, event: FileSystemEvent) -> None:
        if isinstance(event, DirCreatedEvent):
            return
        self._process_event("CREATE", event.src_path)

    def on_modified(self, event: FileSystemEvent) -> None:
        if isinstance(event, DirModifiedEvent):
            return
        self._process_event("MODIFY", event.src_path)

    def on_deleted(self, event: FileSystemEvent) -> None:
        if isinstance(event, DirDeletedEvent):
            return
        self._process_event("DELETE", event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        if isinstance(event, DirMovedEvent):
            return
        dest_path = getattr(event, "dest_path", None)
        self._process_event("MOVE", event.src_path, dest_path=dest_path)


class FilesystemMonitor:
    """Monitors sandbox filesystem activity using watchdog."""

    def __init__(
        self,
        sandbox: SandboxManager,
        normalizer: EventNormalizer,
    ):
        self.sandbox = sandbox
        self.normalizer = normalizer
        self._callbacks: List[Callable[[NormalizedEvent], None]] = []
        self._observer: Optional[Observer] = None
        self._is_running = False
        self._active_scenario_id: Optional[str] = None
        self._lock = threading.Lock()

    def set_active_scenario_id(self, scenario_id: Optional[str]) -> None:
        """Set current simulation scenario ID to associate with captured events."""
        with self._lock:
            self._active_scenario_id = scenario_id

    def get_active_scenario_id(self) -> Optional[str]:
        with self._lock:
            return self._active_scenario_id

    def register_callback(self, callback: Callable[[NormalizedEvent], None]) -> None:
        """Register a callback to receive normalized events."""
        with self._lock:
            if callback not in self._callbacks:
                self._callbacks.append(callback)

    def unregister_callback(self, callback: Callable[[NormalizedEvent], None]) -> None:
        """Unregister an event callback."""
        with self._lock:
            if callback in self._callbacks:
                self._callbacks.remove(callback)

    def _dispatch_event(self, event: NormalizedEvent) -> None:
        with self._lock:
            callbacks = list(self._callbacks)
        for cb in callbacks:
            try:
                cb(event)
            except Exception as e:
                logger.error(f"Callback dispatch error: {e}")

    @property
    def is_running(self) -> bool:
        return self._is_running

    def start(self) -> None:
        """Start watchdog observer on the sandbox directory."""
        with self._lock:
            if self._is_running:
                return

            event_handler = SentinelEventHandler(
                normalizer=self.normalizer,
                callback=self._dispatch_event,
                get_scenario_id=self.get_active_scenario_id,
            )

            self._observer = Observer()
            self._observer.schedule(
                event_handler,
                str(self.sandbox.sandbox_path),
                recursive=True,
            )
            self._observer.start()
            self._is_running = True
            logger.info(f"Started FilesystemMonitor on {self.sandbox.sandbox_path}")

    def stop(self) -> None:
        """Stop watchdog observer cleanly."""
        with self._lock:
            if not self._is_running or not self._observer:
                return

            try:
                self._observer.stop()
                self._observer.join(timeout=2.0)
            except Exception as e:
                logger.warning(f"Error stopping observer: {e}")
            finally:
                self._observer = None
                self._is_running = False
                logger.info("Stopped FilesystemMonitor")

