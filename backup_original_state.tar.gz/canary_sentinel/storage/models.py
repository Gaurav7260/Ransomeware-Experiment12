"""Data models for CanarySentinel entities."""

import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class NormalizedEvent:
    event_id: str
    timestamp: float
    iso_timestamp: str
    event_type: str  # "CREATE", "MODIFY", "DELETE", "MOVE"
    path: str  # Relative to sandbox
    src_path: Optional[str] = None
    extension: str = ""
    is_canary: bool = False
    size_bytes: int = 0
    entropy: float = 0.0
    process_id: Optional[int] = None
    process_name: Optional[str] = None
    scenario_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AlertRecord:
    alert_id: str
    timestamp: float
    iso_timestamp: str
    detector_config: str  # "baseline", "canary_only", "hybrid"
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    risk_score: int  # 0 - 100
    confidence: float  # 0.0 - 1.0
    triggering_event_id: str
    triggering_event_summary: str
    supporting_event_ids: List[str] = field(default_factory=list)
    explanation: str = ""
    response_status: str = "NONE"  # "NONE", "BLOCKED", "PREVENTED"
    scenario_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["supporting_event_ids"] = json.dumps(self.supporting_event_ids)
        return d


@dataclass
class ScenarioRecord:
    scenario_id: str
    scenario_name: str
    scenario_type: str  # "benign", "suspicious"
    detector_config: str  # "baseline", "canary_only", "hybrid"
    start_time: float
    end_time: float
    duration_ms: float
    planned_ops: int
    executed_ops: int
    prevented_ops: int
    files_damaged: int  # User files modified before detection
    detected: bool
    detection_latency_ms: Optional[float] = None
    response_triggered: bool = False
    alert_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CanaryRecord:
    canary_id: str
    relative_path: str
    filename: str
    file_hash: str
    file_size: int
    created_at: str
    status: str = "ACTIVE"  # "ACTIVE", "MODIFIED", "DELETED", "MISSING"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SystemMetricsRecord:
    timestamp: float
    cpu_percent: float
    memory_mb: float
    scenario_id: Optional[str] = None
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

