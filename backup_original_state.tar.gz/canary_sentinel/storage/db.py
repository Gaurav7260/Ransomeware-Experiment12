"""SQLite storage layer for CanarySentinel."""

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from canary_sentinel.storage.models import (
    AlertRecord,
    CanaryRecord,
    NormalizedEvent,
    ScenarioRecord,
    SystemMetricsRecord,
)


class Database:
    """Thread-safe SQLite persistent storage manager."""

    def __init__(self, db_path: Union[str, Path] = "./canary_sentinel.db"):
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.init_schema()

    def get_connection(self) -> sqlite3.Connection:
        """Create and configure a SQLite connection."""
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=10.0,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA busy_timeout = 5000;")
        return conn

    def init_schema(self) -> None:
        """Initialize database tables and indexes."""
        with self._lock, self.get_connection() as conn:
            cursor = conn.cursor()

            # Normalized Events table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    timestamp REAL NOT NULL,
                    iso_timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    path TEXT NOT NULL,
                    src_path TEXT,
                    extension TEXT,
                    is_canary INTEGER NOT NULL,
                    size_bytes INTEGER NOT NULL,
                    entropy REAL NOT NULL,
                    process_id INTEGER,
                    process_name TEXT,
                    scenario_id TEXT
                );
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(timestamp);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_canary ON events(is_canary);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_scenario ON events(scenario_id);")

            # Alerts table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS alerts (
                    alert_id TEXT PRIMARY KEY,
                    timestamp REAL NOT NULL,
                    iso_timestamp TEXT NOT NULL,
                    detector_config TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    risk_score INTEGER NOT NULL,
                    confidence REAL NOT NULL,
                    triggering_event_id TEXT NOT NULL,
                    triggering_event_summary TEXT NOT NULL,
                    supporting_event_ids TEXT NOT NULL,
                    explanation TEXT NOT NULL,
                    response_status TEXT NOT NULL,
                    scenario_id TEXT
                );
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(timestamp);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_detector ON alerts(detector_config);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_scenario ON alerts(scenario_id);")

            # Scenarios table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS scenarios (
                    scenario_id TEXT PRIMARY KEY,
                    scenario_name TEXT NOT NULL,
                    scenario_type TEXT NOT NULL,
                    detector_config TEXT NOT NULL,
                    start_time REAL NOT NULL,
                    end_time REAL NOT NULL,
                    duration_ms REAL NOT NULL,
                    planned_ops INTEGER NOT NULL,
                    executed_ops INTEGER NOT NULL,
                    prevented_ops INTEGER NOT NULL,
                    files_damaged INTEGER NOT NULL,
                    detected INTEGER NOT NULL,
                    detection_latency_ms REAL,
                    response_triggered INTEGER NOT NULL,
                    alert_id TEXT
                );
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_scenarios_name ON scenarios(scenario_name);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_scenarios_detector ON scenarios(detector_config);")

            # Canaries table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS canaries (
                    canary_id TEXT PRIMARY KEY,
                    relative_path TEXT NOT NULL UNIQUE,
                    filename TEXT NOT NULL,
                    file_hash TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL
                );
                """
            )

            # System Metrics table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS system_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    cpu_percent REAL NOT NULL,
                    memory_mb REAL NOT NULL,
                    scenario_id TEXT
                );
                """
            )
            conn.commit()

    def save_event(self, event: NormalizedEvent) -> None:
        """Insert or replace a normalized event."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO events (
                    event_id, timestamp, iso_timestamp, event_type, path,
                    src_path, extension, is_canary, size_bytes, entropy,
                    process_id, process_name, scenario_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.event_id,
                    event.timestamp,
                    event.iso_timestamp,
                    event.event_type,
                    event.path,
                    event.src_path,
                    event.extension,
                    1 if event.is_canary else 0,
                    event.size_bytes,
                    event.entropy,
                    event.process_id,
                    event.process_name,
                    event.scenario_id,
                ),
            )
            conn.commit()

    def save_alert(self, alert: AlertRecord) -> None:
        """Insert or replace an alert record."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO alerts (
                    alert_id, timestamp, iso_timestamp, detector_config,
                    severity, risk_score, confidence, triggering_event_id,
                    triggering_event_summary, supporting_event_ids,
                    explanation, response_status, scenario_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    alert.alert_id,
                    alert.timestamp,
                    alert.iso_timestamp,
                    alert.detector_config,
                    alert.severity,
                    alert.risk_score,
                    alert.confidence,
                    alert.triggering_event_id,
                    alert.triggering_event_summary,
                    json.dumps(alert.supporting_event_ids),
                    alert.explanation,
                    alert.response_status,
                    alert.scenario_id,
                ),
            )
            conn.commit()

    def save_scenario(self, scenario: ScenarioRecord) -> None:
        """Insert or replace a scenario experiment record."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO scenarios (
                    scenario_id, scenario_name, scenario_type, detector_config,
                    start_time, end_time, duration_ms, planned_ops,
                    executed_ops, prevented_ops, files_damaged, detected,
                    detection_latency_ms, response_triggered, alert_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    scenario.scenario_id,
                    scenario.scenario_name,
                    scenario.scenario_type,
                    scenario.detector_config,
                    scenario.start_time,
                    scenario.end_time,
                    scenario.duration_ms,
                    scenario.planned_ops,
                    scenario.executed_ops,
                    scenario.prevented_ops,
                    scenario.files_damaged,
                    1 if scenario.detected else 0,
                    scenario.detection_latency_ms,
                    1 if scenario.response_triggered else 0,
                    scenario.alert_id,
                ),
            )
            conn.commit()

    def save_canary(self, canary: CanaryRecord) -> None:
        """Insert or replace a canary decoy file record."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO canaries (
                    canary_id, relative_path, filename, file_hash,
                    file_size, created_at, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    canary.canary_id,
                    canary.relative_path,
                    canary.filename,
                    canary.file_hash,
                    canary.file_size,
                    canary.created_at,
                    canary.status,
                ),
            )
            conn.commit()

    def update_canary_status(self, canary_id: str, status: str) -> None:
        """Update status of a canary file."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                "UPDATE canaries SET status = ? WHERE canary_id = ?",
                (status, canary_id),
            )
            conn.commit()

    def clear_canaries(self) -> None:
        """Clear canary registry table."""
        with self._lock, self.get_connection() as conn:
            conn.execute("DELETE FROM canaries")
            conn.commit()

    def save_system_metrics(self, metrics: SystemMetricsRecord) -> None:
        """Record system CPU and memory resource sample."""
        with self._lock, self.get_connection() as conn:
            conn.execute(
                """
                INSERT INTO system_metrics (timestamp, cpu_percent, memory_mb, scenario_id)
                VALUES (?, ?, ?, ?)
                """,
                (
                    metrics.timestamp,
                    metrics.cpu_percent,
                    metrics.memory_mb,
                    metrics.scenario_id,
                ),
            )
            conn.commit()

    def get_events(
        self,
        limit: int = 100,
        scenario_id: Optional[str] = None,
        is_canary: Optional[bool] = None,
    ) -> List[NormalizedEvent]:
        """Query normalized events."""
        query = "SELECT * FROM events"
        params: List[Any] = []
        conditions: List[str] = []

        if scenario_id:
            conditions.append("scenario_id = ?")
            params.append(scenario_id)
        if is_canary is not None:
            conditions.append("is_canary = ?")
            params.append(1 if is_canary else 0)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            events = []
            for r in rows:
                events.append(
                    NormalizedEvent(
                        event_id=r["event_id"],
                        timestamp=r["timestamp"],
                        iso_timestamp=r["iso_timestamp"],
                        event_type=r["event_type"],
                        path=r["path"],
                        src_path=r["src_path"],
                        extension=r["extension"],
                        is_canary=bool(r["is_canary"]),
                        size_bytes=r["size_bytes"],
                        entropy=r["entropy"],
                        process_id=r["process_id"],
                        process_name=r["process_name"],
                        scenario_id=r["scenario_id"],
                    )
                )
            return events

    def get_alerts(
        self,
        limit: int = 100,
        detector_config: Optional[str] = None,
        scenario_id: Optional[str] = None,
    ) -> List[AlertRecord]:
        """Query alert records."""
        query = "SELECT * FROM alerts"
        params: List[Any] = []
        conditions: List[str] = []

        if detector_config:
            conditions.append("detector_config = ?")
            params.append(detector_config)
        if scenario_id:
            conditions.append("scenario_id = ?")
            params.append(scenario_id)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(query, params).fetchall()
            alerts = []
            for r in rows:
                supp_ids = []
                try:
                    supp_ids = json.loads(r["supporting_event_ids"])
                except Exception:
                    pass
                alerts.append(
                    AlertRecord(
                        alert_id=r["alert_id"],
                        timestamp=r["timestamp"],
                        iso_timestamp=r["iso_timestamp"],
                        detector_config=r["detector_config"],
                        severity=r["severity"],
                        risk_score=r["risk_score"],
                        confidence=r["confidence"],
                        triggering_event_id=r["triggering_event_id"],
                        triggering_event_summary=r["triggering_event_summary"],
                        supporting_event_ids=supp_ids,
                        explanation=r["explanation"],
                        response_status=r["response_status"],
                        scenario_id=r["scenario_id"],
                    )
                )
            return alerts

    def get_scenarios(self, limit: int = 200) -> List[ScenarioRecord]:
        """Query scenario records."""
        with self.get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM scenarios ORDER BY start_time DESC LIMIT ?",
                (limit,),
            ).fetchall()
            scenarios = []
            for r in rows:
                scenarios.append(
                    ScenarioRecord(
                        scenario_id=r["scenario_id"],
                        scenario_name=r["scenario_name"],
                        scenario_type=r["scenario_type"],
                        detector_config=r["detector_config"],
                        start_time=r["start_time"],
                        end_time=r["end_time"],
                        duration_ms=r["duration_ms"],
                        planned_ops=r["planned_ops"],
                        executed_ops=r["executed_ops"],
                        prevented_ops=r["prevented_ops"],
                        files_damaged=r["files_damaged"],
                        detected=bool(r["detected"]),
                        detection_latency_ms=r["detection_latency_ms"],
                        response_triggered=bool(r["response_triggered"]),
                        alert_id=r["alert_id"],
                    )
                )
            return scenarios

    def get_canaries(self) -> List[CanaryRecord]:
        """Query all registered canaries."""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM canaries ORDER BY relative_path ASC").fetchall()
            canaries = []
            for r in rows:
                canaries.append(
                    CanaryRecord(
                        canary_id=r["canary_id"],
                        relative_path=r["relative_path"],
                        filename=r["filename"],
                        file_hash=r["file_hash"],
                        file_size=r["file_size"],
                        created_at=r["created_at"],
                        status=r["status"],
                    )
                )
            return canaries

    def get_system_metrics(self, limit: int = 200) -> List[SystemMetricsRecord]:
        """Query system CPU and memory metrics."""
        with self.get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM system_metrics ORDER BY timestamp DESC LIMIT ?",
                (limit,),
            ).fetchall()
            metrics = []
            for r in rows:
                metrics.append(
                    SystemMetricsRecord(
                        id=r["id"],
                        timestamp=r["timestamp"],
                        cpu_percent=r["cpu_percent"],
                        memory_mb=r["memory_mb"],
                        scenario_id=r["scenario_id"],
                    )
                )
            return metrics

    def reset_db(self) -> None:
        """Clear all tables."""
        with self._lock, self.get_connection() as conn:
            conn.execute("DELETE FROM events;")
            conn.execute("DELETE FROM alerts;")
            conn.execute("DELETE FROM scenarios;")
            conn.execute("DELETE FROM canaries;")
            conn.execute("DELETE FROM system_metrics;")
            conn.commit()

