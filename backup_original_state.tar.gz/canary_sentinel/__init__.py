"""CanarySentinel: Canary-based endpoint ransomware detection and behavioral analysis system."""

__version__ = "1.0.0"

