"""Harmless activity simulator for CanarySentinel."""

import logging
import os
import shutil
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.simulation.scenarios import ScenarioDefinition, ScenarioHelper

logger = logging.getLogger(__name__)


@dataclass
class SimulationResult:
    scenario_id: str
    scenario_name: str
    category: str
    planned_ops: int
    executed_ops: int
    prevented_ops: int
    files_damaged: int
    response_triggered: bool
    start_time: float
    end_time: float
    duration_ms: float


class ActivitySimulator:
    """Safely executes benign and harmless suspicious-looking filesystem scenarios."""

    SCENARIO_CATALOG: Dict[str, ScenarioDefinition] = {
        "normal_file_editing": ScenarioDefinition(
            id="normal_file_editing",
            name="Normal File Editing",
            category="benign",
            description="Simulates standard sporadic user modifications to documents at a slow pace.",
            expected_baseline_alert=False,
            expected_canary_alert=False,
            expected_hybrid_alert=False,
            planned_operations=5,
        ),
        "bulk_copying": ScenarioDefinition(
            id="bulk_copying",
            name="Bulk Copying",
            category="benign",
            description="Duplicates a set of files to a backup directory with modest delays.",
            expected_baseline_alert=False,
            expected_canary_alert=False,
            expected_hybrid_alert=False,
            planned_operations=6,
        ),
        "bulk_renaming": ScenarioDefinition(
            id="bulk_renaming",
            name="Bulk Renaming",
            category="benign",
            description="Renames files with standard prefixes without altering extensions.",
            expected_baseline_alert=False,
            expected_canary_alert=False,
            expected_hybrid_alert=False,
            planned_operations=6,
        ),
        "canary_touch_benign": ScenarioDefinition(
            id="canary_touch_benign",
            name="Canary Touch Without Suspicious Follow-up",
            category="benign",
            description="Simulates an innocent indexer/scanner opening a canary file, followed by no mass activity.",
            expected_baseline_alert=False,
            expected_canary_alert=True,  # Canary-only creates false positive here!
            expected_hybrid_alert=False,  # Hybrid successfully filters this out!
            planned_operations=4,
        ),
        "canary_plus_rapid_bulk": ScenarioDefinition(
            id="canary_plus_rapid_bulk",
            name="Canary Touch + Rapid Bulk Modifications",
            category="suspicious",
            description="Touches a canary decoy file, then rapidly overwrites multiple user files with high-entropy bytes.",
            expected_baseline_alert=True,
            expected_canary_alert=True,
            expected_hybrid_alert=True,
            planned_operations=12,
        ),
        "rapid_bulk_without_canary": ScenarioDefinition(
            id="rapid_bulk_without_canary",
            name="Rapid Bulk Modifications Without Canary",
            category="suspicious",
            description="Rapidly modifies user files across folders without touching canary files.",
            expected_baseline_alert=True,
            expected_canary_alert=False,  # Canary-only misses this completely!
            expected_hybrid_alert=False,
            planned_operations=10,
        ),
    }

    def __init__(
        self,
        sandbox: SandboxManager,
        canary_manager: CanaryManager,
        response_manager: SimulatedResponseManager,
    ):
        self.sandbox = sandbox
        self.canary_manager = canary_manager
        self.response_manager = response_manager
        self.helper = ScenarioHelper(sandbox)

    def run_scenario(
        self,
        scenario_key: str,
        scenario_id: Optional[str] = None,
        on_op_callback: Optional[Callable[[int, int], None]] = None,
    ) -> SimulationResult:
        """Execute a selected scenario within the sandbox."""
        if scenario_key not in self.SCENARIO_CATALOG:
            raise ValueError(f"Unknown scenario: {scenario_key}")

        defn = self.SCENARIO_CATALOG[scenario_key]
        sid = scenario_id or f"{scenario_key}_{uuid.uuid4().hex[:8]}"

        self.response_manager.reset()
        start_time = time.time()

        runner_map: Dict[str, Callable[[str, Callable], SimulationResult]] = {
            "normal_file_editing": self._scenario_normal_editing,
            "bulk_copying": self._scenario_bulk_copying,
            "bulk_renaming": self._scenario_bulk_renaming,
            "canary_touch_benign": self._scenario_canary_touch_benign,
            "canary_plus_rapid_bulk": self._scenario_canary_plus_rapid_bulk,
            "rapid_bulk_without_canary": self._scenario_rapid_bulk_without_canary,
        }

        runner = runner_map[scenario_key]
        result = runner(sid, on_op_callback or (lambda cur, tot: None))
        return result

    def _scenario_normal_editing(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["normal_file_editing"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        damaged = 0
        start = time.time()

        doc_dir = self.sandbox.validate_path("documents")
        files = [p for p in doc_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        if not files:
            files = self.helper.create_user_files(count=5, directory="documents")
            time.sleep(0.05)

        for i, fpath in enumerate(files[:planned]):
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break

            with open(fpath, "a", encoding="utf-8") as f:
                f.write(f"\nUser edit revision {i + 1} at {time.time()}: normal business note.")
            executed += 1
            cb(executed, planned)
            time.sleep(0.12)  # Normal realistic user pause

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=damaged,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )

    def _scenario_bulk_copying(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["bulk_copying"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        start = time.time()

        proj_dir = self.sandbox.validate_path("projects")
        src_files = [p for p in proj_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        if not src_files:
            src_files = self.helper.create_user_files(count=6, directory="projects")
            time.sleep(0.05)

        dest_dir = self.sandbox.validate_path("backups")
        dest_dir.mkdir(parents=True, exist_ok=True)

        for i, src in enumerate(src_files[:planned]):
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break

            target = dest_dir / f"backup_{src.name}"
            self.sandbox.validate_path(target)
            shutil.copy2(src, target)
            executed += 1
            cb(executed, planned)
            time.sleep(0.08)

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=0,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )

    def _scenario_bulk_renaming(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["bulk_renaming"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        start = time.time()

        fin_dir = self.sandbox.validate_path("finance")
        files = [p for p in fin_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        if not files:
            files = self.helper.create_user_files(count=6, directory="finance")
            time.sleep(0.05)

        for i, src in enumerate(files[:planned]):
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break

            target = src.parent / f"archived_{src.name}"
            self.sandbox.validate_path(target)
            src.rename(target)
            executed += 1
            cb(executed, planned)
            time.sleep(0.08)

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=0,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )

    def _scenario_canary_touch_benign(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["canary_touch_benign"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        start = time.time()

        canaries = list(self.canary_manager._canary_records.values())
        if not canaries:
            canaries = self.canary_manager.deploy_canaries()

        if not canaries:
            raise ScenarioExecutionError("No canaries available to test")

        # Find or create user files
        doc_dir = self.sandbox.validate_path("documents")
        user_files = [p for p in doc_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        if len(user_files) < 3:
            user_files = self.helper.create_user_files(count=3, directory="documents")

        canary_rel = canaries[0].relative_path
        canary_abs = self.sandbox.validate_path(canary_rel)

        # Step 1: Touch the canary once (innocent indexer read / metadata edit)
        if self.response_manager.is_blocked():
            prevented = planned - executed
        else:
            with open(canary_abs, "a", encoding="utf-8") as f:
                f.write(f"\n# Indexed by local search service at {time.time()}")
            executed += 1
            cb(executed, planned)

        # Step 2: Benign pause with no rapid damage follow-up
        time.sleep(0.3)

        # Step 3: Edit 3 ordinary documents slowly with low entropy text
        for uf in user_files[:3]:
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break
            with open(uf, "a", encoding="utf-8") as f:
                f.write(f"\nStandard documentation update at {time.time()}.")
            executed += 1
            cb(executed, planned)
            time.sleep(0.3)

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=0,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )

    def _scenario_canary_plus_rapid_bulk(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["canary_plus_rapid_bulk"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        damaged = 0
        start = time.time()

        canaries = list(self.canary_manager._canary_records.values())
        if not canaries:
            canaries = self.canary_manager.deploy_canaries()

        doc_dir = self.sandbox.validate_path("documents")
        user_files = [p for p in doc_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        if len(user_files) < 11:
            more_files = self.helper.create_user_files(count=11, directory="documents")
            user_files.extend(more_files)

        # Operation 1: Tamper with first canary
        if canaries:
            canary_abs = self.sandbox.validate_path(canaries[0].relative_path)
            if self.response_manager.is_blocked():
                prevented = planned - executed
            else:
                high_ent = self.helper.generate_high_entropy_bytes(1024)
                with open(canary_abs, "wb") as f:
                    f.write(high_ent)
                executed += 1
                cb(executed, planned)

        time.sleep(0.02)

        # Subsequent operations: Rapidly overwrite user documents with high entropy simulated payload
        for uf in user_files[:planned - 1]:
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break

            high_ent = self.helper.generate_high_entropy_bytes(2048)
            with open(uf, "wb") as f:
                f.write(high_ent)
            executed += 1
            damaged += 1
            cb(executed, planned)
            time.sleep(0.02)  # Rapid malicious burst velocity

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=damaged,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )

    def _scenario_rapid_bulk_without_canary(self, sid: str, cb: Callable) -> SimulationResult:
        defn = self.SCENARIO_CATALOG["rapid_bulk_without_canary"]
        planned = defn.planned_operations
        executed = 0
        prevented = 0
        damaged = 0
        start = time.time()

        doc_dir = self.sandbox.validate_path("documents")
        proj_dir = self.sandbox.validate_path("projects")
        files1 = [p for p in doc_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        files2 = [p for p in proj_dir.glob("*.txt") if not self.canary_manager.is_canary(self.sandbox.relative_to_sandbox(p))]
        all_files = files1 + files2
        if len(all_files) < planned:
            all_files.extend(self.helper.create_user_files(count=planned, directory="projects"))

        for uf in all_files[:planned]:
            if self.response_manager.is_blocked():
                prevented = planned - executed
                break

            # Write high entropy bytes rapidly
            high_ent = self.helper.generate_high_entropy_bytes(2048)
            with open(uf, "wb") as f:
                f.write(high_ent)
            executed += 1
            damaged += 1
            cb(executed, planned)
            time.sleep(0.02)

        end = time.time()
        return SimulationResult(
            scenario_id=sid,
            scenario_name=defn.name,
            category=defn.category,
            planned_ops=planned,
            executed_ops=executed,
            prevented_ops=prevented,
            files_damaged=damaged,
            response_triggered=self.response_manager.is_blocked(),
            start_time=start,
            end_time=end,
            duration_ms=(end - start) * 1000.0,
        )
