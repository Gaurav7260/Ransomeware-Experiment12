"""Safe simulated response manager."""

import logging
import threading
import time
from typing import Optional

from canary_sentinel.core.config import ResponseConfig
from canary_sentinel.storage.models import AlertRecord

logger = logging.getLogger(__name__)


class SimulatedResponseManager:
    """Manages safe containment by signaling the simulator to halt subsequent operations.

    Safety Guarantee:
    Exclusively signals the internal simulator to stop planned operations.
    Never kills operating system processes or user processes.
    """

    SEVERITY_RANKS = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

    def __init__(self, config: Optional[ResponseConfig] = None):
        self.config = config or ResponseConfig()
        self._blocked = False
        self._block_time: Optional[float] = None
        self._triggering_alert: Optional[AlertRecord] = None
        self._lock = threading.Lock()

    def reset(self) -> None:
        """Reset response state for a new scenario or experiment."""
        with self._lock:
            self._blocked = False
            self._block_time = None
            self._triggering_alert = None

    def is_blocked(self) -> bool:
        """Query if response containment is currently active."""
        with self._lock:
            return self._blocked

    def get_block_time(self) -> Optional[float]:
        with self._lock:
            return self._block_time

    def get_triggering_alert(self) -> Optional[AlertRecord]:
        with self._lock:
            return self._triggering_alert

    def evaluate_and_respond(self, alert: AlertRecord) -> bool:
        """Evaluate if an alert satisfies response conditions, and activate simulated block.

        Returns:
            True if response was triggered and blocked, False otherwise.
        """
        with self._lock:
            if self._blocked:
                return True  # Already blocked

            if not self.config.auto_block:
                return False

            min_rank = self.SEVERITY_RANKS.get(self.config.minimum_severity, 3)
            alert_rank = self.SEVERITY_RANKS.get(alert.severity, 1)

            if alert_rank >= min_rank or alert.risk_score >= self.config.risk_score_threshold:
                self._blocked = True
                self._block_time = time.time()
                self._triggering_alert = alert
                alert.response_status = "BLOCKED"
                logger.warning(
                    f"[SIMULATED RESPONSE] Containment triggered by {alert.detector_config} detector! "
                    f"Risk={alert.risk_score}, Severity={alert.severity}. Simulator operations blocked."
                )
                return True

            return False

