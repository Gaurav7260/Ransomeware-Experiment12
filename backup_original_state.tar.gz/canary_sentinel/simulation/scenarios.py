"""Harmless test scenarios for CanarySentinel."""

import os
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional

from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.core.utils import calculate_entropy


@dataclass
class ScenarioDefinition:
    """Metadata and execution function for a test scenario."""

    id: str
    name: str
    category: str  # "benign" or "suspicious"
    description: str
    expected_baseline_alert: bool
    expected_canary_alert: bool
    expected_hybrid_alert: bool
    planned_operations: int


class ScenarioExecutionError(Exception):
    pass


class ScenarioHelper:
    """Provides helper routines to create test user files and simulate harmless operations."""

    def __init__(self, sandbox: SandboxManager):
        self.sandbox = sandbox

    def create_user_files(self, count: int = 10, directory: str = "documents") -> List[Path]:
        """Create a set of realistic, harmless user files inside sandbox."""
        dir_path = self.sandbox.validate_path(directory)
        dir_path.mkdir(parents=True, exist_ok=True)
        created_paths = []

        for i in range(count):
            filename = f"user_doc_{i + 1:02d}.txt"
            p = dir_path / filename
            self.sandbox.validate_path(p)
            content = f"User document #{i + 1}\nStatus: Internal working draft.\nNotes: Standard project documentation.\n" * 5
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)
            created_paths.append(p)

        return created_paths

    @staticmethod
    def generate_high_entropy_bytes(size: int = 2048) -> bytes:
        """Generate pseudo-random bytes with high Shannon entropy (simulating encrypted data harmlessly)."""
        # Using random bytes generates entropy ~ 7.8 - 7.9 without any cryptography
        return bytes(random.getrandbits(8) for _ in range(size))

    @staticmethod
    def generate_low_entropy_text(size: int = 2048) -> str:
        """Generate standard low-entropy text."""
        seed = "Regular business report text with standard english vocabulary and predictable frequencies. "
        repeats = (size // len(seed)) + 1
        return (seed * repeats)[:size]

