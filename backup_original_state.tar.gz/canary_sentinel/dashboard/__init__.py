"""Dashboard package for CanarySentinel."""

