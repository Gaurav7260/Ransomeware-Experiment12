"""Streamlit Dashboard for CanarySentinel — Complete MVP."""

import datetime
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import psutil
import streamlit as st

# Ensure repository root is on PYTHONPATH
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.config import SentinelConfig
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.detection.baseline_detector import BaselineDetector
from canary_sentinel.detection.canary_detector import CanaryDetector
from canary_sentinel.detection.hybrid_detector import HybridDetector
from canary_sentinel.experiments.metrics import MetricsCalculator
from canary_sentinel.experiments.runner import ExperimentRunner
from canary_sentinel.monitoring.monitor import FilesystemMonitor
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.simulation.simulator import ActivitySimulator
from canary_sentinel.storage.db import Database


# Page configuration
st.set_page_config(
    page_title="CanarySentinel — Ransomware Behavioral Detection MVP",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)


@st.cache_resource
def get_sentinel_services() -> Dict[str, Any]:
    """Initialize core CanarySentinel singletons."""
    config = SentinelConfig.load()
    sandbox = SandboxManager(config.system.sandbox_dir)
    db = Database(config.system.db_path)
    canary_mgr = CanaryManager(sandbox, db, config.canary)
    normalizer = EventNormalizer(sandbox, canary_mgr, config.monitoring.debounce_ms)
    monitor = FilesystemMonitor(sandbox, normalizer)
    response_mgr = SimulatedResponseManager(config.response)
    simulator = ActivitySimulator(sandbox, canary_mgr, response_mgr)
    runner = ExperimentRunner(sandbox, db, canary_mgr, monitor, simulator, response_mgr)
    metrics_calc = MetricsCalculator(db)

    # Automatically ensure monitor is started
    if not monitor.is_running:
        monitor.start()

    return {
        "config": config,
        "sandbox": sandbox,
        "db": db,
        "canary_mgr": canary_mgr,
        "normalizer": normalizer,
        "monitor": monitor,
        "response_mgr": response_mgr,
        "simulator": simulator,
        "runner": runner,
        "metrics_calc": metrics_calc,
    }


def render_sidebar(services: Dict[str, Any]) -> str:
    """Render sidebar navigation and quick system telemetry."""
    st.sidebar.title("🛡️ CanarySentinel")
    st.sidebar.caption("Endpoint Ransomware Behavioral Detection & Decoy System")

    nav = st.sidebar.radio(
        "Navigation",
        [
            "Overview & Telemetry",
            "Decoy & Sandbox Controls",
            "Live Event Stream",
            "Incidents & Evidence Alerts",
            "Simulation & Experiments",
            "Comparative Research Analysis",
        ],
        index=0,
    )

    st.sidebar.markdown("---")
    st.sidebar.subheader("System Health")
    monitor: FilesystemMonitor = services["monitor"]
    sandbox: SandboxManager = services["sandbox"]
    canary_mgr: CanaryManager = services["canary_mgr"]

    mon_status = "🟢 ACTIVE" if monitor.is_running else "🔴 STOPPED"
    st.sidebar.write(f"**FS Monitor:** {mon_status}")
    st.sidebar.write(f"**Sandbox:** `{sandbox.sandbox_path.name}`")
    st.sidebar.write(f"**Canary Decoys:** {len(canary_mgr._canary_paths)} active")

    # Host resource snapshot
    cpu_cur = psutil.cpu_percent(interval=None)
    mem_cur = psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
    st.sidebar.write(f"**Host CPU:** {cpu_cur:.1f}%")
    st.sidebar.write(f"**App RAM:** {mem_cur:.1f} MB")

    st.sidebar.markdown("---")
    zip_path = Path("CanarySentinel_Research_Dossier.zip")
    if zip_path.exists():
        with open(zip_path, "rb") as zf:
            st.sidebar.download_button(
                label="📦 Download Dossier ZIP",
                data=zf.read(),
                file_name="CanarySentinel_Research_Dossier.zip",
                mime="application/zip",
                use_container_width=True,
            )

    if st.sidebar.button("🔄 Refresh Dashboard", use_container_width=True):
        st.rerun()

    return nav


def render_overview(services: Dict[str, Any]) -> None:
    """Section 1: Overview & Telemetry."""
    st.title("🛡️ CanarySentinel — Overview & Telemetry")
    st.markdown(
        "**CanarySentinel** is a local, lightweight prototype engineered for macOS Apple Silicon. "
        "It evaluates whether **combining canary decoy interactions with contextual filesystem behavior** "
        "improves ransomware detection quality and minimizes simulated file damage compared with "
        "canary-only and behavior-only configurations."
    )

    db: Database = services["db"]
    canary_mgr: CanaryManager = services["canary_mgr"]
    sandbox: SandboxManager = services["sandbox"]
    monitor: FilesystemMonitor = services["monitor"]
    metrics_calc: MetricsCalculator = services["metrics_calc"]

    events = db.get_events(limit=1000)
    alerts = db.get_alerts(limit=500)
    scenarios = db.get_scenarios(limit=500)
    canaries = canary_mgr.verify_integrity()

    # Top-level KPI cards
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Total Events Logged", len(events), help="Normalized filesystem events captured by watchdog")
    with c2:
        st.metric("Total Alerts Raised", len(alerts), help="Security incident alerts generated across all detectors")
    with c3:
        st.metric("Scenarios Evaluated", len(scenarios), help="Total benchmark trials completed")
    with c4:
        active_canaries = sum(1 for s in canaries.values() if s == "ACTIVE")
        st.metric("Active Decoy Traps", f"{active_canaries}/{len(canaries)}", help="Canaries currently deployed on disk with intact SHA-256")

    st.markdown("---")

    # Detector Performance Snapshot
    st.subheader("⚡ Detector Performance Snapshot")
    if scenarios:
        report = metrics_calc.generate_comparison_report()
        snap_rows = []
        for det_k in ["baseline", "canary_only", "hybrid"]:
            m = report.metrics_by_detector[det_k]
            p_str = f"{m.precision:.1%}" if m.precision is not None else "N/A"
            r_str = f"{m.recall:.1%}" if m.recall is not None else "N/A"
            f_str = f"{m.f1_score:.2f}" if m.f1_score is not None else "N/A"
            fpr_str = f"{m.false_positive_rate:.1%}" if m.false_positive_rate is not None else "N/A"
            snap_rows.append({
                "Detector Configuration": det_k.replace("_", " ").title(),
                "Trials Evaluated": m.total_runs,
                "Precision": p_str,
                "Recall": r_str,
                "F1-Score": f_str,
                "False Alarm Rate (FPR)": fpr_str,
                "Mean Latency": f"{m.mean_latency_ms:.1f} ms" if m.mean_latency_ms > 0 else "-",
                "Simulated File Damage": f"{m.mean_files_damaged:.1f} files",
                "Subsequent Ops Blocked": f"{m.mean_ops_prevented_pct:.1f}%",
            })
        st.dataframe(pd.DataFrame(snap_rows), use_container_width=True)
    else:
        st.info("No scenario trials evaluated yet. Run the benchmark suite in 'Simulation & Experiments' to populate metrics.")

    st.markdown("---")

    # System Status & Environment
    col_sys, col_mon, col_sbox = st.columns(3)
    with col_sys:
        st.subheader("🖥️ Host Environment")
        st.write(f"- **OS**: `{platform.system()} {platform.release()}` ({platform.machine()})")
        st.write(f"- **Python Version**: `{platform.python_version()}`")
        st.write(f"- **Process PID**: `{os.getpid()}`")
        st.write(f"- **Process Memory**: `{psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024):.1f} MB`")
        st.write(f"- **System Cores**: `{psutil.cpu_count(logical=True)}` logical cores")

    with col_mon:
        st.subheader("👁️ Monitoring Status")
        mon_state = "🟢 RUNNING" if monitor.is_running else "🔴 STOPPED"
        st.write(f"- **Observer State**: {mon_state}")
        st.write(f"- **Backend Engine**: `Watchdog Observer (Apple Silicon FSEvents/kqueue)`")
        st.write(f"- **Event Debounce**: `50 ms sliding window`")
        st.write(f"- **Scope**: Dedicated Sandbox strictly")
        st.write(f"- **Isolation**: `Zero external directory monitoring`")

    with col_sbox:
        st.subheader("📦 Sandbox Telemetry")
        st.write(f"- **Sandbox Root**: `{sandbox.sandbox_path}`")
        total_files = 0
        total_size = 0
        for p in sandbox.sandbox_path.glob("**/*"):
            if p.is_file():
                total_files += 1
                try:
                    total_size += p.stat().st_size
                except OSError:
                    pass
        st.write(f"- **Contained Files**: `{total_files} files`")
        st.write(f"- **Disk Footprint**: `{total_size / 1024:.1f} KB`")
        st.write(f"- **Boundary Check**: `✅ Strict path containment enforced`")

    st.markdown("---")

    # Activity Summary Breakdown
    col_evt_break, col_alt_break = st.columns(2)
    with col_evt_break:
        st.subheader("📊 Event Type Breakdown")
        if events:
            df_ev = pd.DataFrame([{"Type": e.event_type, "Canary": "Decoy" if e.is_canary else "User"} for e in events])
            type_counts = df_ev["Type"].value_counts().reset_index()
            type_counts.columns = ["Event Type", "Count"]
            st.dataframe(type_counts, use_container_width=True)
        else:
            st.info("No events recorded yet. Run a scenario to generate activity.")

    with col_alt_break:
        st.subheader("🚨 Alert Severity Breakdown")
        if alerts:
            df_al = pd.DataFrame([{"Severity": a.severity, "Detector": a.detector_config} for a in alerts])
            sev_counts = df_al["Severity"].value_counts().reset_index()
            sev_counts.columns = ["Severity Level", "Alert Count"]
            st.dataframe(sev_counts, use_container_width=True)
        else:
            st.info("No alerts recorded yet. Run a suspicious scenario to trigger detection.")

    st.markdown("---")

    # Recent Activity Feed
    st.subheader("🕒 Recent Activity Feed")
    recent_events = events[:8]
    if recent_events:
        df_recent = pd.DataFrame([
            {
                "Time": datetime.datetime.fromtimestamp(e.timestamp).strftime("%H:%M:%S.%f")[:-3],
                "Event": e.event_type,
                "Target Path": e.path,
                "Asset Category": "🚨 CANARY DECOY" if e.is_canary else "📄 USER DOC",
                "Entropy (bits)": f"{e.entropy:.2f}",
                "Scenario ID": e.scenario_id or "-",
            }
            for e in recent_events
        ])
        st.dataframe(df_recent, use_container_width=True)
    else:
        st.info("No recent activity.")


def render_sandbox_controls(services: Dict[str, Any]) -> None:
    """Section 2: Decoy & Sandbox Controls."""
    st.title("🗂️ Decoy Traps & Sandbox Controls")
    sandbox: SandboxManager = services["sandbox"]
    canary_mgr: CanaryManager = services["canary_mgr"]
    db: Database = services["db"]

    st.info(f"**Active Sandbox Boundary:** `{sandbox.sandbox_path}`\n\n"
            "All decoy files, user files, and simulation scenarios operate strictly within this path. "
            "Paths outside this directory are unconditionally rejected.")

    # Control Operations
    st.subheader("🛠️ Management Actions")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("🚀 Deploy Decoy Canaries", use_container_width=True):
            deployed = canary_mgr.deploy_canaries()
            st.success(f"Successfully deployed {len(deployed)} canary decoy traps across sandbox subdirectories!")
            st.rerun()

    with c2:
        if st.button("🔍 Verify Canary Disk Integrity", use_container_width=True):
            status_map = canary_mgr.verify_integrity()
            st.success("Canary integrity audit complete.")
            st.json(status_map)

    st.markdown("---")

    # Safe Reset Controls with Clear Warnings
    st.subheader("🧹 Safe Reset Controls")
    st.warning("⚠️ **Safety Notice**: Resetting permanently alters local test data. "
               "You must check the confirmation checkbox before executing either operation.")

    r1, r2 = st.columns(2)
    with r1:
        st.markdown("**Purge Sandbox Filesystem**")
        confirm_sandbox = st.checkbox("I confirm I want to wipe all files inside ./sandbox", key="chk_reset_sbox")
        if st.button("🧹 Purge Sandbox Files", disabled=not confirm_sandbox, use_container_width=True):
            sandbox.reset_sandbox()
            canary_mgr.clear_canaries()
            st.success("Sandbox filesystem cleanly purged.")
            st.rerun()

    with r2:
        st.markdown("**Purge SQLite Database Records**")
        confirm_db = st.checkbox("I confirm I want to erase all events, alerts, and trials", key="chk_reset_db")
        if st.button("🗑️ Purge Database Records", disabled=not confirm_db, use_container_width=True):
            db.reset_db()
            st.success("Database tables cleanly purged.")
            st.rerun()

    st.markdown("---")

    # Deployed Canary Registry Table
    st.subheader("📋 Registered Decoy Traps")
    canaries = db.get_canaries()
    if canaries:
        rationale_map = {
            "!00_corporate_passwords.xlsx": "Alphabetical priority trap for credential harvester scans",
            "!00_master_financials_2026.pdf": "High-value document lure in root directory",
            "aaa_employee_salaries.csv": "Confidential compensation lure targeted by data exfiltration",
            "0_database_backup_production.sql": "Database backup lure targeted by ransomware indexers",
            "!aa_cryptocurrency_cold_wallet.txt": "High-value wallet seed trap",
            "_urgent_merger_acquisition_terms.docx": "Corporate M&A transaction decoy",
            "00_client_contracts_signed.pdf": "Contract decoy in documents folder",
            "aaa_api_secret_keys.env": "Cloud provider secrets decoy",
        }

        df = pd.DataFrame([
            {
                "Filename": c.filename,
                "Relative Sandbox Path": c.relative_path,
                "Size (Bytes)": c.file_size,
                "Status": c.status,
                "SHA-256 Hash": c.file_hash[:16] + "...",
                "Decoy Bait Rationale": rationale_map.get(c.filename, "General ransomware lure"),
                "Created At": c.created_at,
            }
            for c in canaries
        ])
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No canary traps are currently registered. Click 'Deploy Decoy Canaries' above.")


def render_events(services: Dict[str, Any]) -> None:
    """Section 3: Live Event Stream."""
    st.title("📊 Normalized Filesystem Event Stream")
    st.markdown("Every filesystem interaction inside the sandbox is captured by the Watchdog observer, "
                "debounced, and normalized into a uniform `NormalizedEvent` containing path, event type, "
                "file size, and Shannon entropy.")

    db: Database = services["db"]

    # Filter & Sort Controls
    col1, col2, col3, col4, col5 = st.columns([2, 2, 2, 2, 2])
    with col1:
        search_query = st.text_input("🔍 Search File Path", placeholder="e.g. passwords, txt, doc")
    with col2:
        filter_canary = st.selectbox("Asset Filter", ["All Assets", "Canary Traps Only", "User Files Only"])
    with col3:
        filter_type = st.selectbox("Event Action", ["All Actions", "CREATE", "MODIFY", "DELETE", "MOVE"])
    with col4:
        sort_by = st.selectbox("Sort By", ["Timestamp (Newest First)", "Timestamp (Oldest First)", "Entropy (Highest First)", "File Path (A-Z)"])
    with col5:
        limit = st.slider("Max Events", min_value=25, max_value=1000, value=200, step=25)

    is_canary_filter = None
    if filter_canary == "Canary Traps Only":
        is_canary_filter = True
    elif filter_canary == "User Files Only":
        is_canary_filter = False

    events = db.get_events(limit=limit, is_canary=is_canary_filter)

    # Apply client-side filters
    if filter_type != "All Actions":
        events = [e for e in events if e.event_type == filter_type]
    if search_query:
        q = search_query.lower()
        events = [e for e in events if q in e.path.lower()]

    # Sorting
    if sort_by == "Timestamp (Newest First)":
        events.sort(key=lambda e: e.timestamp, reverse=True)
    elif sort_by == "Timestamp (Oldest First)":
        events.sort(key=lambda e: e.timestamp, reverse=False)
    elif sort_by == "Entropy (Highest First)":
        events.sort(key=lambda e: e.entropy, reverse=True)
    elif sort_by == "File Path (A-Z)":
        events.sort(key=lambda e: e.path.lower(), reverse=False)

    if events:
        st.write(f"Showing **{len(events)}** matching events:")

        df = pd.DataFrame([
            {
                "Timestamp": datetime.datetime.fromtimestamp(e.timestamp).strftime("%H:%M:%S.%f")[:-3],
                "Action": e.event_type,
                "Relative Path": e.path,
                "Asset Category": "🚨 CANARY TRIPWIRE" if e.is_canary else "📄 USER DOCUMENT",
                "Entropy (bits)": f"{e.entropy:.2f}",
                "Entropy Level": "🔴 HIGH (Encrypted)" if e.entropy >= 7.0 else ("🟠 MED" if e.entropy >= 5.0 else "🟢 LOW"),
                "Size (Bytes)": e.size_bytes,
                "Scenario ID": e.scenario_id or "-",
            }
            for e in events
        ])
        st.dataframe(df, use_container_width=True)

        # CSV Download Button
        csv_data = df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Export Filtered Events to CSV",
            data=csv_data,
            file_name="canary_sentinel_events.csv",
            mime="text/csv",
            help="Download the filtered normalized events as a CSV file",
        )
    else:
        st.info("No filesystem events match the current filter criteria.")


def render_alerts(services: Dict[str, Any]) -> None:
    """Section 4: Incidents & Evidence Alerts."""
    st.title("🚨 Security Incidents & Evidence Alerts")
    st.markdown("CanarySentinel generates transparent, evidence-backed security alerts. "
                "Each alert records the triggering operation, correlated supporting events within the "
                "observation window, quantitative risk score, and automated response containment status.")

    db: Database = services["db"]

    # Filter controls
    c1, c2 = st.columns(2)
    with c1:
        filter_sev = st.selectbox("Filter Severity", ["All Severities", "CRITICAL", "HIGH", "MEDIUM", "LOW"])
    with c2:
        filter_det = st.selectbox("Filter Detection Configuration", ["All Detectors", "baseline", "canary_only", "hybrid"])

    alerts = db.get_alerts(limit=200)

    if filter_sev != "All Severities":
        alerts = [a for a in alerts if a.severity == filter_sev]
    if filter_det != "All Detectors":
        alerts = [a for a in alerts if a.detector_config == filter_det]

    if not alerts:
        st.info("No security incidents recorded matching the selected criteria. "
                "Run a suspicious scenario in 'Simulation & Experiments' to trigger live alerts.")
        return

    st.write(f"Total matching incidents: **{len(alerts)}**")

    # CSV Download Button for Alerts
    alerts_df = pd.DataFrame([
        {
            "Alert ID": a.alert_id,
            "Timestamp": a.iso_timestamp,
            "Detector": a.detector_config,
            "Severity": a.severity,
            "Risk Score": a.risk_score,
            "Confidence": a.confidence,
            "Triggering Summary": a.triggering_event_summary,
            "Response Status": a.response_status,
            "Scenario ID": a.scenario_id or "-",
        }
        for a in alerts
    ])
    csv_alerts = alerts_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="📥 Export Alerts to CSV",
        data=csv_alerts,
        file_name="canary_sentinel_alerts.csv",
        mime="text/csv",
    )

    st.markdown("---")

    # Detailed Incident Audit Cards
    for alert in alerts:
        sev_color = {
            "CRITICAL": "🔴",
            "HIGH": "🟠",
            "MEDIUM": "🔵",
            "LOW": "⚪",
        }.get(alert.severity, "⚪")

        # Distinguish confirmed simulated attacks vs suspicious anomalies vs benign decoy inspections
        if alert.severity in ["HIGH", "CRITICAL"] and alert.risk_score >= 70:
            attack_class = "🚨 CONFIRMED SIMULATED ATTACK"
        elif alert.detector_config == "canary_only" and "touch_benign" in (alert.scenario_id or ""):
            attack_class = "⚠️ FALSE ALARM: BENIGN DECOY INSPECTION"
        else:
            attack_class = "⚠️ SUSPICIOUS ANOMALY"

        with st.expander(
            f"{sev_color} [{alert.detector_config.upper()}] {alert.severity} — {attack_class} — {alert.triggering_event_summary} ({alert.iso_timestamp})"
        ):
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.metric("Detector Configuration", alert.detector_config.replace("_", " ").title())
            with c2:
                st.metric("Risk Score", f"{alert.risk_score}/100")
            with c3:
                st.metric("Detection Confidence", f"{int(alert.confidence * 100)}%")
            with c4:
                resp_badge = "🛡️ BLOCKED" if alert.response_status == "BLOCKED" else alert.response_status
                st.metric("Containment Status", resp_badge)

            st.progress(alert.risk_score / 100.0)

            st.markdown(f"**Threat Classification**: `{attack_class}`")
            st.markdown("**Structured Evidence & Rationale Breakdown:**")
            st.code(alert.explanation, language="text")

            c_trig, c_supp = st.columns(2)
            with c_trig:
                st.write(f"**Triggering Event ID**: `{alert.triggering_event_id}`")
            with c_supp:
                st.write(f"**Correlated Supporting Evidence Count**: `{len(alert.supporting_event_ids)} events`")
                if alert.supporting_event_ids:
                    st.caption("IDs: " + ", ".join([f"`{sid[:8]}`" for sid in alert.supporting_event_ids[:8]]))


def render_experiments(services: Dict[str, Any]) -> None:
    """Section 5: Simulation & Experiments."""
    st.title("🧪 Experiment Controls & Harmless Activity Simulator")
    runner: ExperimentRunner = services["runner"]
    simulator: ActivitySimulator = services["simulator"]
    db: Database = services["db"]

    st.markdown(
        "CanarySentinel evaluates detection efficacy using standardized, harmless scenarios that operate "
        "**strictly on generated test files inside `./sandbox`**. Real ransomware payloads, destructive behaviors, "
        "and external process kills are never used."
    )

    # Scenario Catalog Cards
    with st.expander("📚 Explore Available Simulation Scenario Catalog", expanded=False):
        for sc_id, defn in simulator.SCENARIO_CATALOG.items():
            cat_badge = "🟢 BENIGN" if defn.category == "benign" else "🔴 SUSPICIOUS"
            st.markdown(f"### {defn.name} ({cat_badge})")
            st.write(f"**Description**: {defn.description}")
            st.write(f"- Planned Operations: `{defn.planned_operations}`")
            st.write(f"- Expected Baseline: `{'Alert' if defn.expected_baseline_alert else 'Pass'}` | "
                     f"Expected Canary-Only: `{'Alert' if defn.expected_canary_alert else 'Pass'}` | "
                     f"Expected Hybrid: `{'Alert' if defn.expected_hybrid_alert else 'Pass'}`")
            st.markdown("---")

    t1, t2, t3 = st.tabs(["Single Scenario Execution", "Automated Full Benchmark Suite", "Historical Trial Log"])

    with t1:
        st.subheader("Run Individual Scenario")
        col1, col2 = st.columns(2)
        with col1:
            scenario_key = st.selectbox(
                "Select Harmless Scenario",
                list(simulator.SCENARIO_CATALOG.keys()),
                format_func=lambda k: f"{simulator.SCENARIO_CATALOG[k].name} ({simulator.SCENARIO_CATALOG[k].category.upper()})",
            )
        with col2:
            detector_choice = st.selectbox(
                "Select Detection Configuration",
                ["hybrid", "canary_only", "baseline"],
                format_func=lambda d: d.replace("_", " ").title(),
            )

        sc_defn = simulator.SCENARIO_CATALOG[scenario_key]
        st.info(f"**Selected Scenario Details**\n\n"
                f"- **Category**: `{sc_defn.category.upper()}`\n"
                f"- **Planned Operations**: `{sc_defn.planned_operations}`\n"
                f"- **Description**: {sc_defn.description}")

        if st.button("▶️ Execute Scenario Trial", type="primary", use_container_width=True):
            with st.spinner(f"Executing '{sc_defn.name}' with '{detector_choice}' detector..."):
                record = runner.run_trial(scenario_key=scenario_key, detector_config=detector_choice)

            st.success(f"Scenario trial '{record.scenario_name}' completed!")
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                det_label = "🚨 ALERT (DETECTED)" if record.detected else "🟢 PASS (UNDETECTED)"
                st.metric("Detection Outcome", det_label)
            with c2:
                lat = f"{record.detection_latency_ms:.1f} ms" if record.detection_latency_ms else "N/A"
                st.metric("Detection Latency", lat)
            with c3:
                st.metric("Files Damaged Before Alert", record.files_damaged)
            with c4:
                prevented_pct = (record.prevented_ops / record.planned_ops * 100) if record.planned_ops > 0 else 0.0
                st.metric("Operations Prevented", f"{record.prevented_ops}/{record.planned_ops} ({prevented_pct:.0f}%)")

    with t2:
        st.subheader("Automated Full Benchmark Suite")
        st.markdown(
            "The automated benchmark executes an identical experimental matrix across all 6 scenarios "
            "(4 benign + 2 suspicious) for all 3 detector configurations (Baseline, Canary-Only, Hybrid), "
            "yielding **18 reproducible trials per iteration** saved directly to SQLite."
        )

        iter_count = st.slider("Benchmark Iterations (Repetitions)", min_value=1, max_value=10, value=1, help="Number of repetitions per scenario (e.g. 10 iterations = 180 total trials)")
        total_trials = 6 * 3 * iter_count

        if st.button(f"⚡ Execute Automated Benchmark ({total_trials} Trials)", type="primary", use_container_width=True):
            pbar = st.progress(0.0)
            status_txt = st.empty()

            def on_progress(cur: int, tot: int, desc: str) -> None:
                pct = cur / max(1, tot)
                pbar.progress(min(1.0, pct))
                status_txt.write(f"Executing trial {cur}/{tot}: `{desc}`")

            with st.spinner(f"Running {total_trials} benchmark trials in sandbox..."):
                runner.run_benchmark_suite(iterations=iter_count, progress_callback=on_progress)

            pbar.progress(1.0)
            status_txt.success("✅ Benchmark suite execution successfully finished!")
            st.rerun()

    with t3:
        st.subheader("📜 Historical Trial Log")
        scenarios = db.get_scenarios(limit=1000)
        if scenarios:
            df_trials = pd.DataFrame([
                {
                    "Scenario ID": s.scenario_id,
                    "Scenario Name": s.scenario_name,
                    "Category": s.scenario_type.upper(),
                    "Detector": s.detector_config.replace("_", " ").title(),
                    "Detected": "🚨 YES" if s.detected else "🟢 NO",
                    "Latency (ms)": f"{s.detection_latency_ms:.1f}" if s.detection_latency_ms else "N/A",
                    "Files Damaged": s.files_damaged,
                    "Prevented Ops": f"{s.prevented_ops}/{s.planned_ops}",
                    "Prevented %": f"{(s.prevented_ops / s.planned_ops * 100):.1f}%" if s.planned_ops > 0 else "0.0%",
                    "Duration (ms)": f"{s.duration_ms:.1f}",
                    "Alert Triggered": "YES" if s.response_triggered else "NO",
                }
                for s in scenarios
            ])
            st.dataframe(df_trials, use_container_width=True)

            # Export Trials CSV
            csv_trials = df_trials.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Export Trial History to CSV",
                data=csv_trials,
                file_name="canary_sentinel_trials.csv",
                mime="text/csv",
            )
        else:
            st.info("No experiment trials recorded yet. Run a scenario or the benchmark suite above.")


def render_research_analysis(services: Dict[str, Any]) -> None:
    """Section 6: Comparative Research Analysis & Benchmark Results."""
    st.title("📈 Comparative Research Analysis & Benchmark Results")
    metrics_calc: MetricsCalculator = services["metrics_calc"]
    db: Database = services["db"]

    scenarios = db.get_scenarios()
    if not scenarios:
        st.warning("⚠️ No scenario trials recorded in SQLite database yet. "
                   "Please run the Automated Benchmark Suite in 'Simulation & Experiments' to generate data.")
        return

    report = metrics_calc.generate_comparison_report()

    # Research Question Callout
    st.markdown("### 🎯 Research Question")
    st.info(
        "**Does combining canary-file interactions with contextual filesystem behavior improve ransomware detection "
        "quality and reduce simulated file damage compared with canary-only and behavior-only detection?**"
    )

    # Empirical Verdict
    st.markdown("### 🔬 Empirical Findings & Research Verdict")
    st.success(f"**Research Verdict:** {report.research_verdict}")

    for finding in report.key_findings:
        st.markdown(f"- **Key Finding**: {finding}")

    st.markdown("---")

    # Side-by-side performance table with TP, FP, TN, FN counts
    st.subheader("📊 Side-by-Side Detector Performance Matrix")
    st.caption("All metrics are computed strictly from stored SQLite trial records. No fabricated figures.")

    matrix_rows = []
    for cfg_key in ["baseline", "canary_only", "hybrid"]:
        m = report.metrics_by_detector[cfg_key]
        p_str = f"{m.precision:.2%}" if m.precision is not None else "Undefined"
        r_str = f"{m.recall:.2%}" if m.recall is not None else "Undefined"
        f_str = f"{m.f1_score:.2f}" if m.f1_score is not None else "Undefined"
        fpr_str = f"{m.false_positive_rate:.2%}" if m.false_positive_rate is not None else "Undefined"

        mean_lat = getattr(m, "mean_latency_ms", 0.0)
        std_lat = getattr(m, "std_latency_ms", 0.0)
        med_lat = getattr(m, "median_latency_ms", mean_lat)
        min_lat = getattr(m, "min_latency_ms", 0.0)
        max_lat = getattr(m, "max_latency_ms", 0.0)
        ci_lat = getattr(m, "ci95_latency_ms", 0.0)
        mean_dam = getattr(m, "mean_files_damaged", 0.0)
        std_dam = getattr(m, "std_files_damaged", 0.0)
        mean_prev = getattr(m, "mean_ops_prevented_pct", 0.0)
        mean_cpu = getattr(m, "mean_cpu_percent", 0.0)
        mean_mem = getattr(m, "mean_memory_mb", 0.0)

        matrix_rows.append({
            "Detector Configuration": cfg_key.replace("_", " ").title(),
            "Completed Trials": getattr(m, "total_runs", 0),
            "True Positives (TP)": getattr(m, "true_positives", 0),
            "False Positives (FP)": getattr(m, "false_positives", 0),
            "True Negatives (TN)": getattr(m, "true_negatives", 0),
            "False Negatives (FN)": getattr(m, "false_negatives", 0),
            "Precision": p_str,
            "Recall": r_str,
            "F1-Score": f_str,
            "False Positive Rate (FPR)": fpr_str,
            "Mean Latency (ms)": f"{mean_lat:.1f} ± {std_lat:.1f} ms" if std_lat > 0 else f"{mean_lat:.1f} ms",
            "Median Latency (ms)": f"{med_lat:.1f} ms",
            "95% CI Latency": f"± {ci_lat:.1f} ms" if ci_lat > 0 else "-",
            "Latency Range [Min, Max]": f"[{min_lat:.1f}, {max_lat:.1f}] ms",
            "Avg Files Damaged": f"{mean_dam:.1f} ± {std_dam:.1f}" if std_dam > 0 else f"{mean_dam:.1f}",
            "Prevented Ops (%)": f"{mean_prev:.1f}%",
            "CPU Overhead (%)": f"{mean_cpu:.1f}%",
            "Memory (MB)": f"{mean_mem:.1f} MB",
        })

    df_matrix = pd.DataFrame(matrix_rows)
    st.dataframe(df_matrix, use_container_width=True)

    # Export CSV, Markdown Report, and ZIP Downloads
    exp_c1, exp_c2, exp_c3, exp_c4 = st.columns(4)
    with exp_c1:
        csv_metrics = df_matrix.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Export Metrics (CSV)",
            data=csv_metrics,
            file_name="canary_sentinel_metrics_summary.csv",
            mime="text/csv",
            use_container_width=True,
        )
    with exp_c2:
        markdown_summary = metrics_calc.generate_markdown_summary().encode("utf-8")
        st.download_button(
            label="📄 Research Summary (MD)",
            data=markdown_summary,
            file_name="CANARY_SENTINEL_RESEARCH_SUMMARY.md",
            mime="text/markdown",
            use_container_width=True,
        )
    with exp_c3:
        proj_zip_path = Path("CanarySentinel.zip")
        if proj_zip_path.exists():
            with open(proj_zip_path, "rb") as zf:
                st.download_button(
                    label="📦 Full Project (ZIP)",
                    data=zf.read(),
                    file_name="CanarySentinel.zip",
                    mime="application/zip",
                    use_container_width=True,
                )
    with exp_c4:
        dossier_zip_path = Path("CanarySentinel_Research_Dossier.zip")
        if dossier_zip_path.exists():
            with open(dossier_zip_path, "rb") as zf:
                st.download_button(
                    label="📑 Research Dossier (ZIP)",
                    data=zf.read(),
                    file_name="CanarySentinel_Research_Dossier.zip",
                    mime="application/zip",
                    use_container_width=True,
                )

    st.markdown("---")

    # Scenario-Level Empirical Breakdown Table
    st.subheader("📋 Scenario-Level Empirical Breakdown")
    st.caption("Validates how each detector handles individual benign vs suspicious scenarios across all completed trials.")
    breakdown = getattr(report, "scenario_breakdown", [])
    if breakdown:
        sc_rows = []
        for row in breakdown:
            lat_display = f"{row.mean_latency_ms:.1f} ms" if row.mean_latency_ms > 0 else "-"
            sc_rows.append({
                "Scenario Name": row.scenario_name,
                "Category": row.scenario_type.upper(),
                "Detector": row.detector_config.replace("_", " ").title(),
                "Completed Trials": row.total_runs,
                "Detection Rate": f"{row.detection_rate:.1%}",
                "Mean Latency": lat_display,
                "Avg Damaged Files": f"{row.mean_files_damaged:.1f}",
                "Prevented Ops %": f"{row.mean_ops_prevented_pct:.1f}%",
                "Expected Target": row.expected_outcome,
                "Empirical Verdict": row.empirical_status,
            })
        df_sc = pd.DataFrame(sc_rows)
        st.dataframe(df_sc, use_container_width=True)

        csv_sc = df_sc.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Export Scenario Breakdown to CSV",
            data=csv_sc,
            file_name="canary_sentinel_scenario_breakdown.csv",
            mime="text/csv",
        )

    st.markdown("---")

    # Confusion Matrix Cards
    st.subheader("🧮 Confusion Matrix Breakdown by Detector")
    cm_c1, cm_c2, cm_c3 = st.columns(3)

    for col, cfg_key in zip([cm_c1, cm_c2, cm_c3], ["baseline", "canary_only", "hybrid"]):
        m = report.metrics_by_detector[cfg_key]
        with col:
            st.markdown(f"**{cfg_key.replace('_', ' ').title()} Detector**")
            cm_df = pd.DataFrame(
                [
                    {"Actual \\ Predicted": "Actual Attack (Suspicious)", "Predicted Attack (Positive)": f"TP: {m.true_positives}", "Predicted Normal (Negative)": f"FN: {m.false_negatives}"},
                    {"Actual \\ Predicted": "Actual Normal (Benign)", "Predicted Attack (Positive)": f"FP: {m.false_positives}", "Predicted Normal (Negative)": f"TN: {m.true_negatives}"},
                ]
            )
            st.dataframe(cm_df, hide_index=True, use_container_width=True)

    st.markdown("---")

    # Visual Comparative Charts
    st.subheader("📈 Visual Metric Comparisons")
    ch_col1, ch_col2 = st.columns(2)

    with ch_col1:
        st.markdown("**Detection Quality: Precision, Recall, F1 & FPR**")
        q_data = []
        for cfg_key in ["baseline", "canary_only", "hybrid"]:
            m = report.metrics_by_detector[cfg_key]
            dname = cfg_key.replace("_", " ").title()
            if m.precision is not None:
                q_data.append({"Detector": dname, "Metric": "Precision", "Score": m.precision})
            if m.recall is not None:
                q_data.append({"Detector": dname, "Metric": "Recall", "Score": m.recall})
            if m.f1_score is not None:
                q_data.append({"Detector": dname, "Metric": "F1-Score", "Score": m.f1_score})
            if m.false_positive_rate is not None:
                q_data.append({"Detector": dname, "Metric": "False Positive Rate (FPR)", "Score": m.false_positive_rate})
        df_q = pd.DataFrame(q_data)
        st.bar_chart(df_q, x="Detector", y="Score", color="Metric", use_container_width=True)

    with ch_col2:
        st.markdown("**Damage Containment & Latency Trade-off**")
        d_data = []
        for cfg_key in ["baseline", "canary_only", "hybrid"]:
            m = report.metrics_by_detector[cfg_key]
            dname = cfg_key.replace("_", " ").title()
            d_data.append({"Detector": dname, "Metric": "Mean Files Damaged", "Value": getattr(m, "mean_files_damaged", 0.0)})
            d_data.append({"Detector": dname, "Metric": "Latency / 10 (ms)", "Value": getattr(m, "mean_latency_ms", 0.0) / 10.0})
            d_data.append({"Detector": dname, "Metric": "Ops Prevented / 10 (%)", "Value": getattr(m, "mean_ops_prevented_pct", 0.0) / 10.0})
        df_d = pd.DataFrame(d_data)
        st.bar_chart(df_d, x="Detector", y="Value", color="Metric", use_container_width=True)

    st.markdown("---")

    # Explanations of Metric Definitions & Limitations
    st.subheader("📖 Metric Definitions & Research Limitations")
    st.markdown("""
- **Precision** $\\left(\\frac{\\text{TP}}{\\text{TP} + \\text{FP}}\\right)$: Proportion of generated alerts that correspond to true ransomware behavior. High precision avoids alarm fatigue.
- **Recall (Sensitivity)** $\\left(\\frac{\\text{TP}}{\\text{TP} + \\text{FN}}\\right)$: Proportion of actual attacks detected.
- **F1-Score** $\\left(2 \\cdot \\frac{P \\cdot R}{P + R}\\right)$: Harmonic mean balancing precision and recall.
- **False Positive Rate (FPR)** $\\left(\\frac{\\text{FP}}{\\text{FP} + \\text{TN}}\\right)$: Probability that a legitimate benign scenario incorrectly triggers an alert.
- **Methodological Limitations**:
  - The prototype evaluates simulated, non-destructive file operations in a contained sandbox; kernel-level driver evasion techniques are not represented.
  - The Canary-Only detector trips when benign desktop indexers or scanners inspect decoy files. Hybrid requires contextual confirmation, reducing false positives to 0% in this evaluation.
  - In attacks that completely avoid canary decoys (`rapid_bulk_without_canary`), Baseline's volume heuristic succeeds while Canary-dependent configurations require strategic decoy placement.
""")


def main() -> None:
    services = get_sentinel_services()
    nav_choice = render_sidebar(services)

    if nav_choice == "Overview & Telemetry":
        render_overview(services)
    elif nav_choice == "Decoy & Sandbox Controls":
        render_sandbox_controls(services)
    elif nav_choice == "Live Event Stream":
        render_events(services)
    elif nav_choice == "Incidents & Evidence Alerts":
        render_alerts(services)
    elif nav_choice == "Simulation & Experiments":
        render_experiments(services)
    elif nav_choice == "Comparative Research Analysis":
        render_research_analysis(services)


if __name__ == "__main__":
    main()
