"""Canary decoy management package."""

from canary_sentinel.canary.manager import CanaryManager

__all__ = ["CanaryManager"]

