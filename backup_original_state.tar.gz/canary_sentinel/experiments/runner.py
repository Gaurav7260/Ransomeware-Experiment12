"""Experiment runner for reproducible benchmarking of detection configurations."""

import logging
import os
import time
import uuid
from typing import Callable, Dict, List, Optional

import psutil

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.detection.base import BaseDetector
from canary_sentinel.detection.baseline_detector import BaselineDetector
from canary_sentinel.detection.canary_detector import CanaryDetector
from canary_sentinel.detection.hybrid_detector import HybridDetector
from canary_sentinel.monitoring.monitor import FilesystemMonitor
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.simulation.simulator import ActivitySimulator, SimulationResult
from canary_sentinel.storage.db import Database
from canary_sentinel.storage.models import (
    AlertRecord,
    NormalizedEvent,
    ScenarioRecord,
    SystemMetricsRecord,
)

logger = logging.getLogger(__name__)


class ExperimentRunner:
    """Orchestrates controlled, reproducible trials comparing detector configurations."""

    def __init__(
        self,
        sandbox: SandboxManager,
        db: Database,
        canary_manager: CanaryManager,
        monitor: FilesystemMonitor,
        simulator: ActivitySimulator,
        response_manager: SimulatedResponseManager,
    ):
        self.sandbox = sandbox
        self.db = db
        self.canary_manager = canary_manager
        self.monitor = monitor
        self.simulator = simulator
        self.response_manager = response_manager
        self._current_process = psutil.Process(os.getpid())

    def create_detector(self, detector_config: str) -> BaseDetector:
        """Instantiate a clean detector instance."""
        if detector_config == "baseline":
            return BaselineDetector()
        elif detector_config == "canary_only":
            return CanaryDetector()
        elif detector_config == "hybrid":
            return HybridDetector()
        else:
            raise ValueError(f"Unknown detector config: {detector_config}")

    def run_trial(
        self,
        scenario_key: str,
        detector_config: str,
        trial_id: Optional[str] = None,
    ) -> ScenarioRecord:
        """Execute a single scenario trial against a designated detector configuration."""
        scenario_id = trial_id or f"{detector_config}_{scenario_key}_{uuid.uuid4().hex[:6]}"

        # 1. Reset state
        self.sandbox.reset_sandbox()
        self.canary_manager.deploy_canaries()
        # Pre-seed sandbox with standard user document files across directories
        self.simulator.helper.create_user_files(count=6, directory="documents")
        self.simulator.helper.create_user_files(count=6, directory="projects")
        self.simulator.helper.create_user_files(count=6, directory="finance")
        # Allow deployment filesystem events to settle
        time.sleep(0.18)

        self.response_manager.reset()
        detector = self.create_detector(detector_config)

        # Alerts and timing captured in this trial
        captured_alerts: List[AlertRecord] = []
        trial_start_time = time.time()

        # 2. Wire event pipeline for this trial
        def event_handler(event: NormalizedEvent) -> None:
            # Ignore stale deployment events that occurred before trial started
            if event.timestamp < trial_start_time:
                return

            # Ensure event is linked to this scenario
            event.scenario_id = scenario_id
            self.db.save_event(event)

            # Evaluate through detector
            decision = detector.process_event(event)
            if decision and decision.alert and not captured_alerts:
                alert = decision.alert
                alert.scenario_id = scenario_id
                captured_alerts.append(alert)
                self.db.save_alert(alert)

                # Trigger response containment
                self.response_manager.evaluate_and_respond(alert)

        # Register callback with monitor
        self.monitor.register_callback(event_handler)
        self.monitor.set_active_scenario_id(scenario_id)

        # Sample initial system metrics
        cpu_pre = self._current_process.cpu_percent(interval=None)
        mem_pre = self._current_process.memory_info().rss / (1024 * 1024)

        try:
            # 3. Execute scenario
            sim_result = self.simulator.run_scenario(
                scenario_key=scenario_key,
                scenario_id=scenario_id,
            )

            # Allow brief settling window for OS filesystem events to drain
            time.sleep(0.15)

        finally:
            # Cleanup callback
            self.monitor.unregister_callback(event_handler)
            self.monitor.set_active_scenario_id(None)

        trial_end_time = time.time()

        # Sample post system metrics
        cpu_post = self._current_process.cpu_percent(interval=None)
        mem_post = self._current_process.memory_info().rss / (1024 * 1024)
        avg_cpu = max(cpu_pre, cpu_post)
        avg_mem = max(mem_pre, mem_post)

        self.db.save_system_metrics(
            SystemMetricsRecord(
                timestamp=trial_end_time,
                cpu_percent=avg_cpu,
                memory_mb=avg_mem,
                scenario_id=scenario_id,
            )
        )

        detected = len(captured_alerts) > 0
        latency_ms: Optional[float] = None
        alert_id: Optional[str] = None

        if detected:
            first_alert = captured_alerts[0]
            alert_id = first_alert.alert_id
            latency_ms = max(1.0, (first_alert.timestamp - trial_start_time) * 1000.0)

        record = ScenarioRecord(
            scenario_id=scenario_id,
            scenario_name=sim_result.scenario_name,
            scenario_type=sim_result.category,
            detector_config=detector_config,
            start_time=trial_start_time,
            end_time=trial_end_time,
            duration_ms=(trial_end_time - trial_start_time) * 1000.0,
            planned_ops=sim_result.planned_ops,
            executed_ops=sim_result.executed_ops,
            prevented_ops=sim_result.prevented_ops,
            files_damaged=sim_result.files_damaged,
            detected=detected,
            detection_latency_ms=latency_ms,
            response_triggered=sim_result.response_triggered,
            alert_id=alert_id,
        )

        self.db.save_scenario(record)
        return record

    def run_benchmark_suite(
        self,
        iterations: int = 1,
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
    ) -> List[ScenarioRecord]:
        """Run all 6 scenarios across all 3 detector configurations.

        Total runs = 6 scenarios * 3 detectors * iterations = 18 * iterations trials.
        """
        scenarios = list(self.simulator.SCENARIO_CATALOG.keys())
        detectors = ["baseline", "canary_only", "hybrid"]
        total_trials = len(scenarios) * len(detectors) * iterations

        records: List[ScenarioRecord] = []
        completed = 0

        # Ensure monitor is running
        was_running = self.monitor.is_running
        if not was_running:
            self.monitor.start()

        try:
            for it in range(iterations):
                for det in detectors:
                    for sc in scenarios:
                        desc = f"Iteration {it + 1}/{iterations} | Detector: {det} | Scenario: {sc}"
                        if progress_callback:
                            progress_callback(completed, total_trials, desc)

                        rec = self.run_trial(scenario_key=sc, detector_config=det)
                        records.append(rec)
                        completed += 1

                        if progress_callback:
                            progress_callback(completed, total_trials, desc)

                        time.sleep(0.05)
        finally:
            if not was_running:
                self.monitor.stop()

        return records
