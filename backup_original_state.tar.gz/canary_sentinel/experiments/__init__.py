"""Experiments and metrics package for CanarySentinel."""

from canary_sentinel.experiments.metrics import ComparisonReport, DetectorMetrics, MetricsCalculator
from canary_sentinel.experiments.runner import ExperimentRunner

__all__ = [
    "ExperimentRunner",
    "MetricsCalculator",
    "DetectorMetrics",
    "ComparisonReport",
]

