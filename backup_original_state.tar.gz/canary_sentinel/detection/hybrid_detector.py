"""Configuration C: Hybrid Detector (Canary + Contextual Behavior)."""

from typing import List, Optional

from canary_sentinel.core.config import HybridConfig
from canary_sentinel.detection.base import BaseDetector, DetectionDecision
from canary_sentinel.detection.risk_engine import RiskEngine
from canary_sentinel.storage.models import NormalizedEvent


class HybridDetector(BaseDetector):
    """Requires both a canary interaction and contextual filesystem evidence within an observation window."""

    def __init__(self, config: Optional[HybridConfig] = None):
        cfg = config or HybridConfig()
        super().__init__(config_name="hybrid", window_seconds=cfg.observation_window_seconds * 2)
        self.observation_window = cfg.observation_window_seconds
        self.min_context_events = cfg.min_context_events
        self.burst_velocity_threshold = cfg.burst_velocity_threshold
        self.entropy_threshold = cfg.entropy_threshold
        self.base_risk_score = cfg.base_risk_score

        # Candidate canary touch awaiting contextual confirmation
        self._pending_canary_event: Optional[NormalizedEvent] = None
        self._alert_dispatched_for_breach = False

    def reset(self) -> None:
        super().reset()
        self._pending_canary_event = None
        self._alert_dispatched_for_breach = False

    def _evaluate_context(
        self,
        canary_event: NormalizedEvent,
        current_event: NormalizedEvent,
    ) -> Optional[DetectionDecision]:
        """Check if events surrounding canary touch satisfy contextual evidence requirements."""
        # Find all non-canary events within observation window of the canary touch
        window_start = canary_event.timestamp - self.observation_window
        window_end = canary_event.timestamp + self.observation_window

        relevant_events = [
            e for e in self.history
            if window_start <= e.timestamp <= window_end
        ]

        non_canary_events = [e for e in relevant_events if not e.is_canary]
        unique_targets = {e.path for e in non_canary_events}
        high_entropy_events = [e for e in non_canary_events if e.entropy >= self.entropy_threshold]

        time_span = max(0.1, max(e.timestamp for e in relevant_events) - min(e.timestamp for e in relevant_events))
        velocity = len(relevant_events) / time_span

        reasons: List[str] = []
        context_confirmed = False

        # Criterion 1: High-entropy payload writes on companion user files (simulated encryption)
        if high_entropy_events and len(unique_targets) >= 2:
            reasons.append(
                f"High-entropy modification on {len(high_entropy_events)} companion file(s) (entropy >= {self.entropy_threshold:.1f})"
            )
            context_confirmed = True

        # Criterion 2: High velocity across multiple companion user files
        if len(non_canary_events) >= 4 and len(unique_targets) >= 3 and velocity >= self.burst_velocity_threshold:
            reasons.append(
                f"Elevated operation velocity: {velocity:.1f} ops/sec across {len(unique_targets)} companion files"
            )
            context_confirmed = True

        # Criterion 3: Substantial mass file churn sequence
        if len(non_canary_events) >= 6 and len(unique_targets) >= 4:
            reasons.append(
                f"Multi-file modification sequence: {len(non_canary_events)} operations across {len(unique_targets)} files"
            )
            context_confirmed = True

        if context_confirmed and not self._alert_dispatched_for_breach:
            self._alert_dispatched_for_breach = True
            reasons.insert(
                0,
                f"Canary file breached: '{canary_event.path}' ({canary_event.event_type}) confirmed by contextual filesystem damage"
            )

            risk_score = min(100, self.base_risk_score + int(velocity * 2))
            confidence = 0.98

            supporting = [e for e in relevant_events if e.event_id != current_event.event_id]

            alert = RiskEngine.create_alert(
                detector_config=self.config_name,
                risk_score=risk_score,
                confidence=confidence,
                triggering_event=current_event,
                supporting_events=supporting,
                reasons=reasons,
                scenario_id=current_event.scenario_id,
            )

            return DetectionDecision(
                is_suspicious=True,
                detector_config=self.config_name,
                risk_score=risk_score,
                confidence=confidence,
                severity=alert.severity,
                triggering_event=current_event,
                supporting_events=supporting,
                reasons=reasons,
                explanation=alert.explanation,
                alert=alert,
            )

        return None

    def process_event(self, event: NormalizedEvent) -> Optional[DetectionDecision]:
        self._prune_history(event.timestamp)
        self.history.append(event)

        # Case 1: Canary file touched
        if event.is_canary and event.event_type in ("MODIFY", "DELETE", "MOVE"):
            self._pending_canary_event = event
            # Check if recent past context already satisfies threshold
            return self._evaluate_context(canary_event=event, current_event=event)

        # Case 2: Non-canary event arrives while canary breach is active within window
        if self._pending_canary_event is not None:
            delta = event.timestamp - self._pending_canary_event.timestamp
            if 0 <= delta <= self.observation_window:
                decision = self._evaluate_context(
                    canary_event=self._pending_canary_event,
                    current_event=event,
                )
                if decision:
                    return decision
            elif delta > self.observation_window:
                # Observation window expired without suspicious context -> isolated touch
                self._pending_canary_event = None

        return None
