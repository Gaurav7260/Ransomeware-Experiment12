"""Configuration B: Canary-Only Detector."""

from typing import List, Optional

from canary_sentinel.core.config import CanaryOnlyConfig
from canary_sentinel.detection.base import BaseDetector, DetectionDecision
from canary_sentinel.detection.risk_engine import RiskEngine
from canary_sentinel.storage.models import NormalizedEvent


class CanaryDetector(BaseDetector):
    """Generates an alert whenever a protected canary decoy file is touched."""

    def __init__(self, config: Optional[CanaryOnlyConfig] = None):
        cfg = config or CanaryOnlyConfig()
        super().__init__(config_name="canary_only", window_seconds=5.0)
        self.monitored_events = set(cfg.monitored_events)
        self.base_risk_score = cfg.base_risk_score

    def process_event(self, event: NormalizedEvent) -> Optional[DetectionDecision]:
        self._prune_history(event.timestamp)
        self.history.append(event)

        # Triggers strictly on canary interactions
        if not event.is_canary:
            return None

        if event.event_type not in self.monitored_events:
            return None

        reasons: List[str] = [
            f"Tripwire breach: Decoy canary file '{event.path}' received unauthorized {event.event_type} action",
            f"Protected asset tampered with (size: {event.size_bytes}B, entropy: {event.entropy:.2f})",
        ]

        risk_score = self.base_risk_score
        confidence = 0.85

        supporting = [e for e in self.history if e.event_id != event.event_id]

        alert = RiskEngine.create_alert(
            detector_config=self.config_name,
            risk_score=risk_score,
            confidence=confidence,
            triggering_event=event,
            supporting_events=supporting,
            reasons=reasons,
            scenario_id=event.scenario_id,
        )

        return DetectionDecision(
            is_suspicious=True,
            detector_config=self.config_name,
            risk_score=risk_score,
            confidence=confidence,
            severity=alert.severity,
            triggering_event=event,
            supporting_events=supporting,
            reasons=reasons,
            explanation=alert.explanation,
            alert=alert,
        )

