"""Configuration A: Baseline Behavior Detector."""

from typing import List, Optional, Set

from canary_sentinel.core.config import BaselineConfig
from canary_sentinel.detection.base import BaseDetector, DetectionDecision
from canary_sentinel.detection.risk_engine import RiskEngine
from canary_sentinel.storage.models import NormalizedEvent


class BaselineDetector(BaseDetector):
    """Detects suspicious file operation volume, burst rates, and sequences without relying on canaries."""

    SUSPICIOUS_EXTENSIONS = {".locked", ".crypto", ".enc", ".crypted", ".ransom", ".encrypted"}

    def __init__(self, config: Optional[BaselineConfig] = None):
        cfg = config or BaselineConfig()
        super().__init__(config_name="baseline", window_seconds=cfg.burst_window_seconds)
        self.burst_window = cfg.burst_window_seconds
        self.burst_threshold = cfg.burst_count_threshold
        self.entropy_threshold = cfg.entropy_threshold
        self.mass_rename_threshold = cfg.mass_rename_threshold
        self.base_risk_score = cfg.base_risk_score

    def process_event(self, event: NormalizedEvent) -> Optional[DetectionDecision]:
        self._prune_history(event.timestamp)
        self.history.append(event)

        # Baseline ignores canary status completely (fair comparison rule)
        window_events = [e for e in self.history if (event.timestamp - e.timestamp) <= self.burst_window]
        total_ops = len(window_events)

        unique_files: Set[str] = {e.path for e in window_events}
        mod_or_create_ops = [e for e in window_events if e.event_type in ("CREATE", "MODIFY")]
        rename_ops = [e for e in window_events if e.event_type == "MOVE"]
        high_entropy_events = [e for e in mod_or_create_ops if e.entropy >= self.entropy_threshold]

        reasons: List[str] = []
        risk_score = 0
        confidence = 0.0

        # Heuristic 1: Rapid file operation burst
        if total_ops >= self.burst_threshold and len(unique_files) >= 3:
            velocity = total_ops / max(0.1, self.burst_window)
            reasons.append(
                f"Abnormal file burst rate: {total_ops} operations across {len(unique_files)} files in {self.burst_window:.1f}s ({velocity:.1f} ops/sec)"
            )
            risk_score += 45
            confidence += 0.40

        # Heuristic 2: High entropy file modification surge
        if high_entropy_events:
            reasons.append(
                f"High-entropy modification detected on {len(high_entropy_events)} file(s) (entropy >= {self.entropy_threshold:.1f})"
            )
            risk_score += 35
            confidence += 0.30

        # Heuristic 3: Suspicious extensions or mass renaming
        if len(rename_ops) >= self.mass_rename_threshold:
            reasons.append(
                f"Mass file renaming sequence: {len(rename_ops)} rename operations within {self.burst_window:.1f}s"
            )
            risk_score += 30
            confidence += 0.25

        if event.extension in self.SUSPICIOUS_EXTENSIONS:
            reasons.append(f"Suspicious known ransomware-like extension detected: '{event.extension}'")
            risk_score += 35
            confidence += 0.30

        # Trigger alert if threshold exceeded
        if risk_score >= self.base_risk_score:
            confidence = min(0.95, confidence)
            supporting = [e for e in window_events if e.event_id != event.event_id]

            alert = RiskEngine.create_alert(
                detector_config=self.config_name,
                risk_score=risk_score,
                confidence=confidence,
                triggering_event=event,
                supporting_events=supporting,
                reasons=reasons,
                scenario_id=event.scenario_id,
            )

            return DetectionDecision(
                is_suspicious=True,
                detector_config=self.config_name,
                risk_score=risk_score,
                confidence=confidence,
                severity=alert.severity,
                triggering_event=event,
                supporting_events=supporting,
                reasons=reasons,
                explanation=alert.explanation,
                alert=alert,
            )

        return None

