"""Base detector interface and decision models."""

import collections
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Deque, List, Optional

from canary_sentinel.storage.models import AlertRecord, NormalizedEvent


@dataclass
class DetectionDecision:
    """Represents a detector's evaluation of an event stream."""

    is_suspicious: bool
    detector_config: str  # "baseline", "canary_only", "hybrid"
    risk_score: int  # 0 to 100
    confidence: float  # 0.0 to 1.0
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    triggering_event: NormalizedEvent
    supporting_events: List[NormalizedEvent] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    explanation: str = ""
    alert: Optional[AlertRecord] = None


class BaseDetector(ABC):
    """Abstract base class for all detection configurations."""

    def __init__(self, config_name: str, window_seconds: float = 5.0):
        self.config_name = config_name
        self.window_seconds = window_seconds
        # Sliding history of events within window_seconds
        self.history: Deque[NormalizedEvent] = collections.deque()

    def _prune_history(self, current_time: float) -> None:
        """Prune events older than the observation window."""
        cutoff = current_time - self.window_seconds
        while self.history and self.history[0].timestamp < cutoff:
            self.history.popleft()

    def reset(self) -> None:
        """Clear detector state and event history."""
        self.history.clear()

    @abstractmethod
    def process_event(self, event: NormalizedEvent) -> Optional[DetectionDecision]:
        """Evaluate an incoming event against detection rules.

        Returns:
            DetectionDecision if an alert condition is reached, else None.
        """
        pass

