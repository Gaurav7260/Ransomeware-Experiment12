"""Transparent risk and severity engine for CanarySentinel."""

import uuid
from typing import Any, Dict, List, Optional

from canary_sentinel.core.utils import get_iso_timestamp
from canary_sentinel.storage.models import AlertRecord, NormalizedEvent


class RiskEngine:
    """Calculates risk scores, severities, and evidence-backed explanations."""

    SEVERITY_LEVELS = [
        (90, "CRITICAL"),
        (70, "HIGH"),
        (35, "MEDIUM"),
        (0, "LOW"),
    ]

    @classmethod
    def determine_severity(cls, risk_score: int) -> str:
        """Map numeric risk score (0-100) to severity category."""
        for threshold, label in cls.SEVERITY_LEVELS:
            if risk_score >= threshold:
                return label
        return "LOW"

    @classmethod
    def build_alert_explanation(
        cls,
        detector_name: str,
        triggering_event: NormalizedEvent,
        reasons: List[str],
        supporting_events: List[NormalizedEvent],
        risk_score: int,
        severity: str,
    ) -> str:
        """Construct a structured, transparent, human-readable explanation."""
        lines = [
            f"=== {detector_name.upper()} DETECTOR ALERT ({severity}) ===",
            f"Risk Score: {risk_score}/100 | Severity: {severity}",
            f"Triggering Action: {triggering_event.event_type} on '{triggering_event.path}' "
            f"(Entropy: {triggering_event.entropy:.2f}, Size: {triggering_event.size_bytes}B, Canary: {triggering_event.is_canary})",
            "",
            "Identified Risk Factors:",
        ]
        for r in reasons:
            lines.append(f"  • {r}")

        if supporting_events:
            lines.append("")
            lines.append(f"Correlated Contextual Evidence ({len(supporting_events)} events):")
            for ev in supporting_events[-5:]:  # show up to 5 most recent
                canary_flag = "[CANARY] " if ev.is_canary else ""
                lines.append(
                    f"  - [{ev.event_type}] {canary_flag}{ev.path} "
                    f"(entropy={ev.entropy:.2f}, delta_t={triggering_event.timestamp - ev.timestamp:.2f}s)"
                )
            if len(supporting_events) > 5:
                lines.append(f"  ... and {len(supporting_events) - 5} additional prior events in window.")

        lines.append("")
        lines.append(f"Action Recommendation: Intercept and prevent subsequent operations.")
        return "\n".join(lines)

    @classmethod
    def create_alert(
        cls,
        detector_config: str,
        risk_score: int,
        confidence: float,
        triggering_event: NormalizedEvent,
        supporting_events: List[NormalizedEvent],
        reasons: List[str],
        response_status: str = "NONE",
        scenario_id: Optional[str] = None,
    ) -> AlertRecord:
        """Instantiate a fully populated AlertRecord."""
        bounded_score = max(0, min(100, int(risk_score)))
        severity = cls.determine_severity(bounded_score)
        explanation = cls.build_alert_explanation(
            detector_name=detector_config,
            triggering_event=triggering_event,
            reasons=reasons,
            supporting_events=supporting_events,
            risk_score=bounded_score,
            severity=severity,
        )

        summary = f"{triggering_event.event_type} on '{triggering_event.path}'"
        if triggering_event.is_canary:
            summary = f"[CANARY TOUCH] {summary}"

        return AlertRecord(
            alert_id=str(uuid.uuid4()),
            timestamp=triggering_event.timestamp,
            iso_timestamp=triggering_event.iso_timestamp,
            detector_config=detector_config,
            severity=severity,
            risk_score=bounded_score,
            confidence=round(confidence, 2),
            triggering_event_id=triggering_event.event_id,
            triggering_event_summary=summary,
            supporting_event_ids=[e.event_id for e in supporting_events],
            explanation=explanation,
            response_status=response_status,
            scenario_id=scenario_id or triggering_event.scenario_id,
        )

