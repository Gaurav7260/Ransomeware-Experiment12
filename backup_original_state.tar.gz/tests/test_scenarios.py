"""Automated tests for harmless simulation scenarios and experiment runner."""

import tempfile
from pathlib import Path

import pytest

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.experiments.runner import ExperimentRunner
from canary_sentinel.monitoring.monitor import FilesystemMonitor
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.simulation.simulator import ActivitySimulator
from canary_sentinel.storage.db import Database


@pytest.fixture
def sim_env():
    with tempfile.TemporaryDirectory() as tmpdir:
        sandbox = SandboxManager(Path(tmpdir) / "sandbox")
        db = Database(Path(tmpdir) / "test.db")
        canary_mgr = CanaryManager(sandbox, db)
        normalizer = EventNormalizer(sandbox, canary_mgr)
        monitor = FilesystemMonitor(sandbox, normalizer)
        resp_mgr = SimulatedResponseManager()
        simulator = ActivitySimulator(sandbox, canary_mgr, resp_mgr)
        runner = ExperimentRunner(sandbox, db, canary_mgr, monitor, simulator, resp_mgr)

        monitor.start()
        yield sandbox, db, canary_mgr, simulator, runner
        monitor.stop()


def test_scenario_normal_editing(sim_env):
    sandbox, db, canary_mgr, simulator, runner = sim_env
    res = simulator.run_scenario("normal_file_editing")
    assert res.category == "benign"
    assert res.executed_ops == 5
    assert res.prevented_ops == 0
    assert res.files_damaged == 0


def test_scenario_bulk_copying(sim_env):
    sandbox, db, canary_mgr, simulator, runner = sim_env
    res = simulator.run_scenario("bulk_copying")
    assert res.category == "benign"
    assert res.executed_ops == 6
    assert res.files_damaged == 0


def test_scenario_bulk_renaming(sim_env):
    sandbox, db, canary_mgr, simulator, runner = sim_env
    res = simulator.run_scenario("bulk_renaming")
    assert res.category == "benign"
    assert res.executed_ops == 6
    assert res.files_damaged == 0


def test_scenario_canary_touch_benign(sim_env):
    sandbox, db, canary_mgr, simulator, runner = sim_env
    res = simulator.run_scenario("canary_touch_benign")
    assert res.category == "benign"
    assert res.executed_ops == 4
    assert res.files_damaged == 0


def test_scenario_canary_plus_rapid_bulk_trial(sim_env):
    """Run trial through ExperimentRunner with hybrid detector."""
    sandbox, db, canary_mgr, simulator, runner = sim_env
    record = runner.run_trial(scenario_key="canary_plus_rapid_bulk", detector_config="hybrid")

    assert record.scenario_type == "suspicious"
    assert record.detected is True
    assert record.response_triggered is True
    assert record.prevented_ops > 0
    assert record.detection_latency_ms is not None

