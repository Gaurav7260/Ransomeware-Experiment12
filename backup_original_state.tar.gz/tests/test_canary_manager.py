"""Automated tests for Canary Manager."""

import tempfile
from pathlib import Path

import pytest

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.config import CanaryConfig
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.storage.db import Database


@pytest.fixture
def test_setup():
    with tempfile.TemporaryDirectory() as tmpdir:
        sandbox_path = Path(tmpdir) / "sandbox"
        db_path = Path(tmpdir) / "test.db"
        sandbox = SandboxManager(sandbox_path)
        db = Database(db_path)
        mgr = CanaryManager(sandbox, db, CanaryConfig(decoy_count=4))
        yield sandbox, db, mgr


def test_canary_deployment(test_setup):
    sandbox, db, mgr = test_setup
    deployed = mgr.deploy_canaries()

    assert len(deployed) == 4
    for record in deployed:
        assert mgr.is_canary(record.relative_path)
        abs_p = sandbox.validate_path(record.relative_path)
        assert abs_p.exists()
        assert abs_p.stat().st_size > 0


def test_canary_integrity_active(test_setup):
    sandbox, db, mgr = test_setup
    mgr.deploy_canaries()
    status_map = mgr.verify_integrity()

    assert len(status_map) == 4
    for status in status_map.values():
        assert status == "ACTIVE"


def test_canary_integrity_modified(test_setup):
    sandbox, db, mgr = test_setup
    deployed = mgr.deploy_canaries()

    # Modify one canary
    target_rel = deployed[0].relative_path
    target_abs = sandbox.validate_path(target_rel)
    with open(target_abs, "a") as f:
        f.write("\nTAMPERED BY TEST")

    status_map = mgr.verify_integrity()
    assert status_map[target_rel] == "MODIFIED"


def test_canary_integrity_deleted(test_setup):
    sandbox, db, mgr = test_setup
    deployed = mgr.deploy_canaries()

    target_rel = deployed[1].relative_path
    target_abs = sandbox.validate_path(target_rel)
    target_abs.unlink()

    status_map = mgr.verify_integrity()
    assert status_map[target_rel] == "DELETED"


def test_canary_cleanup(test_setup):
    sandbox, db, mgr = test_setup
    mgr.deploy_canaries()
    mgr.clear_canaries()

    assert len(mgr._canary_paths) == 0
    assert len(db.get_canaries()) == 0

