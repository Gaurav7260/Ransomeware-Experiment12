"""Tests package for CanarySentinel."""

