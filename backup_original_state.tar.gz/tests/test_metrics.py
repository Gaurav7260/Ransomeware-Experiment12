"""Automated tests for Metrics calculation and Comparison Report."""

import tempfile
from pathlib import Path

import pytest

from canary_sentinel.experiments.metrics import MetricsCalculator
from canary_sentinel.storage.db import Database
from canary_sentinel.storage.models import ScenarioRecord


@pytest.fixture
def test_db_with_scenarios():
    with tempfile.TemporaryDirectory() as tmpdir:
        db = Database(Path(tmpdir) / "test.db")

        # Add 2 suspicious scenarios detected (TP)
        db.save_scenario(
            ScenarioRecord(
                scenario_id="hybrid_canary_plus_rapid_bulk_01",
                scenario_name="Canary Touch + Rapid Bulk Modifications",
                scenario_type="suspicious",
                detector_config="hybrid",
                start_time=1.0,
                end_time=2.0,
                duration_ms=1000.0,
                planned_ops=10,
                executed_ops=4,
                prevented_ops=6,
                files_damaged=2,
                detected=True,
                detection_latency_ms=50.0,
                response_triggered=True,
            )
        )
        db.save_scenario(
            ScenarioRecord(
                scenario_id="hybrid_canary_plus_rapid_bulk_02",
                scenario_name="Canary Touch + Rapid Bulk Modifications",
                scenario_type="suspicious",
                detector_config="hybrid",
                start_time=2.0,
                end_time=3.0,
                duration_ms=1000.0,
                planned_ops=10,
                executed_ops=3,
                prevented_ops=7,
                files_damaged=1,
                detected=True,
                detection_latency_ms=60.0,
                response_triggered=True,
            )
        )

        # Add 2 benign scenarios NOT detected (TN)
        db.save_scenario(
            ScenarioRecord(
                scenario_id="hybrid_normal_file_editing_01",
                scenario_name="Normal File Editing",
                scenario_type="benign",
                detector_config="hybrid",
                start_time=3.0,
                end_time=4.0,
                duration_ms=1000.0,
                planned_ops=5,
                executed_ops=5,
                prevented_ops=0,
                files_damaged=0,
                detected=False,
                detection_latency_ms=None,
                response_triggered=False,
            )
        )

        yield db


def test_metrics_calculator_perfect_score(test_db_with_scenarios):
    calc = MetricsCalculator(test_db_with_scenarios)
    m = calc.calculate_for_detector("hybrid")

    assert m.true_positives == 2
    assert m.false_positives == 0
    assert m.true_negatives == 1
    assert m.false_negatives == 0
    assert m.precision == 1.0
    assert m.recall == 1.0
    assert m.f1_score == 1.0
    assert m.false_positive_rate == 0.0
    assert m.mean_latency_ms == 55.0
    assert m.median_latency_ms == 55.0
    assert m.std_latency_ms > 0.0
    assert m.mean_files_damaged == 1.5


def test_metrics_calculator_zero_division_safety():
    """Ensure no crash when no trials exist and undefined metrics are None."""
    with tempfile.TemporaryDirectory() as tmpdir:
        empty_db = Database(Path(tmpdir) / "empty.db")
        calc = MetricsCalculator(empty_db)
        m = calc.calculate_for_detector("baseline")

        # Undefined metrics should be None rather than invented zeros
        assert m.precision is None
        assert m.recall is None
        assert m.f1_score is None
        assert m.false_positive_rate is None
        assert m.total_runs == 0
        assert m.mean_latency_ms == 0.0


def test_scenario_breakdown_generation(test_db_with_scenarios):
    calc = MetricsCalculator(test_db_with_scenarios)
    breakdown = calc.calculate_scenario_breakdown()

    assert len(breakdown) > 0
    # Check canary_plus_rapid_bulk for hybrid
    matching = [b for b in breakdown if b.scenario_id == "canary_plus_rapid_bulk" and b.detector_config == "hybrid"]
    assert len(matching) == 1
    row = matching[0]
    assert row.total_runs == 2
    assert row.detected_count == 2
    assert row.detection_rate == 1.0
    assert "✅" in row.empirical_status


def test_markdown_summary_report_generation(test_db_with_scenarios):
    calc = MetricsCalculator(test_db_with_scenarios)
    summary = calc.generate_markdown_summary()

    assert "# CanarySentinel Empirical Research Summary" in summary
    assert "Comparative Performance Matrix" in summary
    assert "Scenario-Level Empirical Breakdown" in summary
