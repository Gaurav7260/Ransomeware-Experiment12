"""End-to-end integration tests for CanarySentinel."""

import tempfile
import time
from pathlib import Path

import pytest

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.config import CanaryConfig, ResponseConfig
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.experiments.metrics import MetricsCalculator
from canary_sentinel.experiments.runner import ExperimentRunner
from canary_sentinel.monitoring.monitor import FilesystemMonitor
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.simulation.simulator import ActivitySimulator
from canary_sentinel.storage.db import Database


def test_full_pipeline_flow():
    """Test the complete CanarySentinel execution pipeline:
    Sandbox initialization -> Canary deployment -> Filesystem monitoring ->
    Event normalization -> Detection -> Alert creation -> Simulated response ->
    SQLite storage -> Metrics calculation.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        sandbox_path = root / "sandbox"
        db_path = root / "test.db"

        sandbox = SandboxManager(sandbox_path)
        db = Database(db_path)
        canary_cfg = CanaryConfig()
        canary_mgr = CanaryManager(sandbox, db, canary_cfg)
        normalizer = EventNormalizer(sandbox, canary_mgr, debounce_ms=30)
        monitor = FilesystemMonitor(sandbox, normalizer)
        resp_cfg = ResponseConfig(auto_block=True, minimum_severity="HIGH", risk_score_threshold=70)
        response_mgr = SimulatedResponseManager(resp_cfg)
        simulator = ActivitySimulator(sandbox, canary_mgr, response_mgr)
        runner = ExperimentRunner(sandbox, db, canary_mgr, monitor, simulator, response_mgr)
        metrics_calc = MetricsCalculator(db)

        # 1. Start monitor
        monitor.start()
        try:
            # 2. Run single trial of suspicious scenario with Hybrid detector
            record = runner.run_trial(
                scenario_key="canary_plus_rapid_bulk",
                detector_config="hybrid",
                trial_id="integration_trial_hybrid_01",
            )

            # 3. Verify trial record
            assert record.detected is True
            assert record.alert_id is not None
            assert record.detection_latency_ms is not None
            assert record.detection_latency_ms > 0
            assert record.files_damaged < record.planned_ops
            assert record.prevented_ops > 0
            assert record.response_triggered is True

            # 4. Verify SQLite storage
            events = db.get_events()
            assert len(events) > 0

            alerts = db.get_alerts()
            assert len(alerts) >= 1
            alert = alerts[0]
            assert alert.detector_config == "hybrid"
            assert alert.severity in ["HIGH", "CRITICAL"]
            assert alert.risk_score >= 70

            scenarios = db.get_scenarios()
            assert len(scenarios) == 1

            # 5. Verify Metrics Calculation
            report = metrics_calc.generate_comparison_report()
            h_metrics = report.metrics_by_detector["hybrid"]
            assert h_metrics.total_runs == 1
            assert h_metrics.true_positives == 1
            assert h_metrics.precision == 1.0

        finally:
            monitor.stop()
