"""Automated tests for Risk Engine and Simulated Response Manager."""

import time
import uuid

import pytest

from canary_sentinel.core.config import ResponseConfig
from canary_sentinel.detection.risk_engine import RiskEngine
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.storage.models import AlertRecord, NormalizedEvent


def dummy_event() -> NormalizedEvent:
    return NormalizedEvent(
        event_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        event_type="MODIFY",
        path="documents/test.txt",
        extension=".txt",
        is_canary=False,
        size_bytes=512,
        entropy=4.2,
    )


def test_risk_engine_severity_mapping():
    assert RiskEngine.determine_severity(95) == "CRITICAL"
    assert RiskEngine.determine_severity(75) == "HIGH"
    assert RiskEngine.determine_severity(45) == "MEDIUM"
    assert RiskEngine.determine_severity(20) == "LOW"


def test_risk_engine_alert_creation():
    ev = dummy_event()
    alert = RiskEngine.create_alert(
        detector_config="baseline",
        risk_score=85,
        confidence=0.9,
        triggering_event=ev,
        supporting_events=[],
        reasons=["High file burst rate", "Entropy spike"],
    )

    assert alert.severity == "HIGH"
    assert alert.risk_score == 85
    assert "High file burst rate" in alert.explanation


def test_response_manager_blocks_on_high_alert():
    mgr = SimulatedResponseManager(ResponseConfig(auto_block=True, minimum_severity="HIGH"))
    assert mgr.is_blocked() is False

    ev = dummy_event()
    alert = AlertRecord(
        alert_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        detector_config="hybrid",
        severity="CRITICAL",
        risk_score=95,
        confidence=0.98,
        triggering_event_id=ev.event_id,
        triggering_event_summary="MODIFY on doc.txt",
        supporting_event_ids=[],
        explanation="Test alert",
        response_status="NONE",
    )

    triggered = mgr.evaluate_and_respond(alert)
    assert triggered is True
    assert mgr.is_blocked() is True
    assert alert.response_status == "BLOCKED"


def test_response_manager_ignores_low_severity():
    mgr = SimulatedResponseManager(ResponseConfig(auto_block=True, minimum_severity="HIGH"))

    ev = dummy_event()
    low_alert = AlertRecord(
        alert_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        detector_config="baseline",
        severity="LOW",
        risk_score=20,
        confidence=0.3,
        triggering_event_id=ev.event_id,
        triggering_event_summary="MODIFY on doc.txt",
        supporting_event_ids=[],
        explanation="Low risk",
        response_status="NONE",
    )

    triggered = mgr.evaluate_and_respond(low_alert)
    assert triggered is False
    assert mgr.is_blocked() is False


def test_response_manager_never_terminates_os_processes():
    """Verify that response manager strictly modifies internal state and never kills OS processes."""
    import os
    import psutil

    mgr = SimulatedResponseManager(ResponseConfig(auto_block=True, minimum_severity="HIGH"))
    current_pid = os.getpid()
    assert psutil.pid_exists(current_pid)

    ev = dummy_event()
    critical_alert = AlertRecord(
        alert_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        detector_config="hybrid",
        severity="CRITICAL",
        risk_score=100,
        confidence=1.0,
        triggering_event_id=ev.event_id,
        triggering_event_summary="Critical Alert",
        supporting_event_ids=[],
        explanation="Simulated critical ransomware alert",
        response_status="NONE",
    )

    # Trigger response
    triggered = mgr.evaluate_and_respond(critical_alert)
    assert triggered is True
    assert mgr.is_blocked() is True

    # Current process and system processes are completely unharmed
    assert psutil.pid_exists(current_pid)
    assert psutil.Process(current_pid).is_running()

