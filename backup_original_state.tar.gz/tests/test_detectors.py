"""Automated tests for Baseline, Canary-Only, and Hybrid Detectors."""

import time
import uuid

import pytest

from canary_sentinel.core.config import BaselineConfig, CanaryOnlyConfig, HybridConfig
from canary_sentinel.detection.baseline_detector import BaselineDetector
from canary_sentinel.detection.canary_detector import CanaryDetector
from canary_sentinel.detection.hybrid_detector import HybridDetector
from canary_sentinel.storage.models import NormalizedEvent


def make_event(
    path: str,
    event_type: str = "MODIFY",
    is_canary: bool = False,
    entropy: float = 4.0,
    timestamp: float = 0.0,
) -> NormalizedEvent:
    now = timestamp or time.time()
    return NormalizedEvent(
        event_id=str(uuid.uuid4()),
        timestamp=now,
        iso_timestamp="2026-01-01T00:00:00Z",
        event_type=event_type,
        path=path,
        extension=".txt" if not path.endswith(".locked") else ".locked",
        is_canary=is_canary,
        size_bytes=1024,
        entropy=entropy,
    )


# --- Baseline Detector Tests ---

def test_baseline_detector_triggers_on_burst():
    detector = BaselineDetector(BaselineConfig(burst_count_threshold=5, burst_window_seconds=2.0))
    t0 = time.time()

    decision = None
    for i in range(5):
        ev = make_event(path=f"documents/doc_{i}.txt", timestamp=t0 + i * 0.05, entropy=7.5)
        res = detector.process_event(ev)
        if res:
            decision = res

    assert decision is not None
    assert decision.is_suspicious is True
    assert decision.detector_config == "baseline"
    assert decision.risk_score >= 65


def test_baseline_detector_ignores_canary_status():
    detector = BaselineDetector()
    t0 = time.time()

    # Even if canary is touched, if burst threshold is not reached, baseline should not alert
    ev = make_event(path="!00_passwords.xlsx", is_canary=True, timestamp=t0)
    res = detector.process_event(ev)
    assert res is None


# --- Canary-Only Detector Tests ---

def test_canary_detector_triggers_immediately_on_canary():
    detector = CanaryDetector()
    ev = make_event(path="!00_passwords.xlsx", event_type="MODIFY", is_canary=True)
    decision = detector.process_event(ev)

    assert decision is not None
    assert decision.is_suspicious is True
    assert decision.detector_config == "canary_only"
    assert decision.severity in ("HIGH", "CRITICAL")


def test_canary_detector_ignores_regular_files():
    detector = CanaryDetector()
    ev = make_event(path="documents/user_file.txt", event_type="MODIFY", is_canary=False)
    decision = detector.process_event(ev)
    assert decision is None


# --- Hybrid Detector Tests ---

def test_hybrid_detector_suppresses_isolated_canary_touch():
    """An innocent indexer touches a canary with no follow-up damage -> Hybrid suppresses alert."""
    detector = HybridDetector(HybridConfig(observation_window_seconds=2.0, min_context_events=2))
    t0 = time.time()

    # Canary touched once in isolation
    ev_canary = make_event(path="!00_passwords.xlsx", is_canary=True, timestamp=t0)
    decision = detector.process_event(ev_canary)

    # Must NOT alert immediately on isolated touch
    assert decision is None


def test_hybrid_detector_triggers_on_canary_plus_context():
    """Canary touch followed by rapid non-canary modifications -> Hybrid triggers CRITICAL alert."""
    detector = HybridDetector(HybridConfig(observation_window_seconds=2.0, min_context_events=2, burst_velocity_threshold=2.0))
    t0 = time.time()

    # Step 1: Canary touch
    ev_canary = make_event(path="!00_passwords.xlsx", is_canary=True, timestamp=t0)
    detector.process_event(ev_canary)

    # Step 2: Contextual rapid modifications to user documents
    decision = None
    for i in range(3):
        ev = make_event(
            path=f"documents/user_doc_{i}.txt",
            is_canary=False,
            entropy=7.6,
            timestamp=t0 + 0.1 * (i + 1),
        )
        res = detector.process_event(ev)
        if res:
            decision = res

    assert decision is not None
    assert decision.is_suspicious is True
    assert decision.detector_config == "hybrid"
    assert decision.severity == "CRITICAL"
    assert "Canary file breached" in decision.explanation

