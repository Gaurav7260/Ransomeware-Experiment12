"""Automated tests for Event Normalizer and Filesystem Monitor."""

import tempfile
import time
from pathlib import Path

import pytest

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.storage.db import Database


@pytest.fixture
def setup_env():
    with tempfile.TemporaryDirectory() as tmpdir:
        sandbox = SandboxManager(Path(tmpdir) / "sandbox")
        db = Database(Path(tmpdir) / "test.db")
        canary_mgr = CanaryManager(sandbox, db)
        normalizer = EventNormalizer(sandbox, canary_mgr, debounce_ms=100)
        yield sandbox, canary_mgr, normalizer


def test_event_normalizer_valid_file(setup_env):
    sandbox, canary_mgr, normalizer = setup_env
    test_file = sandbox.validate_path("documents/report.txt")
    test_file.parent.mkdir(parents=True, exist_ok=True)
    test_file.write_text("Normal plain text file content for unit testing.")

    event = normalizer.normalize(
        event_type="MODIFY",
        src_path=str(test_file),
    )

    assert event is not None
    assert event.event_type == "MODIFY"
    assert event.path == "documents/report.txt"
    assert event.extension == ".txt"
    assert event.is_canary is False
    assert event.entropy > 0.0


def test_event_normalizer_canary_flag(setup_env):
    sandbox, canary_mgr, normalizer = setup_env
    canaries = canary_mgr.deploy_canaries()
    canary_rel = canaries[0].relative_path
    canary_abs = sandbox.validate_path(canary_rel)

    event = normalizer.normalize(
        event_type="MODIFY",
        src_path=str(canary_abs),
    )

    assert event is not None
    assert event.is_canary is True
    assert event.path == canary_rel


def test_event_normalizer_debounces_duplicates(setup_env):
    sandbox, canary_mgr, normalizer = setup_env
    test_file = sandbox.validate_path("documents/doc.txt")
    test_file.parent.mkdir(parents=True, exist_ok=True)
    test_file.write_text("Hello")

    ev1 = normalizer.normalize("MODIFY", str(test_file))
    ev2 = normalizer.normalize("MODIFY", str(test_file))  # Immediately within 100ms debounce

    assert ev1 is not None
    assert ev2 is None  # Debounced duplicate


def test_event_normalizer_ignores_outside_sandbox(setup_env):
    sandbox, canary_mgr, normalizer = setup_env
    with tempfile.NamedTemporaryFile() as ext:
        event = normalizer.normalize("MODIFY", ext.name)
        assert event is None

