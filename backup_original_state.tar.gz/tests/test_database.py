"""Automated tests for SQLite Database Layer."""

import tempfile
import time
import uuid
from pathlib import Path

import pytest

from canary_sentinel.storage.db import Database
from canary_sentinel.storage.models import AlertRecord, CanaryRecord, NormalizedEvent, ScenarioRecord


@pytest.fixture
def temp_db():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        db = Database(db_path)
        yield db


def test_db_save_and_get_events(temp_db):
    ev = NormalizedEvent(
        event_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        event_type="MODIFY",
        path="documents/test.txt",
        extension=".txt",
        is_canary=True,
        size_bytes=256,
        entropy=3.5,
        scenario_id="scen_1",
    )
    temp_db.save_event(ev)

    events = temp_db.get_events(scenario_id="scen_1")
    assert len(events) == 1
    assert events[0].event_id == ev.event_id
    assert events[0].is_canary is True


def test_db_save_and_get_alerts(temp_db):
    alert = AlertRecord(
        alert_id=str(uuid.uuid4()),
        timestamp=time.time(),
        iso_timestamp="2026-01-01T00:00:00Z",
        detector_config="hybrid",
        severity="CRITICAL",
        risk_score=95,
        confidence=0.98,
        triggering_event_id="ev_1",
        triggering_event_summary="Test Summary",
        supporting_event_ids=["ev_2", "ev_3"],
        explanation="Test explanation",
        response_status="BLOCKED",
        scenario_id="scen_1",
    )
    temp_db.save_alert(alert)

    alerts = temp_db.get_alerts(detector_config="hybrid")
    assert len(alerts) == 1
    assert alerts[0].risk_score == 95
    assert len(alerts[0].supporting_event_ids) == 2


def test_db_save_and_get_scenarios(temp_db):
    scenario = ScenarioRecord(
        scenario_id="test_scen",
        scenario_name="Test Scenario",
        scenario_type="suspicious",
        detector_config="hybrid",
        start_time=100.0,
        end_time=105.0,
        duration_ms=5000.0,
        planned_ops=10,
        executed_ops=4,
        prevented_ops=6,
        files_damaged=3,
        detected=True,
        detection_latency_ms=120.0,
        response_triggered=True,
    )
    temp_db.save_scenario(scenario)

    scenarios = temp_db.get_scenarios()
    assert len(scenarios) == 1
    assert scenarios[0].prevented_ops == 6
    assert scenarios[0].detected is True


def test_db_reset(temp_db):
    temp_db.save_event(
        NormalizedEvent(
            event_id="e1",
            timestamp=1.0,
            iso_timestamp="ts",
            event_type="MODIFY",
            path="p",
        )
    )
    assert len(temp_db.get_events()) == 1

    temp_db.reset_db()
    assert len(temp_db.get_events()) == 0

