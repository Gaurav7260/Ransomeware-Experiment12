"""Automated tests for Sandbox safety, path traversal prevention, and symlink isolation."""

import os
import tempfile
from pathlib import Path

import pytest

from canary_sentinel.core.sandbox import SandboxManager, SandboxSecurityError


@pytest.fixture
def temp_sandbox():
    """Create a temporary sandbox directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        mgr = SandboxManager(tmpdir)
        yield mgr


def test_sandbox_path_validation_valid(temp_sandbox):
    """Valid paths inside the sandbox should resolve correctly."""
    valid_file = temp_sandbox.validate_path("documents/test.txt")
    assert valid_file.is_relative_to(temp_sandbox.sandbox_path)

    # Subdirectory validation
    valid_sub = temp_sandbox.validate_path(temp_sandbox.sandbox_path / "finance" / "budget.xlsx")
    assert valid_sub.is_relative_to(temp_sandbox.sandbox_path)


def test_sandbox_rejects_directory_traversal(temp_sandbox):
    """Directory traversal sequences like ../ must be blocked."""
    with pytest.raises(SandboxSecurityError):
        temp_sandbox.validate_path("../../etc/passwd")

    with pytest.raises(SandboxSecurityError):
        temp_sandbox.validate_path("documents/../../outside.txt")


def test_sandbox_rejects_absolute_path_outside(temp_sandbox):
    """Absolute paths outside sandbox must be blocked."""
    with pytest.raises(SandboxSecurityError):
        temp_sandbox.validate_path("/etc/hosts")

    with pytest.raises(SandboxSecurityError):
        temp_sandbox.validate_path(Path.home() / "Documents")


def test_sandbox_rejects_null_byte_injection(temp_sandbox):
    """Null byte injection must be blocked."""
    with pytest.raises(SandboxSecurityError):
        temp_sandbox.validate_path("documents/file.txt\0/etc/passwd")


def test_sandbox_rejects_symlink_escape(temp_sandbox):
    """Symlinks that point outside the sandbox boundary must be detected and blocked."""
    with tempfile.NamedTemporaryFile() as ext_file:
        external_target = Path(ext_file.name)
        symlink_path = temp_sandbox.sandbox_path / "evil_symlink.txt"

        try:
            os.symlink(external_target, symlink_path)
            with pytest.raises(SandboxSecurityError):
                temp_sandbox.validate_path(symlink_path, check_symlink=True)
        finally:
            if symlink_path.is_symlink() or symlink_path.exists():
                symlink_path.unlink()


def test_sandbox_safe_reset(temp_sandbox):
    """Safe reset should delete contents but keep sandbox root intact."""
    test_sub = temp_sandbox.sandbox_path / "subdir"
    test_sub.mkdir()
    test_file = test_sub / "test.txt"
    test_file.write_text("dummy")

    assert test_file.exists()
    temp_sandbox.reset_sandbox()

    assert temp_sandbox.sandbox_path.exists()
    assert not test_file.exists()
    assert not test_sub.exists()


def test_refusal_to_use_system_root_as_sandbox():
    """System roots and user home directory must be rejected as sandbox path."""
    with pytest.raises(SandboxSecurityError):
        SandboxManager("/")

    with pytest.raises(SandboxSecurityError):
        SandboxManager("/etc")

    with pytest.raises(SandboxSecurityError):
        SandboxManager("/etc/sub")

    with pytest.raises(SandboxSecurityError):
        SandboxManager("/System")

    with pytest.raises(SandboxSecurityError):
        SandboxManager("/System/sub")

    with pytest.raises(SandboxSecurityError):
        SandboxManager("/bin")

    with pytest.raises(SandboxSecurityError):
        SandboxManager(Path.home())


def test_nested_traversal_attempts(temp_sandbox):
    """Deep nested traversal attempts must be blocked."""
    nested_cases = [
        "a/b/c/../../../../etc/passwd",
        "./a/./b/../../../../var/log",
        "documents/sub/../../../outside.txt",
        "..",
        "../sandbox",
    ]
    for case in nested_cases:
        with pytest.raises(SandboxSecurityError):
            temp_sandbox.validate_path(case)


def test_simulator_cannot_write_outside_sandbox(temp_sandbox):
    """The simulator helper must reject creating or writing files outside sandbox."""
    from canary_sentinel.simulation.scenarios import ScenarioHelper

    helper = ScenarioHelper(temp_sandbox)

    with tempfile.TemporaryDirectory() as outside_dir:
        # Traversal target
        with pytest.raises(SandboxSecurityError):
            helper.create_user_files(count=2, directory="../../outside")

        # Absolute outside target
        with pytest.raises(SandboxSecurityError):
            helper.create_user_files(count=2, directory=outside_dir)

