"""Automated tests for CLI utilities and CSV data export."""

import tempfile
from pathlib import Path

import pandas as pd
import pytest

from canary_sentinel.experiments.metrics import MetricsCalculator
from canary_sentinel.storage.db import Database
from canary_sentinel.storage.models import (
    AlertRecord,
    NormalizedEvent,
    ScenarioRecord,
)


def test_csv_export_generation():
    """Verify that events, alerts, trials, and scenario breakdown export valid CSV files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        db_path = root / "export_test.db"
        export_dir = root / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)

        db = Database(db_path)

        # Insert dummy event
        ev = NormalizedEvent(
            event_id="e1",
            timestamp=1000.0,
            iso_timestamp="2026-11-02T12:00:00Z",
            event_type="MODIFY",
            path="documents/test.txt",
            is_canary=False,
            size_bytes=100,
            entropy=4.5,
            process_id=123,
            process_name="test_proc",
            scenario_id="sc1",
        )
        db.save_event(ev)

        # Insert dummy alert
        al = AlertRecord(
            alert_id="a1",
            timestamp=1001.0,
            iso_timestamp="2026-11-02T12:00:01Z",
            detector_config="hybrid",
            severity="HIGH",
            risk_score=85,
            confidence=0.9,
            triggering_event_id="e1",
            triggering_event_summary="Test trigger",
            supporting_event_ids=["e1"],
            explanation="Test explanation",
            response_status="BLOCKED",
            scenario_id="sc1",
        )
        db.save_alert(al)

        # Insert dummy trial
        sc = ScenarioRecord(
            scenario_id="sc1",
            scenario_name="Canary Touch + Rapid Bulk Modifications",
            scenario_type="suspicious",
            detector_config="hybrid",
            start_time=1000.0,
            end_time=1002.0,
            duration_ms=2000.0,
            planned_ops=10,
            executed_ops=3,
            prevented_ops=7,
            files_damaged=1,
            detected=True,
            detection_latency_ms=45.0,
            response_triggered=True,
            alert_id="a1",
        )
        db.save_scenario(sc)

        # Export events CSV
        events = db.get_events()
        df_ev = pd.DataFrame([e.to_dict() for e in events])
        ev_csv = export_dir / "events.csv"
        df_ev.to_csv(ev_csv, index=False)
        assert ev_csv.exists()
        assert len(pd.read_csv(ev_csv)) == 1

        # Export alerts CSV
        alerts = db.get_alerts()
        df_al = pd.DataFrame([a.to_dict() for a in alerts])
        al_csv = export_dir / "alerts.csv"
        df_al.to_csv(al_csv, index=False)
        assert al_csv.exists()
        assert len(pd.read_csv(al_csv)) == 1

        # Export trials CSV
        scenarios = db.get_scenarios()
        df_sc = pd.DataFrame([s.to_dict() for s in scenarios])
        sc_csv = export_dir / "trials.csv"
        df_sc.to_csv(sc_csv, index=False)
        assert sc_csv.exists()
        assert len(pd.read_csv(sc_csv)) == 1

        # Export metrics and breakdown
        calc = MetricsCalculator(db)
        rep = calc.generate_comparison_report()
        breakdown_csv = export_dir / "scenario_breakdown.csv"
        if rep.scenario_breakdown:
            df_sb = pd.DataFrame([
                {
                    "scenario_id": r.scenario_id,
                    "scenario_name": r.scenario_name,
                    "scenario_type": r.scenario_type,
                    "detector_config": r.detector_config,
                    "total_runs": r.total_runs,
                    "detected_count": r.detected_count,
                    "detection_rate": r.detection_rate,
                    "mean_latency_ms": r.mean_latency_ms,
                    "mean_files_damaged": r.mean_files_damaged,
                    "mean_ops_prevented_pct": r.mean_ops_prevented_pct,
                }
                for r in rep.scenario_breakdown
            ])
            df_sb.to_csv(breakdown_csv, index=False)
            assert breakdown_csv.exists()
            assert len(pd.read_csv(breakdown_csv)) >= 1
