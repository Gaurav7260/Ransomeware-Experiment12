"""Performance and overhead benchmarks for CanarySentinel on local hardware."""

import tempfile
import time
from pathlib import Path

import psutil
import pytest

from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.core.config import CanaryConfig, SentinelConfig
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.detection.baseline_detector import BaselineDetector
from canary_sentinel.detection.canary_detector import CanaryDetector
from canary_sentinel.detection.hybrid_detector import HybridDetector
from canary_sentinel.monitoring.normalizer import EventNormalizer
from canary_sentinel.storage.db import Database
from canary_sentinel.storage.models import NormalizedEvent


def test_performance_benchmarks():
    """Measure event normalization latency, detector processing latency, and DB throughput."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        sandbox = SandboxManager(root / "sandbox")
        db = Database(root / "perf.db")
        canary_mgr = CanaryManager(sandbox, db, CanaryConfig())
        normalizer = EventNormalizer(sandbox, canary_mgr)

        baseline = BaselineDetector()
        canary_det = CanaryDetector()
        hybrid = HybridDetector()

        # 1. Measure DB event write latency
        t0 = time.perf_counter()
        count = 100
        for i in range(count):
            ev = NormalizedEvent(
                event_id=f"perf_ev_{i}",
                timestamp=time.time(),
                iso_timestamp="2026-11-02T12:00:00Z",
                event_type="MODIFY",
                path=f"documents/doc_{i}.txt",
                size_bytes=1024,
                entropy=4.2,
            )
            db.save_event(ev)
        t_db_write = (time.perf_counter() - t0) * 1000.0 / count  # ms per event

        # 2. Measure DB query latency
        t0 = time.perf_counter()
        events_read = db.get_events(limit=100)
        t_db_read = (time.perf_counter() - t0) * 1000.0  # ms for 100 events

        assert len(events_read) == count
        assert t_db_write < 20.0  # SQLite with WAL should be well under 20ms/write
        assert t_db_read < 25.0

        # 3. Measure Detector processing latency per event
        sample_event = events_read[0]

        # Baseline
        t0 = time.perf_counter()
        for _ in range(100):
            baseline.process_event(sample_event)
        t_baseline = (time.perf_counter() - t0) * 1000.0 / 100

        # Canary-only
        t0 = time.perf_counter()
        for _ in range(100):
            canary_det.process_event(sample_event)
        t_canary = (time.perf_counter() - t0) * 1000.0 / 100

        # Hybrid
        t0 = time.perf_counter()
        for _ in range(100):
            hybrid.process_event(sample_event)
        t_hybrid = (time.perf_counter() - t0) * 1000.0 / 100

        # All detector in-memory event evaluations should execute in sub-millisecond time (< 1.0 ms)
        assert t_baseline < 1.0
        assert t_canary < 1.0
        assert t_hybrid < 1.0

