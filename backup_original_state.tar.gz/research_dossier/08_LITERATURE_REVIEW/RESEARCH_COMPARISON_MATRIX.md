# Research Comparison Matrix: State-of-the-Art vs. CanarySentinel

**Document**: `research_dossier/08_LITERATURE_REVIEW/RESEARCH_COMPARISON_MATRIX.md`  

| System | Year | Platform | Detection Paradigm | Uses Decoys? | Evasion Resilience | False Positive Rate | Containment Mechanism | Latency | Core Limitations |
|:---|:---:|:---:|:---|:---:|:---:|:---:|:---|:---:|:---|
| **CryptoDrop** | 2016 | Windows | Behavioral (Entropy + Type) | No | Moderate | Low (~1.2%) | Process suspension | 410 ms | Driver minifilter; slow drip evasion |
| **ShieldFS** | 2016 | Windows | Driver Behavioral + Self-Healing | No | High | Low (~0.1%) | Copy-on-write rollback | 850 ms | High CPU overhead (12-18%); Windows only |
| **R-Sentry** | 2019 | Windows | Cognitive Trajectory + Honeyfiles | Yes | Moderate | Moderate (~4.5%) | Process termination | 65 ms | Invasive process memory profiling |
| **GuardFS** | 2021 | Linux | VFS Inline Interception | No | High | Low (~1.8%) | Staged write abort | 185 ms | FUSE/VFS filesystem driver overhead |
| **RansomFisher** | 2021 | Windows | Behavior-Only (No Decoys) | No | High | Moderate (~6.2%) | Process termination | 320 ms | False alarms on developer batch tasks |
| **RWGuard** | 2018 | Windows | Hybrid (I/O + Decoys + Counters) | Yes | High | Low (~1.1%) | Process kill + Key capture | 92 ms | Hardware counter dependency limits portability |
| **CanarySentinel (Baseline)** | 2026 | macOS | Behavior-Only Heuristics | No | High (Catches S6) | 25.0% | Simulated block flag | 147.1 ms | False alarms on developer batch renaming |
| **CanarySentinel (Canary-Only)** | 2026 | macOS | Decoy Tripwire | Yes | Zero (Misses S6) | 25.0% | Simulated block flag | 18.9 ms | False alarms on innocent single canary reads |
| **CanarySentinel (Hybrid)** | 2026 | macOS | Correlated Context (Decoy + Velocity) | Yes | Zero (Misses S6) | **0.0%** | Simulated block flag | **26.1 ms** | Blind to attacks that avoid canaries (Recall 50%) |
