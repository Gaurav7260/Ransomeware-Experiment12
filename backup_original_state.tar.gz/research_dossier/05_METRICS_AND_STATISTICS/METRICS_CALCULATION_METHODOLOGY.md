# Metrics Calculation Methodology & Mathematical Formulations

**Document**: `research_dossier/05_METRICS_AND_STATISTICS/METRICS_CALCULATION_METHODOLOGY.md`  
**Scope**: Exact mathematical definitions, denominators, edge-case handlers, and implementations used in CanarySentinel.  

---

## 1. Classification Metrics Formulations

Let $N$ denote the total number of experimental trials ($N = 60$ per detector configuration):
- **Actual Positives ($P = 20$)**: Trials executing simulated attack scenarios (`canary_plus_rapid_bulk`, `rapid_bulk_without_canary`).
- **Actual Negatives ($N_{\text{neg}} = 40$)**: Trials executing benign workloads (`Normal File Editing`, `Bulk Copying`, `Bulk Renaming`, `Canary Touch Without Follow-up`).

### A. Confusion Matrix Elements
- **True Positive ($\text{TP}$)**: Attack trial correctly alerted ($\text{scenario\_type} == \text{'suspicious'} \wedge \text{detected} == 1$).
- **False Positive ($\text{FP}$)**: Benign trial incorrectly alerted ($\text{scenario\_type} == \text{'benign'} \wedge \text{detected} == 1$).
- **True Negative ($\text{TN}$)**: Benign trial correctly not alerted ($\text{scenario\_type} == \text{'benign'} \wedge \text{detected} == 0$).
- **False Negative ($\text{FN}$)**: Attack trial not alerted ($\text{scenario\_type} == \text{'suspicious'} \wedge \text{detected} == 0$).

### B. Precision (Positive Predictive Value)
$$\text{Precision} = \frac{\text{TP}}{\text{TP} + \text{FP}}$$
*Zero-Denominator Handling*: If $\text{TP} + \text{FP} == 0$, $\text{Precision}$ is defined as `N/A` or `0.0`.

### C. Recall (Sensitivity / True Positive Rate)
$$\text{Recall} = \frac{\text{TP}}{\text{TP} + \text{FN}} = \frac{\text{TP}}{P}$$

### D. F1-Score (Harmonic Mean of Precision and Recall)
$$F_1 = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}} = \frac{2 \cdot \text{TP}}{2 \cdot \text{TP} + \text{FP} + \text{FN}}$$

### E. False Positive Rate (FPR / Fall-out)
$$\text{FPR} = \frac{\text{FP}}{\text{FP} + \text{TN}} = \frac{\text{FP}}{N_{\text{neg}}}$$

### F. Specificity (True Negative Rate)
$$\text{Specificity} = \frac{\text{TN}}{\text{TN} + \text{FP}} = 1 - \text{FPR}$$

### G. Accuracy
$$\text{Accuracy} = \frac{\text{TP} + \text{TN}}{\text{TP} + \text{TN} + \text{FP} + \text{FN}} = \frac{\text{TP} + \text{TN}}{N}$$

---

## 2. Temporal & Damage Metrics Formulations

### A. Detection Latency
For trials where an alert was generated ($\text{detected} == 1$):
$$\text{Latency} = (t_{\text{alert}} - t_{\text{start}}) \times 1000 \quad [\text{ms}]$$
*Strict Exclusion*: Undetected attacks ($\text{detected} == 0$) are **excluded** from latency averages (stored as `NULL`), rather than treated as $0.0\text{ ms}$, preventing artificial downward distortion.

### B. Student's $t$ 95% Confidence Interval
$$\text{CI}_{95} = \bar{x} \pm t_{\alpha/2, \, \nu} \times \frac{s}{\sqrt{k}}$$
Where:
- $\bar{x}$ is the sample mean latency.
- $s = \sqrt{\frac{1}{k-1}\sum_{i=1}^k (x_i - \bar{x})^2}$ is the sample standard deviation.
- $k$ is the count of alert trials ($k=30$ for Baseline, $k=20$ for Canary-Only, $k=10$ for Hybrid).
- $\nu = k - 1$ degrees of freedom.
- $t_{0.025, \nu}$ is the two-tailed critical value: $t_{0.025, 29} = 2.045$, $t_{0.025, 19} = 2.093$, $t_{0.025, 9} = 2.262$.

### C. Operations Prevented Percentage
Calculated per trial as:
$$\text{PrevPct}_i = \frac{\text{prevented\_ops}_i}{\text{planned\_ops}_i} \times 100$$
The aggregate operations prevented is reported as the arithmetic mean of per-trial percentages across suspicious attack trials ($n = 20$).

