# Statistical Limitations and Methodological Boundaries

**Auditor**: Independent Statistical Validation Team  
**Document**: `research_dossier/05_METRICS_AND_STATISTICS/STATISTICAL_LIMITATIONS.md`  

---

## 1. Sample Size & Power Considerations

1. **Repetitions per Scenario ($n = 10$)**:
   - While 10 repetitions per scenario provide sufficient power for detecting large effect sizes ($d > 0.8$, such as the latency difference between 147 ms and 26 ms), subtle behavioral variations within sub-millisecond intervals cannot be fully resolved without larger sample sizes ($n \ge 100$).
2. **Alert Counts ($k$)**:
   - For Hybrid, only 10 trials alerted (Scenario S5). While the standard deviation was tight ($s = 8.43\text{ ms}$), the small degrees of freedom ($\nu = 9$) widen the Student's $t$ confidence interval multiplier to $t_{0.025, 9} = 2.262$.
   - Recommendations for future studies: expand attack repetitions to at least 30 runs per scenario.

---

## 2. Normality and Multiple Comparisons

1. **Multimodality in Baseline Latency**:
   - Baseline latency is a mixture distribution: Scenario S5 alerts in ~25.8 ms, Scenario S6 alerts in ~144.0 ms, and Scenario B4 (false positive) alerts in ~271.3 ms.
   - The aggregated mean of 147.05 ms collapses three distinct behavioral regimes. Researchers must inspect the scenario-level breakdown rather than relying solely on the pooled average.
2. **Family-Wise Error Rate (FWER)**:
   - When conducting multiple pairwise hypothesis tests (e.g., across 3 detectors and 6 scenarios), applying Holm-Bonferroni correction maintains family-wise error rate control.
   - For our three primary tests, all $p$-values ($p < 0.0012$) remain statistically significant even under conservative Bonferroni thresholds ($\alpha / 3 = 0.0167$).

---

## 3. Threat to External Validity: The Base-Rate Fallacy

- In our controlled experimental design, the attack base rate was $33.3\%$ (20 attack trials out of 60 trials).
- In real-world enterprise environments, the base rate of ransomware attacks relative to benign operations is infinitesimal ($< 0.0001\%$).
- Consequently, while Hybrid achieved **0.0% False Positive Rate** across 40 benign trials in our sandbox, real-world deployment across millions of diverse enterprise operations may encounter rare edge cases that generate false alarms.
- **Audited Rule**: Achieving 0.0% FPR in a controlled sandbox does **not** prove zero false alarms in production enterprise environments.

