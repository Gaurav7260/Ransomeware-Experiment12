# Independent Metrics Validation & Recalculation Audit

**Auditor**: Independent Statistical Validation Team  
**Document**: `research_dossier/05_METRICS_AND_STATISTICS/INDEPENDENT_METRICS_VALIDATION.md`  
**Authoritative Source**: SQLite Table `scenarios` (180 verified records)  

---

## 1. Step-by-Step Numerical Recalculation

All metrics below are derived directly from the trial-level records stored in `canary_sentinel.db`.

```
========================================================================================
1. CONFIGURATION A: BASELINE BEHAVIORAL DETECTOR (Total Trials N = 60)
========================================================================================
- True Positives (TP):   20  (10 in S5 [Canary+Rapid], 10 in S6 [Rapid w/o Canary])
- False Positives (FP):  10  (10 in B4 [Bulk Renaming])
- True Negatives (TN):   30  (10 in B1 [Normal], 10 in B2 [Copy], 10 in B3 [Canary Touch])
- False Negatives (FN):   0  (All 20 attack trials detected)

* Precision:   TP / (TP + FP) = 20 / (20 + 10) = 20 / 30 = 0.666667  -->  66.67%
* Recall:      TP / (TP + FN) = 20 / (20 + 0)  = 20 / 20 = 1.000000  --> 100.00%
* F1-Score:    2 * (P * R) / (P + R) = 2 * (0.666667 * 1.0) / 1.666667 = 0.8000
* FPR:         FP / (FP + TN) = 10 / (10 + 30) = 10 / 40 = 0.250000  -->  25.00%
* Specificity: TN / (TN + FP) = 30 / (30 + 10) = 30 / 40 = 0.750000  -->  75.00%
* Accuracy:    (TP + TN) / N  = (20 + 30) / 60 = 50 / 60 = 0.833333  -->  83.33%

* Detection Latency (k = 30 alerts):
  Sum = 4,411.42 ms  -->  Mean = 4,411.42 / 30 = 147.05 ms
  Std Dev (s) = 102.07 ms, Median = 141.96 ms, Min = 18.85 ms, Max = 276.48 ms
  Student t 95% CI: 147.05 +/- 2.045 * (102.07 / sqrt(30)) = 147.05 +/- 38.13 ms

* Suspicious Trials Damage & Operations Prevented (n = 20):
  Mean Files Damaged = (0.0 * 10 + 6.1 * 10) / 20 = 61.0 / 20 = 3.05 files
  Mean Prevented Ops % (Mean of trial ratios): (91.67% * 10 + 39.0% * 10) / 20 = 65.33%
  Prevented Ops % (Ratio of sums): 149 prevented / 220 planned = 67.73%

========================================================================================
2. CONFIGURATION B: CANARY-ONLY TRIPWIRE DETECTOR (Total Trials N = 60)
========================================================================================
- True Positives (TP):   10  (10 in S5 [Canary+Rapid])
- False Positives (FP):  10  (10 in B3 [Canary Touch Benign])
- True Negatives (TN):   30  (10 in B1, 10 in B2, 10 in B4)
- False Negatives (FN):  10  (10 in S6 [Rapid w/o Canary - missed entirely])

* Precision:   TP / (TP + FP) = 10 / (10 + 10) = 10 / 20 = 0.500000  -->  50.00%
* Recall:      TP / (TP + FN) = 10 / (10 + 10) = 10 / 20 = 0.500000  -->  50.00%
* F1-Score:    2 * (P * R) / (P + R) = 2 * (0.5 * 0.5) / 1.0 = 0.5000
* FPR:         FP / (FP + TN) = 10 / (10 + 30) = 10 / 40 = 0.250000  -->  25.00%
* Specificity: TN / (TN + FP) = 30 / (30 + 10) = 30 / 40 = 0.750000  -->  75.00%
* Accuracy:    (TP + TN) / N  = (10 + 30) / 60 = 40 / 60 = 0.666667  -->  66.67%

* Detection Latency (k = 20 alerts):
  Sum = 377.67 ms  -->  Mean = 377.67 / 20 = 18.88 ms
  Std Dev (s) = 7.71 ms, Median = 16.17 ms, Min = 5.51 ms, Max = 38.10 ms
  Student t 95% CI: 18.88 +/- 2.093 * (7.71 / sqrt(20)) = 18.88 +/- 3.61 ms

* Suspicious Trials Damage & Operations Prevented (n = 20):
  Mean Files Damaged = (0.10 * 10 + 10.0 * 10) / 20 = 101.0 / 20 = 5.05 files
  Mean Prevented Ops % (Mean of trial ratios): (90.83% * 10 + 0.0% * 10) / 20 = 45.42%
  Prevented Ops % (Ratio of sums): 109 prevented / 220 planned = 49.55%

========================================================================================
3. CONFIGURATION C: HYBRID CORRELATED DETECTOR (Total Trials N = 60)
========================================================================================
- True Positives (TP):   10  (10 in S5 [Canary+Rapid])
- False Positives (FP):   0  (Zero false alarms across all 40 benign trials)
- True Negatives (TN):   40  (10 in B1, 10 in B2, 10 in B3, 10 in B4)
- False Negatives (FN):  10  (10 in S6 [Rapid w/o Canary - missed entirely])

* Precision:   TP / (TP + FP) = 10 / (10 + 0)  = 10 / 10 = 1.000000  --> 100.00%
* Recall:      TP / (TP + FN) = 10 / (10 + 10) = 10 / 20 = 0.500000  -->  50.00%
* F1-Score:    2 * (P * R) / (P + R) = 2 * (1.0 * 0.5) / 1.5 = 0.6667
* FPR:         FP / (FP + TN) = 0 / (0 + 40)   = 0 / 40  = 0.000000  -->   0.00%
* Specificity: TN / (TN + FP) = 40 / (40 + 0)  = 40 / 40 = 1.000000  --> 100.00%
* Accuracy:    (TP + TN) / N  = (10 + 40) / 60 = 50 / 60 = 0.833333  -->  83.33%

* Detection Latency (k = 10 alerts):
  Sum = 261.05 ms  -->  Mean = 261.05 / 10 = 26.10 ms
  Std Dev (s) = 8.43 ms, Median = 25.78 ms, Min = 15.76 ms, Max = 46.85 ms
  Student t 95% CI: 26.10 +/- 2.262 * (8.43 / sqrt(10)) = 26.10 +/- 6.03 ms

* Suspicious Trials Damage & Operations Prevented (n = 20):
  Mean Files Damaged = (0.10 * 10 + 10.0 * 10) / 20 = 101.0 / 20 = 5.05 files
  Mean Prevented Ops % (Mean of trial ratios): (90.83% * 10 + 0.0% * 10) / 20 = 45.42%
  Prevented Ops % (Ratio of sums): 109 prevented / 220 planned = 49.55%
========================================================================================
```

