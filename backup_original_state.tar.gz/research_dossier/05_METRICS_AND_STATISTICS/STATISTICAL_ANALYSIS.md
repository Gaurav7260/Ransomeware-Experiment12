# Rigorous Statistical Audit & Significance Analysis

**Auditor**: Independent Statistical Validation & Research Methods Team  
**Dataset**: `research_dossier/05_METRICS_AND_STATISTICS/RAW_EXPERIMENT_DATA.csv`  
**Document**: `research_dossier/05_METRICS_AND_STATISTICS/STATISTICAL_ANALYSIS.md`  

---

## 1. Experimental Design & Statistical Assumptions Audit

1. **Trial Independence**:
   - The 180 trials were executed in sequential blocks with a mandatory 150 ms settling window (`time.sleep(0.15)`) between runs.
   - The filesystem sandbox was cleanly reset and canaries regenerated between scenario groups, preventing state leakage.
   - Trials are treated as independent realizations within each scenario group.
2. **Paired vs. Unpaired Structure**:
   - The three detector configurations were evaluated against **identical scenario definitions and target workloads**.
   - For classification outcomes across the 20 attack scenarios, McNemar's paired test and Fisher's exact test evaluate classification shifts.
3. **Distribution Normality (Shapiro-Wilk Test)**:
   - **Baseline Latency ($k=30$)**: $W = 0.8220, p = 0.0002$. Rejects normality at $\alpha = 0.05$. (Multimodal due to combining S5, S6, and B4).
   - **Hybrid Latency ($k=10$)**: $W = 0.7982, p = 0.0138$. Rejects normality at $\alpha = 0.05$.
   - **Canary-Only Latency ($k=20$)**: $W = 0.9392, p = 0.2311$. Does not reject normality.
   - **Methodological Impact**: Because Baseline and Hybrid latencies deviate from normality, non-parametric tests (**Mann-Whitney U**) and reporting **Median Latency** are scientifically mandatory alongside parametric $t$-tests.

---

## 2. Hypothesis Testing & Significance Results

### Test 1: Detection Latency (Baseline vs. Hybrid)
- **Null Hypothesis ($H_0$)**: There is no difference in detection latency between Baseline and Hybrid ($\mu_{\text{baseline}} = \mu_{\text{hybrid}}$).
- **Alternative Hypothesis ($H_1$)**: Hybrid detection latency is significantly lower than Baseline ($\mu_{\text{hybrid}} < \mu_{\text{baseline}}$).
- **Parametric Test (Welch's Two-Sample $t$-test)**:
  - $t = 6.3887, p = 4.14 \times 10^{-7}$ ($p < 0.0001$).
- **Non-Parametric Test (Mann-Whitney U Test)**:
  - $U = 287.0, p = 1.05 \times 10^{-4}$ ($p < 0.001$).
- **Effect Size (Cohen's $d$)**:
  $$d = \frac{147.05 - 26.10}{89.27} = \mathbf{1.3549} \quad (\text{Very large effect size, } d > 0.8)$$
- **Scientific Verdict**: **REJECT $H_0$**. Hybrid detection is statistically significantly faster than Baseline by an order of magnitude ($p < 0.0001$), with a very large effect size ($d = 1.35$).

### Test 2: False Positive Rate (Canary-Only vs. Hybrid)
- **Null Hypothesis ($H_0$)**: False positive rate on benign workloads is independent of detector configuration ($p_{\text{FP\_Canary}} = p_{\text{FP\_Hybrid}}$).
- **Alternative Hypothesis ($H_1$)**: Hybrid achieves a significantly lower false positive rate than Canary-Only ($p_{\text{FP\_Hybrid}} < p_{\text{FP\_Canary}}$).
- **Contingency Matrix ($2 \times 2$)**:
  $$\begin{pmatrix} \text{FP} & \text{TN} \\ 10 & 30 \\ 0 & 40 \end{pmatrix}$$
- **Fisher's Exact Test**:
  - Odds Ratio $= 0.0$, $p = 0.00114$ ($p < 0.01$).
- **Scientific Verdict**: **REJECT $H_0$**. The reduction of false alarms from 25.0% to 0.0% achieved by Hybrid is statistically significant ($p = 0.0011$). Corroboration definitively suppresses false alarms on benign decoy access.

### Test 3: Attack Recall / Sensitivity (Baseline vs. Hybrid)
- **Null Hypothesis ($H_0$)**: True positive detection rate on attacks is equal between Baseline and Hybrid ($p_{\text{Recall\_Baseline}} = p_{\text{Recall\_Hybrid}}$).
- **Alternative Hypothesis ($H_1$)**: Baseline achieves significantly higher recall than Hybrid ($p_{\text{Recall\_Baseline}} > p_{\text{Recall\_Hybrid}}$).
- **Contingency Matrix ($2 \times 2$)**:
  $$\begin{pmatrix} \text{TP} & \text{FN} \\ 20 & 0 \\ 10 & 10 \end{pmatrix}$$
- **Fisher's Exact Test**:
  - Odds Ratio $= \infty$, $p = 0.000407$ ($p < 0.001$).
- **Scientific Verdict**: **REJECT $H_0$**. Baseline achieves statistically significantly higher recall than Hybrid ($p < 0.001$). Hybrid's reliance on canaries creates a statistically proven blind spot when attackers evade decoys (Scenario S6).

---

## 3. Summary Table of Statistical Tests

| Statistical Test | Comparison | $H_0$ | Test Statistic | $p$-value | Significant at $\alpha=0.01$? | Effect Size |
|:---|:---|:---|:---:|:---:|:---:|:---:|
| **Welch's $t$-test** | Latency: Baseline vs Hybrid | $\mu_B = \mu_H$ | $t = 6.3887$ | $4.14 \times 10^{-7}$ | **YES** | Cohen's $d = 1.35$ |
| **Mann-Whitney U** | Latency: Baseline vs Hybrid | $\text{Rank}_B = \text{Rank}_H$ | $U = 287.0$ | $1.05 \times 10^{-4}$ | **YES** | $r = 0.61$ |
| **Fisher's Exact** | FPR: Canary-Only vs Hybrid | $\text{FPR}_C = \text{FPR}_H$ | $\text{OR} = 0.0$ | $0.00114$ | **YES** | Risk Ratio $= 0.0$ |
| **Fisher's Exact** | Recall: Baseline vs Hybrid | $\text{Rec}_B = \text{Rec}_H$ | $\text{OR} = \infty$ | $0.00041$ | **YES** | Risk Ratio $= 2.0$ |

