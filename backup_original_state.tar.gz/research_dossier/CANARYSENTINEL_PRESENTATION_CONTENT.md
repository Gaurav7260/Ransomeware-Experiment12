# CanarySentinel — B.Tech Final-Year Capstone Project Presentation

**Project Title**: CanarySentinel: Deception-Based Ransomware Detection, Behavioral Analysis and Risk-Aware Response System  
**Research Topic**: Evaluating Canary-Triggered Behavioral Corroboration for Early Ransomware Detection and Damage Reduction  
**Audience**: Final-Year Examination Board, Faculty Evaluators, and Industry Reviewers  
**Document**: CANARYSENTINEL_PRESENTATION_CONTENT.md  

---

## Slide 1: Title Slide

- **Slide Title**: CanarySentinel: Deception-Based Ransomware Detection, Behavioral Analysis and Risk-Aware Response System
- **Subtitle**: Evaluating Canary-Triggered Behavioral Corroboration for Early Ransomware Detection and Damage Reduction
- **Presenter Names**: [Student Name 1], [Student Name 2], [Student Name 3]
- **Guide**: [Supervisor Name], Department of Computer Science and Engineering
- **Institution**: [Institution / University Name]
- **Date**: Academic Year 2025–2026
- **Suggested Visual**: Official Institution Logo beside the CanarySentinel Project Shield Icon.
- **Speaker Notes**:
  > "Good morning, respected members of the evaluation committee and my project guide. Today, we are presenting our final-year project: CanarySentinel. Our research investigates a critical challenge in endpoint cybersecurity: Can we eliminate false alarms and contain ransomware damage by corroborating canary file tripwires with contextual filesystem behavior? Over the next 15 minutes, we will present the architecture, mathematical verification, empirical results from 180 controlled trials, and our conclusions."
- **Evidence Source**: Project Repository Root (`canary_sentinel/`).

---

## Slide 2: Introduction & Motivation

- **Slide Title**: The Ransomware Epidemic & The Defense Dilemma
- **Key Points**:
  - **The Threat**: Modern crypto-ransomware operates as an automated, multi-threaded pipeline capable of destroying gigabytes of user data within seconds.
  - **Irreversible Destruction**: Once plaintext files are overwritten with strong ciphers (AES-256), recovery without paid decryption keys or backups is mathematically impossible.
  - **The Latency Imperative**: Every millisecond of detection latency translates directly to permanently lost user documents.
  - **The Operational Dilemma**:
    - Aggressive automated containment (killing processes) cannot be bound to noisy detectors without disrupting business operations.
    - Passive alerts fail because attackers encrypt data faster than human security analysts can triage tickets.
- **Suggested Visual**: Conceptual diagram contrasting "Detection Latency vs. Cumulative File Damage".
- **Speaker Notes**:
  > "Why does ransomware defense remain an unsolved problem? Because encryption is an irreversible, time-critical process. Unlike data exfiltration where data can be blocked at the egress firewall, ransomware modifies data locally. The core challenge is that automated containment—such as terminating a process—cannot tolerate false positives. If an endpoint tool kills a developer's software build or an administrative backup script, it disrupts business. Therefore, we need an ultra-fast trigger with zero false alarms."
- **Evidence Source**: `literature/LITERATURE_REVIEW.md`, Section 1.

---

## Slide 3: Problem Statement

- **Slide Title**: Limitations of Existing Endpoint Defenses
- **Key Points**:
  - **Signature Defenses (Antivirus)**: Completely ineffective against zero-day and polymorphic binaries; dynamic crypters generate unique hashes for every payload drop.
  - **Behavioral Volume Monitors (e.g., CryptoDrop)**: Monitor operation counts and Shannon entropy; effective against known bursts, but trigger severe false alarms on benign developer compilation, `git clone`, and archiving.
  - **Pure Canary Tripwires (Honeypots)**: Deploy decoy files (`000_canary.txt`); achieve ultra-low latency, but trigger false alarms on accidental user or indexing reads, and fail completely (100% false negatives) when ransomware evades decoy paths.
  - **Core Research Gap**: A lack of empirical evaluation analyzing whether **correlating canary triggers with surrounding filesystem velocity within a temporal sliding window** solves the false-positive dilemma without introducing fatal blind spots.
- **Suggested Visual**: Three-column comparison table highlighting the fatal flaw of each paradigm.
- **Speaker Notes**:
  > "Current defenses force a painful compromise. Antivirus signatures are obsolete against polymorphic malware. Pure behavioral detectors trigger false alarms during routine developer builds. Pure canary files alert instantly, but false-alarm on accidental reads and fail completely if the attacker skips decoy files. This leads directly to our research question: Can we combine canary tripwires with contextual behavior to achieve the best of both worlds?"
- **Evidence Source**: `literature/LITERATURE_COMPARISON_MATRIX.csv`.

---

## Slide 4: Research Objectives & Hypotheses

- **Slide Title**: Research Question, Objectives & Hypotheses
- **Research Question**: *Does combining canary-file interactions with contextual filesystem behavior improve detection quality and reduce simulated file damage compared with canary-only and behavior-only detection?*
- **Primary Objectives**:
  1. Build a lightweight, modular, user-space detection architecture on macOS (Apple Silicon M1).
  2. Implement and fairly compare three detection paradigms (Baseline, Canary-Only, Hybrid) consuming identical normalized event streams.
  3. Safely simulate benign workloads and ransomware encryption in an isolated sandbox.
  4. Conduct 180 controlled empirical trials and recalculate all statistical metrics.
- **Formal Hypotheses**:
  - **$H_1$ (False-Positive Suppression)**: Temporal corroboration eliminates false alarms from innocent canary reads ($\text{FPR} = 0.0\%$).
  - **$H_2$ (Damage Reduction)**: Canary-assisted detection halts attacks significantly faster than baseline heuristics, reducing file damage by $>70\%$.
  - **$H_3$ (Universal Superiority)**: Hybrid detection outperforms baseline and canary-only models across all evaluation metrics.
- **Suggested Visual**: Flowchart connecting the Research Question to the three testable hypotheses.
- **Speaker Notes**:
  > "To answer this question scientifically, we formulated three formal hypotheses. First, that corroboration eliminates false positives. Second, that canary assistance cuts detection latency and damage. Third, that hybrid detection is universally superior across all metrics. As we will show later, hypotheses 1 and 2 are confirmed, but hypothesis 3 is rejected due to honeypot evasion—a vital scientific finding."
- **Evidence Source**: `CANARYSENTINEL_RESEARCH_PAPER.md`, Section 6.

---

## Slide 5: Literature Review & State-of-the-Art

- **Slide Title**: State-of-the-Art in Ransomware Defense
- **Key Reviewed Research**:
  - **CryptoDrop (Scaife et al., IEEE ICDCS 2016)**: Introduced entropy heuristics and file-type inspection on Windows; identified mass modification invariants.
  - **ShieldFS (Continella et al., ACM ACSAC 2016)**: Implemented self-healing copy-on-write drivers; demonstrated damage recovery but suffered 12–18% CPU overhead.
  - **R-Sentry (Al-rimy et al., Computers & Security 2019)**: Combined honeyfiles with memory cognitive trajectories; proved that decoy access requires behavioral context.
  - **RansomFisher (Ku et al., IEEE Access 2021)**: Proved that non-linear traversal completely evades decoy files; argued for behavior-only models.
- **CanarySentinel's Distinction**:
  - Operates in user space without invasive kernel drivers or hardware counters.
  - Concurrently feeds identical, debounced event streams into three parallel detectors for fair empirical comparison.
- **Suggested Visual**: Summary graphic of `literature/LITERATURE_COMPARISON_MATRIX.csv`.
- **Speaker Notes**:
  > "Our system builds upon landmark peer-reviewed research. Scaife's CryptoDrop proved that behavioral heuristics catch ransomware, while Continella's ShieldFS showed how containment reduces damage. Al-rimy's R-Sentry demonstrated the value of combining honeyfiles with behavior. However, Ku's RansomFisher proved that canaries can be bypassed. CanarySentinel provides the first rigorous, side-by-side empirical comparison of these paradigms on macOS."
- **Evidence Source**: `literature/REFERENCES.md`, `literature/LITERATURE_REVIEW.md`.

---

## Slide 6: CanarySentinel System Architecture

- **Slide Title**: Modular System Architecture
- **Core Subsystems**:
  1. **Strict Sandbox (`sandbox/`)**: Enforces path resolution bounds; prevents symlink traversal or host file tampering.
  2. **Canary Decoy Manager**: Deploys 8 strategic decoys (`000_canary.txt`, `_decoy.pdf`, `.hidden_canary.db`) with SHA-256 baselines.
  3. **Filesystem Monitor (Watchdog)**: Asynchronously captures macOS `FSEvents` callbacks.
  4. **Event Normalizer & Debouncer**: Deduplicates OS event flushes within a 100 ms sliding window.
  5. **Parallel Detector Suite**: Concurrently runs Baseline, Canary-Only, and Hybrid engines.
  6. **Risk Engine**: Normalizes threat severity ($0–100$) and generates evidence strings.
  7. **Simulated Response Manager**: Terminates verified simulator PIDs via POSIX signals (`SIGTERM`).
  8. **Persistence & UI**: SQLite 3 (WAL mode) and 6-page interactive Streamlit dashboard.
- **Suggested Visual**: Diagram `diagrams/system_architecture.mmd`.
- **Speaker Notes**:
  > "Here is our high-level architecture. At the bottom is the sandbox directory where both legitimate user documents and 8 strategic canary decoys reside. When filesystem changes occur, macOS FSEvents notifies our Watchdog monitor. The Event Normalizer debounces raw OS bursts into clean NormalizedEvent objects. Crucially, all three detectors receive this exact same event stream simultaneously, feeding alerts into our Risk Engine, SQLite database, and Streamlit dashboard."
- **Evidence Source**: `diagrams/system_architecture.mmd`, `canary_sentinel/core/`.

---

## Slide 7: The Three Detection Configurations

- **Slide Title**: Three Evaluated Detection Paradigms
- **Configuration A: Baseline Detector (Behavior-Only Heuristics)**:
  - Evaluates operation velocity and burst volume across the directory tree.
  - Threshold: Rate $> 5\text{ ops/sec}$ AND Burst $> 5\text{ ops}$ in sliding window.
  - *No awareness of canary files.*
- **Configuration B: Canary-Only Detector (Decoy Tripwire)**:
  - Intercepts any file event where `is_canary = True`.
  - Triggers immediately upon `MODIFY`, `DELETE`, or `RENAME`.
  - *No evaluation of surrounding context or velocity.*
- **Configuration C: Hybrid Detector (Correlated Context)**:
  - Evaluates a 5.0-second sliding event deque.
  - Condition: $(E_{\text{canary}} \in W_{5.0\text{s}}) \wedge (\text{Count}(E_{\text{context}} \in W_{5.0\text{s}}) \ge 3)$.
  - *Requires both spatial decoy contact AND kinematic burst velocity.*
- **Suggested Visual**: Diagram `diagrams/detection_workflow.mmd`.
- **Speaker Notes**:
  > "To ensure rigorous evaluation, we implemented three distinct detectors. Configuration A is purely behavioral, tracking operation rates regardless of file identity. Configuration B is a pure canary tripwire, firing the instant a decoy is touched. Configuration C is our proposed hybrid engine: it maintains a 5-second sliding window and only fires if a canary hit is accompanied by at least three rapid contextual file operations. This dual condition is the mathematical heart of our false-alarm suppression."
- **Evidence Source**: `canary_sentinel/detectors/`.

---

## Slide 8: The Hybrid Correlation Mechanism

- **Slide Title**: Temporal Corroboration in Action
- **Case 1: Accidental Decoy Read (Benign Scenario B3)**:
  - User or desktop indexer opens `000_canary.txt`.
  - Canary-Only triggers an immediate **False Alarm (FP)**.
  - Hybrid inspects 5.0s window: surrounding velocity $= 0 < 3$ ops.
  - **Hybrid suppresses alert $\rightarrow$ 0% False Positive Rate.**
- **Case 2: Ransomware Attack with Canary (Suspicious Scenario S5)**:
  - Malicious process overwrites `000_canary.txt` and starts bulk encryption.
  - Hybrid inspects window: canary hit corroborated by 3 rapid user file writes.
  - **Hybrid fires Critical Alert in 26.1 ms $\rightarrow$ Process Terminated $\rightarrow$ 90.8% Damage Prevented.**
- **Suggested Visual**: Sequence diagram `diagrams/hybrid_correlation.mmd`.
- **Speaker Notes**:
  > "This diagram demonstrates the power of temporal correlation. On the left, an innocent user reads a canary file. The Canary-Only detector panics and triggers a false alarm. But the Hybrid engine checks the sliding buffer, sees zero surrounding file modifications, and cleanly suppresses the alert. On the right, during a genuine ransomware attack, the canary hit is instantly corroborated by rapid writes to adjacent user documents, triggering an immediate kill signal in 26 milliseconds."
- **Evidence Source**: `diagrams/hybrid_correlation.mmd`.

---

## Slide 9: Standardized Behavioral Scenarios

- **Slide Title**: Controlled Workload Suite (6 Scenarios)
- **Benign Scenarios (Negative Class, Ground Truth = 0)**:
  - **B1 (`benign_single_read`)**: Open and read 1 document. (Baseline for quiet system).
  - **B2 (`benign_bulk_docs`)**: Developer rapidly edits 10 documents in 1 second. (Tests resistance to compilation/archiving).
  - **B3 (`canary_accidental_read`)**: Single read of `000_canary.txt`. (Tests decoy false-alarm suppression).
  - **B4 (`mixed_burst`)**: Rapid burst of 3 non-canary file operations. (Tests edge-case rate tolerance).
- **Suspicious Scenarios (Positive Class, Ground Truth = 1)**:
  - **S5 (`canary_plus_rapid_bulk`)**: Fast encryption overwriting 1 canary + 10 user documents. (Standard alphabetical ransomware).
  - **S6 (`rapid_bulk_without_canary`)**: Fast encryption of 10 user documents deliberately evading canaries. (Tests decoy evasion resilience).
- **Suggested Visual**: Grid illustration comparing benign developer file patterns vs. malicious traversal patterns.
- **Speaker Notes**:
  > "We constructed six standardized scenarios to stress-test our detectors. Scenarios B1 through B4 represent legitimate everyday workloads—including developer batch saves and accidental decoy inspections. Scenarios S5 and S6 represent ransomware attacks. Notice Scenario S6: here, the simulator encrypts 10 user files while deliberately avoiding every canary decoy. This scenario specifically tests what happens when an attacker knows or guesses how to evade honeypots."
- **Evidence Source**: `canary_sentinel/simulator/activity_simulator.py`.

---

## Slide 10: Experimental Methodology & Rigor

- **Slide Title**: Experimental Setup & Integrity Controls
- **Testing Corpus ($N = 180$ Controlled Trials)**:
  - 3 Detection Configurations $\times$ 6 Scenarios $\times$ 10 Repetitions = **180 Trials**.
  - All 180 trials executed, verified, and persistently stored in `canary_sentinel.db`.
- **Scientific Integrity Controls**:
  1. **Strictly Sandboxed Execution**: Synthetic random byte generation; zero weaponized payloads.
  2. **Equi-Telemetry Guarantee**: All three detectors consume identical, debounced event sequences.
  3. **Zero-Fabrication Commitment**: All metrics independently recalculated from stored trial rows.
  4. **Statistical Derivation**: 95% Confidence Intervals computed via Student's $t$-distribution.
- **Suggested Visual**: Experiment runner pipeline diagram `diagrams/experiment_workflow.mmd`.
- **Speaker Notes**:
  > "Our experimental methodology follows strict academic standards. We conducted 180 distinct trials—10 repetitions for each of the six scenarios across all three detector configurations. Every single trial was logged to SQLite with timestamps, latency, files damaged, and system metrics. All 180 runs completed without a single crash or missing record. Most importantly, we did not fabricate or cherry-pick data; we report all empirical outcomes, including when our hybrid model failed."
- **Evidence Source**: `experiments/EXPERIMENTAL_DATA.csv`, `experiments/STATISTICAL_ANALYSIS.md`.

---

## Slide 11: Side-by-Side Empirical Performance Matrix

- **Slide Title**: Experimental Results: The Grand Comparison ($N = 180$)
- **Comparative Results Table**:

| Evaluated Metric | Baseline (Config A) | Canary-Only (Config B) | Hybrid (Config C) |
|:---|:---:|:---:|:---:|
| **Total Completed Trials** | 60 | 60 | 60 |
| **True Positives (TP)** | 20 | 10 | 10 |
| **False Positives (FP)** | 10 | 10 | **0** |
| **True Negatives (TN)** | 30 | 30 | **40** |
| **False Negatives (FN)** | **0** | 10 | 10 |
| **Precision** | 66.67% (20/30) | 50.00% (10/20) | **100.00%** (10/10) |
| **Recall (Sensitivity)** | **100.00%** (20/20) | 50.00% (10/20) | 50.00% (10/20) |
| **$F_1$-Score** | **0.8000** | 0.5000 | 0.6667 |
| **False Positive Rate (FPR)** | 25.00% (10/40) | 25.00% (10/40) | **0.00%** (0/40) |
| **Mean Detection Latency** | 147.1 ms | **18.9 ms** | 26.1 ms |
| **95% Confidence Interval** | $\pm 36.5$ ms | $\pm 3.4$ ms | $\pm 5.2$ ms |

- **Suggested Visual**: Grouped bar chart comparing Precision, Recall, and False Positive Rate across A, B, and C.
- **Speaker Notes**:
  > "This is our master empirical performance matrix. Please focus on two key rows. First, look at False Positive Rate: both Baseline and Canary-Only suffer a crippling 25% false alarm rate. Hybrid achieves a flawless 0.0% false positive rate and 100% precision! However, look at Recall: Baseline catches 100% of attacks, while Hybrid catches only 50%. Why? Because Hybrid missed Scenario S6 entirely when canaries were evaded. This is why Baseline achieved a higher overall F1-score of 0.80 versus Hybrid's 0.67."
- **Evidence Source**: `experiments/DETECTOR_COMPARISON.csv`, `experiments/CONFUSION_MATRICES.csv`.

---

## Slide 12: Scenario-by-Scenario Failure Analysis

- **Slide Title**: Scenario-Level Breakdown: Where Each Detector Fails
- **Behavioral Attribution Matrix**:

| Scenario | Ground Truth | Baseline | Canary-Only | Hybrid | Failure Mode Explanation |
|:---|:---:|:---:|:---:|:---:|:---|
| **B1 (Single Read)** | Benign | TN (0/10) | TN (0/10) | TN (0/10) | All correct: quiet system. |
| **B2 (Developer Batch)** | Benign | **FP (10/10)** | TN (0/10) | TN (0/10) | **Baseline Fails**: Volume $>5$ ops/s triggers false alarm. |
| **B3 (Canary Read)** | Benign | TN (0/10) | **FP (10/10)** | TN (0/10) | **Canary-Only Fails**: Decoy read triggers false alarm. |
| **B4 (Mixed Burst)** | Benign | TN (0/10) | TN (0/10) | TN (0/10) | All correct: burst under threshold. |
| **S5 (Attack w/ Canary)** | Attack | **TP (10/10)** | **TP (10/10)** | **TP (10/10)** | All detect: Hybrid halts attack in 26.1 ms. |
| **S6 (Attack Skipping Decoy)**| Attack | **TP (10/10)** | **FN (10/10)** | **FN (10/10)** | **Deception Fails**: Malware evades all canaries. |

- **Suggested Visual**: Color-coded matrix (Green for correct, Red for error) illustrating each scenario outcome.
- **Speaker Notes**:
  > "Examining the scenario breakdown reveals the exact mechanics of each failure mode. In B2, Baseline fails because 10 rapid developer edits look like ransomware. In B3, Canary-Only fails because a user read a decoy file. Hybrid is the only detector that handles both B2 and B3 correctly with zero errors! But in Scenario S6, when the attacker encrypts 10 files without touching canaries, Canary-Only and Hybrid are completely blind. Baseline's volume heuristic is the only engine that catches it."
- **Evidence Source**: `experiments/SCENARIO_RESULTS.csv`.

---

## Slide 13: Latency & Containment Efficacy

- **Slide Title**: Detection Latency & File Damage Reduction
- **Detection Latency Across True Positives**:
  - **Baseline**: Mean $147.1\text{ ms}$ (Median: $142.0\text{ ms}$, $\text{CI}_{95} = \pm 36.5\text{ ms}$).
  - **Canary-Only**: Mean $18.9\text{ ms}$ (Median: $16.2\text{ ms}$, $\text{CI}_{95} = \pm 3.4\text{ ms}$).
  - **Hybrid**: Mean $26.1\text{ ms}$ (Median: $25.8\text{ ms}$, $\text{CI}_{95} = \pm 5.2\text{ ms}$).
- **Containment and Damage Prevention**:
  - **Scenario S5 (Attack with Canary)**:
    - Baseline: 1.10 files damaged $\rightarrow$ **75.42% ops prevented**.
    - Hybrid: 0.10 files damaged $\rightarrow$ **90.83% ops prevented** (10.9/12 planned ops halted).
  - **Scenario S6 (Attack Evading Canary)**:
    - Baseline: 5.00 files damaged $\rightarrow$ **55.24% ops prevented**.
    - Hybrid: 10.00 files damaged $\rightarrow$ **0.00% ops prevented** (Missed completely).
  - **Aggregated Ops Prevented**: $(90.83\% \times 10 + 0.0\% \times 10) / 20 = \mathbf{45.42\%}$.
- **Suggested Visual**: Horizontal bar charts comparing detection latency (ms) and damaged files count.
- **Speaker Notes**:
  > "Speed is everything in ransomware containment. In Scenario S5, Hybrid alerts in just 26 milliseconds—over five times faster than Baseline's 147 milliseconds. Because it alerted so fast, the response manager halted the process after only 0.1 files were damaged on average, preventing 90.8% of planned operations. However, in S6, because Hybrid never alerted, all 10 files were damaged. This explains why Hybrid's aggregated operations prevented is 45.4%: it prevented 90.8% when canaries were hit, and 0% when canaries were evaded."
- **Evidence Source**: `experiments/STATISTICAL_ANALYSIS.md`, Section 5.

---

## Slide 14: System Overhead & Efficiency

- **Slide Title**: System Resource Utilization (macOS Apple Silicon M1)
- **Host & Process Telemetry Across All 180 Runs**:
  - **Mean CPU Utilization**:
    - Baseline: **25.93%**
    - Canary-Only: **26.56%**
    - Hybrid: **25.40%**
  - **Mean RAM Footprint**:
    - Baseline: **37.18 MB**
    - Canary-Only: **37.35 MB**
    - Hybrid: **37.70 MB**
- **Engineering Highlights**:
  - In-memory 5-second sliding window deque introduces **zero measurable CPU penalty** ($\Delta \text{CPU} = 0.53\%$).
  - Total process memory remains strictly bounded below **38 MB**.
  - Operates efficiently on low-spec hardware (8 GB unified memory).
- **Suggested Visual**: System metrics telemetry gauges showing CPU and RAM stability.
- **Speaker Notes**:
  > "A practical endpoint security tool cannot hog host resources. We monitored CPU and memory usage continuously across all 180 runs using psutil. As shown, the entire CanarySentinel Python engine—including the Watchdog daemon, SQLite logging, and the hybrid sliding buffer—consumed less than 38 megabytes of RAM and approximately 25% of a single CPU core during heavy burst activity. The sliding window correlation overhead is completely negligible."
- **Evidence Source**: `canary_sentinel/experiments/metrics.py`, `experiments/DETECTOR_COMPARISON.csv`.

---

## Slide 15: Software Engineering & Dashboard

- **Slide Title**: Architecture, Testing & Interactive Dashboard
- **Robust Software Engineering Standards**:
  - **Automated Test Suite**: 45 unit and integration tests passing (`pytest -v` in 4.69s).
  - Tests cover canary integrity, FSEvents queueing, debouncing, risk scoring, and sandbox path validation.
- **Interactive Streamlit Dashboard**:
  - **View 1: Overview & Telemetry**: Real-time event counts, canary status, system health.
  - **View 2: Decoy & Sandbox Controls**: Deploy, inspect, and regenerate canaries.
  - **View 3: Live Event Stream**: Granular normalized event feed with filtering.
  - **View 4: Incidents & Alerts**: Threat severity, risk score explanations ($0–100$).
  - **View 5: Simulation & Experiments**: Run single workloads or batch trials.
  - **View 6: Comparative Research Analysis**: Side-by-side metric tables and CSV export.
- **Suggested Visual**: Screenshot collage of the Streamlit dashboard tabs.
- **Speaker Notes**:
  > "CanarySentinel is not a theoretical model; it is a fully functioning, interactive software prototype. We implemented 45 comprehensive unit and integration tests, all of which pass cleanly in under 5 seconds. Furthermore, we built a 6-page interactive Streamlit dashboard allowing operators to monitor live telemetry, deploy decoys, execute automated experiments, inspect alerts, and export data directly to CSV."
- **Evidence Source**: `canary_sentinel/dashboard/app.py`, `tests/`.

---

## Slide 16: Research Contribution & Defense-in-Depth

- **Slide Title**: Architectural Recommendation: The Defense-in-Depth Cascade
- **Key Research Takeaway**:
  - **Hybrid is NOT universally superior**: It should never replace behavioral monitoring.
  - **The Solution is Tiered Defense-in-Depth**:
- **Proposed Production EDR Architecture**:
  1. **Tier 1 (Fast-Path Containment - Hybrid Engine)**:
     - Trigger: Correlated Canary Hit + Context Velocity.
     - Action: Immediate, aggressive process termination (`SIGKILL`) and network quarantine.
     - Efficacy: Latency 26 ms, 100% Precision, 0.0% False Alarms, $<1$ file damaged.
  2. **Tier 2 (Safety-Net Fallback - Baseline Behavioral Engine)**:
     - Trigger: High Operation Velocity in absence of canary events.
     - Action: Non-destructive process suspension (`SIGSTOP`) and administrator review.
     - Efficacy: 100% Recall, catches canary evasion attacks (Scenario S6).
- **Suggested Visual**: Two-tier cascade flowchart showing Fast-Path vs. Fallback logic.
- **Speaker Notes**:
  > "The most important intellectual contribution of our project is proving that hybrid detection and behavioral monitoring are complementary. Because Hybrid achieves 100% precision and zero false positives, security tools can safely bind aggressive, automated kill signals to it. When an attacker evades canaries, our Tier 2 behavioral safety net catches them, suspending the process for review. This cascade delivers both rapid containment and complete threat coverage."
- **Evidence Source**: `results/RESEARCH_FINDINGS.md`, Section 5.

---

## Slide 17: Limitations & Future Scope

- **Slide Title**: Honest Limitations & Future Engineering Directions
- **Acknowledged Limitations**:
  - **User-Space Latency**: Because `watchdog` operates asynchronously in user space, write operations are committed to storage before notifications arrive (10–25 ms OS delay).
  - **Synthetic Simulation**: Evaluated against simulated pseudo-random encryption workloads rather than live, kernel-level weaponized malware.
  - **Decoy Discovery**: Sophisticated malware could identify canaries by inspecting file metadata, entropy baselines, or naming patterns.
- **Future Scope**:
  1. **Apple EndpointSecurity.framework**: Port to native Darwin `es_client` system extension for synchronous pre-write authorization blocking.
  2. **Dynamic Decoy Placement**: Use reinforcement learning to autonomously place decoys along predicted adversary traversal paths.
  3. **Live Malware Benchmarking**: Test against weaponized samples in an air-gapped hypervisor sandbox.
- **Suggested Visual**: Conceptual diagram showing migration from user-space FSEvents to `EndpointSecurity.framework`.
- **Speaker Notes**:
  > "To maintain scientific honesty, we acknowledge several limitations. Running in user space means our notifications arrive asynchronously, meaning we cannot prevent the very first write. Furthermore, we evaluated synthetic random writes rather than weaponized malware. For future work, we plan to port CanarySentinel to Apple's native EndpointSecurity framework, allowing synchronous pre-write interception, and to implement machine learning for adaptive decoy placement."
- **Evidence Source**: `CANARYSENTINEL_RESEARCH_PAPER.md`, Sections 18 & 21.

---

## Slide 18: Conclusion & Acknowledgement

- **Slide Title**: Summary of Findings & Acknowledgements
- **Core Summary**:
  - Built CanarySentinel, an end-to-end endpoint ransomware detection and response architecture.
  - Demonstrated that temporal corroboration achieves **100% precision** and **0% false alarms**, reducing detection latency to **26.1 ms** and file damage to **0.1 files**.
  - Empirically proved that pure deception fails against decoy evasion, mandating a multi-tiered defense-in-depth model.
  - Validated all findings across 180 controlled empirical trials with 45 passing automated tests.
- **Acknowledgements**:
  - Heartfelt gratitude to our supervisor, **[Supervisor Name]**, and faculty members of the Department of Computer Science and Engineering.
- **Questions & Open Defence**: We invite questions and technical discussion from the examination committee.
- **Suggested Visual**: Concluding slide featuring repository link and contact details.
- **Speaker Notes**:
  > "In conclusion, CanarySentinel proves that canary-triggered behavioral corroboration solves the false-alarm dilemma of deception technology, while highlighting the critical necessity of defense-in-depth. We thank our supervisor, department faculty, and the evaluation committee for your time and guidance. We are now open for your questions."
- **Evidence Source**: `CANARYSENTINEL_FINAL_PROJECT_REPORT.md`, Section 27.

