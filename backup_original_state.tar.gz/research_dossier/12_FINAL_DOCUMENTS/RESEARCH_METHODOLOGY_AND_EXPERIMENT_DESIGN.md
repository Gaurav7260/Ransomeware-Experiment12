# Research Methodology and Experimental Design

**Document**: `research_dossier/12_FINAL_DOCUMENTS/RESEARCH_METHODOLOGY_AND_EXPERIMENT_DESIGN.md`  
**Academic Context**: B.Tech Capstone Project & Peer-Reviewed Research  

---

## 1. Experimental Variables

### A. Independent Variables
1. **Detection Configuration**:
   - Level 1: Configuration A (Baseline Behavioral Heuristics)
   - Level 2: Configuration B (Canary-Only Decoy Tripwire)
   - Level 3: Configuration C (Hybrid Correlated Context)
2. **Workload Scenario**:
   - 4 Benign Workloads: B1 (`Normal File Editing`), B2 (`Bulk Copying`), B3 (`Canary Touch Without Follow-up`), B4 (`Bulk Renaming`).
   - 2 Attack Workloads: S5 (`Canary Touch + Rapid Bulk`), S6 (`Rapid Bulk Without Canary`).

### B. Dependent Variables
1. **Classification Accuracy Metrics**: True Positives (TP), False Positives (FP), True Negatives (TN), False Negatives (FN), Precision, Recall, F1-Score, False Positive Rate (FPR), Specificity.
2. **Temporal Performance**: Detection Latency ($t_{\text{alert}} - t_{\text{start}}$) in milliseconds.
3. **Mitigation Efficacy**: Simulated Files Damaged, Prevented File Operations Count, Operations Prevented Percentage.
4. **System Resource Overhead**: CPU utilization percentage and Resident Set Size (RSS) memory in megabytes.

### C. Controlled Variables
- Host hardware (Apple Silicon M1, 8 GB RAM).
- Operating system (macOS Sequoia 15.3, Darwin 24.3.0).
- Filesystem sandbox root (`./sandbox`) and directory depth.
- Number, filenames, and positions of canary decoy files (8 active canaries).
- Event normalizer debouncing window (50 ms).
- Equi-telemetry normalized event stream.
- Inter-trial settling delay (150 ms).

---

## 2. Ground Truth & Classification Assignment

| Scenario Code | Scenario Name | Category | Ground Truth Class | Target Files Planned | Expected Detection Behavior |
|:---:|:---|:---:|:---:|---:|:---|
| **B1** | Normal File Editing | Benign | Negative (0) | 5 | All detectors should pass without alert. |
| **B2** | Bulk Copying | Benign | Negative (0) | 6 | All detectors should pass without alert. |
| **B3** | Canary Touch Without Follow-up | Benign | Negative (0) | 4 | Canary-Only expected to FP; Hybrid expected to suppress. |
| **B4** | Bulk Renaming | Benign | Negative (0) | 6 | Baseline expected to FP; Canary & Hybrid expected to pass. |
| **S5** | Canary Touch + Rapid Bulk | Attack | Positive (1) | 12 | All detectors expected to trigger TP. |
| **S6** | Rapid Bulk Without Canary | Attack | Positive (1) | 10 | Baseline expected to trigger TP; Canary & Hybrid expected to FN. |

---

## 3. Sampling Size & Statistical Power

- **Factorial Design**: $3 \text{ Configurations} \times 6 \text{ Scenarios} \times 10 \text{ Repetitions} = \mathbf{180 \text{ Total Trials}}$.
- **Sample Distribution per Detector**:
  - $N = 60$ trials per detector configuration.
  - $N_{\text{neg}} = 40$ benign trials per detector.
  - $N_{\text{pos}} = 20$ attack trials per detector.
- **Statistical Tests Employed**:
  - Continuous metrics (Latency): Welch's two-sample unequal variance $t$-test, Mann-Whitney U test, Student's $t$ 95% confidence intervals.
  - Categorical metrics (FPR, Recall): Fisher's exact test on $2 \times 2$ contingency tables.
  - Normality verification: Shapiro-Wilk test.

