# CanarySentinel — Master Technical Documentation & Architecture Reference

**Document**: `research_dossier/12_FINAL_DOCUMENTS/CANARYSENTINEL_TECHNICAL_DOCUMENTATION.md`  
**Target Audience**: Software Engineers, Security Architects, and Code Reviewers  
**Language/Platform**: Python 3.12+ / Darwin macOS on Apple Silicon M1 (arm64)  

---

## 1. Codebase Structure & Package Layout

```
canary_sentinel/
├── __init__.py
├── core/
│   ├── config.py              # Pydantic/dataclass configuration hierarchies
│   ├── sandbox.py             # SandboxManager: strict path resolution and boundaries
│   └── utils.py               # Shannon entropy, file hashing, ISO timestamps
├── canary/
│   └── manager.py             # CanaryManager: deployment, integrity, in-memory lookup
├── monitoring/
│   ├── monitor.py             # FilesystemMonitor: Watchdog/FSEvents daemon thread
│   └── normalizer.py          # EventNormalizer: 50ms debouncing, NormalizedEvent schema
├── detection/
│   ├── base.py                # BaseDetector, DetectionDecision dataclasses
│   ├── baseline_detector.py   # BaselineDetector (Configuration A: velocity/volume)
│   ├── canary_detector.py     # CanaryDetector (Configuration B: decoy tripwire)
│   ├── hybrid_detector.py     # HybridDetector (Configuration C: correlated sliding window)
│   └── risk_engine.py         # RiskEngine: weighted scoring (0-100) & severity mapping
├── simulation/
│   ├── response_manager.py    # SimulatedResponseManager: internal block flag
│   ├── scenarios.py           # ScenarioDefinition, ScenarioHelper file generator
│   └── simulator.py           # ActivitySimulator: 6 safe synthetic workloads
├── storage/
│   ├── db.py                  # Database: SQLite 3 with WAL mode and connection pooling
│   └── models.py              # Dataclass entity schemas (Event, Alert, Canary, Scenario)
├── experiments/
│   ├── runner.py              # ExperimentRunner: automated 180-trial batch coordinator
│   └── metrics.py             # MetricsCalculator: precision, recall, F1, latency CIs
└── dashboard/
    └── app.py                 # Multi-page interactive Streamlit web dashboard
```

---

## 2. Core Dataclass & Event Schemas

### `NormalizedEvent` (`canary_sentinel/storage/models.py`)
```python
@dataclass
class NormalizedEvent:
    event_id: str             # Unique UUID string
    timestamp: float          # High-resolution Unix Epoch timestamp (seconds)
    iso_timestamp: str        # Human-readable ISO-8601 UTC string
    event_type: str           # "CREATE", "MODIFY", "DELETE", "MOVE"
    path: str                 # Sandbox-relative canonical POSIX path
    src_path: Optional[str]   # Original source path for MOVE events
    extension: str            # Lowercase file extension (e.g., ".txt")
    is_canary: bool           # True if path is a registered canary decoy
    size_bytes: int           # Current file size on disk
    entropy: float            # Shannon entropy in bits/byte (0.0 to 8.0)
    process_id: Optional[int] # Originating PID if resolvable
    process_name: Optional[str]
    scenario_id: Optional[str]# Tagged scenario trial identifier
```

### `AlertRecord` (`canary_sentinel/storage/models.py`)
```python
@dataclass
class AlertRecord:
    alert_id: str
    timestamp: float
    iso_timestamp: str
    detector_config: str       # "baseline", "canary_only", "hybrid"
    severity: str              # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    risk_score: int            # Standardized score: 0 to 100
    confidence: float          # Statistical confidence: 0.0 to 1.0
    triggering_event_id: str
    triggering_event_summary: str
    supporting_event_ids: List[str]
    explanation: str
    response_status: str       # "PENDING", "BLOCKED", "IGNORED"
    scenario_id: Optional[str]
```

---

## 3. Detailed Detection Algorithms

### A. Baseline Behavioral Algorithm
1. Prune internal history deque: retain events within `burst_window_seconds` (2.0s).
2. Compute `total_ops = len(window_events)`, `unique_files = len({e.path})`.
3. Check Heuristics:
   - Burst velocity: `total_ops >= 8` and `unique_files >= 3` $\rightarrow$ `risk_score += 45`.
   - Entropy surge: `entropy >= 7.2` on modified files $\rightarrow$ `risk_score += 35`.
   - Mass renaming: `len(rename_ops) >= 4` $\rightarrow$ `risk_score += 30`.
   - Suspicious extension: extension in `{".locked", ".crypto", ...}` $\rightarrow$ `risk_score += 35`.
4. If `risk_score >= 50`: dispatch alert.

### B. Canary-Only Algorithm
1. Check `if not event.is_canary: return None`.
2. Check `if event.event_type not in {"MODIFY", "DELETE", "MOVE"}: return None`.
3. Immediately dispatch alert with `risk_score = 85`, `severity = CRITICAL`.

### C. Hybrid Correlated Sliding Window Algorithm
1. On event receipt: prune history older than $2 \times \text{window}$ (6.0s).
2. If `event.is_canary`: buffer candidate `self._pending_canary_event = event`.
3. Evaluate contextual companion files in $[t_{\text{canary}} - 3.0\text{s}, t_{\text{canary}} + 3.0\text{s}]$:
   - Criterion 1: $\ge 1$ companion file with entropy $\ge 7.2$ across $\ge 2$ targets.
   - Criterion 2: Velocity $\ge 3.0\text{ ops/sec}$ across $\ge 4$ events and $\ge 3$ targets.
   - Criterion 3: Mass churn sequence $\ge 6$ operations across $\ge 4$ targets.
4. If confirmed: dispatch high-priority alert (`risk_score = 90 + int(velocity * 2)`).
5. If window expires without companion activity: clear `self._pending_canary_event` (suppresses false alarm).

---

## 4. Configuration Hierarchies (`config.json`)

```json
{
  "sandbox": {
    "sandbox_dir": "./sandbox",
    "target_directories": ["documents", "backup", "projects"]
  },
  "canary": {
    "decoy_count": 8,
    "target_directories": ["documents", "backup", "projects"]
  },
  "normalizer": {
    "debounce_ms": 50,
    "max_file_size_entropy_mb": 10
  },
  "baseline": {
    "burst_window_seconds": 2.0,
    "burst_count_threshold": 8,
    "entropy_threshold": 7.2,
    "mass_rename_threshold": 4,
    "base_risk_score": 50
  },
  "canary_only": {
    "monitored_events": ["MODIFY", "DELETE", "MOVE"],
    "base_risk_score": 85
  },
  "hybrid": {
    "observation_window_seconds": 3.0,
    "burst_velocity_threshold": 3.0,
    "entropy_threshold": 7.2,
    "base_risk_score": 90
  },
  "response": {
    "auto_block": true,
    "minimum_severity": "HIGH",
    "risk_score_threshold": 70
  }
}
```

---

## 5. Security Boundaries and Troubleshooting

1. **Permission Denied on Sandbox**: Ensure the running user has read/write permissions to `./sandbox`.
2. **Streamlit Port Conflict**: If port 8501 is occupied, launch with `--server.port 8502`.
3. **Database Locks**: SQLite WAL mode prevents read locks, but ensure no external tool holds an exclusive write lock.

