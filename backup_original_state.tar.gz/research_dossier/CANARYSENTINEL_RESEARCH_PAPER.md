# Evaluating Canary-Triggered Behavioral Corroboration for Early Ransomware Detection and Damage Reduction

**Authors**: Research Team (B.Tech Final-Year Capstone Project)  
**Institution**: Department of Computer Science and Engineering  
**Date**: Academic Year 2025–2026  
**Document**: CANARYSENTINEL_RESEARCH_PAPER.md  

---

## Abstract

Cryptographic ransomware remains one of the most destructive threats to enterprise and consumer endpoints. Traditional antivirus signatures fail against zero-day and polymorphic payloads, while pure behavioral anomaly detectors suffer from elevated false-positive rates during benign batch workloads such as compilation or archiving. Conversely, deception-based tripwires (canary files) achieve rapid detection but are prone to false alarms caused by non-malicious user inspection and remain entirely blind to attacks that evade decoy locations. This paper investigates whether corroborating canary-file interactions with contextual filesystem behavioral telemetry improves detection quality and limits data damage compared with isolated baseline and canary-only models. We present **CanarySentinel**, a lightweight, macOS-compatible endpoint ransomware detection and risk-aware response architecture implemented in user space. CanarySentinel deploys decoy files, normalizes OS filesystem telemetry via an asynchronous event debouncing pipeline, and evaluates three concurrent detection configurations: Baseline (volume/velocity heuristics), Canary-Only (decoy tripwire), and Hybrid (temporal sliding-window correlation). In an empirical evaluation across 180 controlled sandboxed trials ($N = 180$), the Hybrid engine completely eliminated false positives (**Precision = 100.0%**, **FPR = 0.0%**), compared to an unacceptable 25.0% false-positive rate in both Baseline and Canary-Only configurations. In attacks targeting canaries, Hybrid achieved early containment in **26.1 ms**, limiting damage to **0.10 files** and preventing **90.83%** of planned destructive writes. However, in attacks that avoided canaries, Hybrid failed entirely (**Recall = 50.0%**, **$F_1 = 0.67$**), whereas Baseline detected all attacks (**Recall = 100.0%**, **$F_1 = 0.80$**). We conclude that while hybrid correlation successfully solves the false-alarm dilemma of deception systems, it must be paired with behavioral monitoring as a multi-layered defense-in-depth architecture.

---

## 1. Keywords

Ransomware Detection, Deception Technology, Canary Files, Behavioral Analysis, Temporal Correlation, Filesystem Telemetry, Endpoint Security, False Positive Suppression.

---

## 2. Introduction

Cryptographic ransomware encrypts high-value user documents—such as databases, source code, spreadsheets, and personal files—using hybrid asymmetric-symmetric ciphers (e.g., RSA-4096 and AES-256) and demands an extortion payment for the decryption key. Modern ransomware operations (Ransomware-as-a-Service, RaaS) have transitioned from mass phishing campaigns to targeted enterprise intrusions where automated multi-threaded encryption routines destroy thousands of files within minutes.

Defending endpoints against modern ransomware presents a fundamental trade-off between **detection speed** and **detection precision**:
1. **Speed**: Encryption is an irreversible, sequential process. Once plaintext data is overwritten with ciphertext and memory buffers are flushed, recovery without backups or paid keys is mathematically infeasible. Every millisecond of detection latency allows an attacker to permanently destroy additional user assets.
2. **Precision**: Automated containment mechanisms—such as process termination or host isolation—carry severe operational penalties if triggered accidentally. A security tool that mistakenly terminates legitimate software compilation or data backup pipelines introduces costly operational downtime.

Deception technology, particularly the deployment of honeypot "canary" files in user directories, offers an attractive fast-path trigger. Because normal user workflows do not interact with hidden or lexicographically prioritized decoy files, any modification targeting a canary provides an immediate indicator of unauthorized filesystem crawling. However, uncorroborated canary triggers generate catastrophic false alarms when backup daemons, antivirus scanners, or users accidentally read or modify a decoy. Furthermore, attackers can easily bypass canaries if their traversal algorithms do not follow standard alphabetical directory listings.

This paper addresses this challenge by designing, implementing, and empirically evaluating **CanarySentinel**, an endpoint architecture that cross-validates canary triggers against contextual filesystem velocity within a temporal sliding window.

---

## 3. Background

### 3.1 The Ransomware Execution Lifecycle
Crypto-ransomware execution follows a characteristic lifecycle:
- **Phase 1: Environment Discovery & Privilege Escalation**: Inspects local drives, network shares, and permissions.
- **Phase 2: Target File Enumeration**: Iterates directory trees (via DFS, BFS, or alphabetical sorting) to build an array of target file paths matching high-value extensions (`.docx`, `.xlsx`, `.pdf`, `.sql`).
- **Phase 3: Cryptographic Key Generation**: Generates ephemeral per-file symmetric keys (AES/ChaCha20) and encrypts them using an embedded public master key.
- **Phase 4: Destruction / Overwrite**: Reads target files, encrypts their contents, writes ciphertext to disk, and deletes or overwrites the original plaintext.
- **Phase 5: Extortion Notification**: Drops ransom notes (`README_RESTORE.txt`) and modifies wallpaper settings.

### 3.2 Information Entropy in File Analysis
Information entropy, formalized by Shannon (1948) [[REF-09]](literature/REFERENCES.md#ref-09), measures data randomness:

$$H(X) = -\sum_{i=1}^{n} P(x_i) \log_2 P(x_i)$$

Plaintext source code and text documents exhibit low entropy ($H \approx 2.5 - 4.5 \text{ bits/byte}$), whereas AES ciphertext approaches maximal entropy ($H \approx 7.9 - 8.0 \text{ bits/byte}$). However, modern documents such as `.docx` or `.zip` are already compressed, naturally exhibiting high entropy ($H > 7.5$), making pure entropy heuristics prone to false alarms during standard document editing.

---

## 4. Problem Statement

Existing endpoint ransomware defenses suffer from acute operational limitations:
- **Signature Defenses**: Static signatures (hashes, YARA) are bypassed by continuous polymorphism, packing, and in-memory execution.
- **Pure Behavioral Defenses**: Velocity and volume heuristics (e.g., detecting $> 5$ file modifications per second) trigger false positives during legitimate batch developer tasks (e.g., `git checkout`, software compilation, archive extraction).
- **Pure Canary Defenses**: Decoy tripwires trigger false positives on innocent administrative reads and suffer complete failure (100% false negatives) when ransomware skips or evades decoy files.

There is a critical lack of empirical research quantifying how **temporal corroboration**—combining spatial decoy triggers with temporal kinematic velocity—impacts the trade-off between false-positive rates, detection latency, and file damage on Unix-like operating systems.

---

## 5. Research Objectives

1. Design and implement a modular, user-space endpoint detection system on macOS capable of deploying canaries, normalizing asynchronous filesystem events, and executing automated containment.
2. Implement three distinct detection configurations:
   - **Baseline (Configuration A)**: Volume and velocity heuristics without decoys.
   - **Canary-Only (Configuration B)**: Immediate alert on canary interaction.
   - **Hybrid (Configuration C)**: Correlated temporal sliding window requiring canary engagement and contextual burst activity.
3. Construct a harmless activity simulator executing controlled benign workloads and simulated ransomware encryption.
4. Execute an empirical evaluation across 180 controlled trials ($N = 180$) to measure Precision, Recall, $F_1$-score, False Positive Rate, Detection Latency, and Simulated File Damage.

---

## 6. Research Question and Hypotheses

### Primary Research Question
*Does combining canary-file interactions with contextual filesystem behavior improve ransomware detection quality and reduce simulated file damage compared with canary-only and behavior-only detection?*

### Formal Hypotheses
- **$H_1$ (False-Positive Suppression)**: Corroborating canary interactions with surrounding filesystem velocity within a 5.0-second sliding window eliminates false positives caused by non-malicious canary reads, achieving $\text{FPR} = 0.0\%$.
- **$H_2$ (Damage Reduction via Rapid Containment)**: Canary-assisted detection detects ransomware significantly faster than baseline behavioral heuristics, reducing simulated file damage by $>70\%$ during active attacks.
- **$H_3$ (Universal Superiority)**: The hybrid detection configuration universally outperforms both baseline and canary-only models across all primary evaluation metrics.

---

## 7. Related Work

The academic literature on ransomware defense spans three major paradigms:

1. **Behavioral Heuristics and File-System Interception**:
   - **CryptoDrop** (Scaife et al., 2016) [[REF-01]](literature/REFERENCES.md#ref-01) pioneered behavioral heuristics using minifilter drivers on Windows, monitoring entropy deltas and burst deletions.
   - **ShieldFS** (Continella et al., 2016) [[REF-02]](literature/REFERENCES.md#ref-02) implemented a self-healing filesystem driver using copy-on-write shadow copies, achieving low damage but incurring 12–18% CPU overhead.
   - **GuardFS** (Park et al., 2021) [[REF-05]](literature/REFERENCES.md#ref-05) introduced VFS-level inline file staging on Linux, buffering writes until process reputation was established.

2. **Deception and Honeypot Systems**:
   - **Moore** (2017) [[REF-07]](literature/REFERENCES.md#ref-07) evaluated honeypot files in enterprise shares, establishing that lexicographical naming (`000_canary.txt`) catches standard alphabetical traversal.
   - **R-Sentry** (Al-rimy et al., 2019) [[REF-04]](literature/REFERENCES.md#ref-04) combined honeyfiles with process memory cognitive trajectories, demonstrating the need for behavioral context around decoys.

3. **Behavioral Detection Without Decoys**:
   - **RansomFisher** (Ku et al., 2021) [[REF-06]](literature/REFERENCES.md#ref-06) analyzed the structural fragility of honeypots, demonstrating that randomized traversal completely bypasses decoy tripwires and advocating for pure behavior-tree monitoring.

---

## 8. Research Gap

Prior studies evaluated either pure behavioral engines (e.g., CryptoDrop, GuardFS) or pure honeypots (e.g., Moore). Complex hybrid systems (e.g., RWGuard, R-Sentry) relied on invasive kernel drivers or hardware performance counters that impair operating system stability and cross-platform portability. Crucially, existing literature lacks side-by-side empirical evaluations feeding **identical, normalized event streams** into Baseline, Canary-Only, and Hybrid engines under explicit decoy-evasion conditions (Scenario S6). CanarySentinel fills this research gap.

---

## 9. Proposed Methodology

CanarySentinel employs a four-tiered architectural methodology:
1. **Isolated Sandbox Environment**: All filesystem operations are strictly confined to a dedicated local directory (`sandbox/`), with automated path resolution preventing symlink traversal or unauthorized disk writes.
2. **Standardized Event Normalization**: Asynchronous filesystem events from the OS are buffered, debounced (100 ms window), and converted into uniform `NormalizedEvent` records containing timestamps, absolute paths, operation types, and canary flags.
3. **Equi-Telemetry Evaluation**: All three detection engines consume identical normalized event sequences concurrently, guaranteeing mathematical fairness.
4. **Harmless Simulation and Simulated Containment**: Benign workloads and synthetic encryption routines operate exclusively on dummy text files within the sandbox, executing process containment via POSIX signals (`SIGTERM`) without modifying user data outside the sandbox.

---

## 10. System Architecture

CanarySentinel is organized into six interconnected subsystems:

```
+-------------------------------------------------------------------------+
|                         Streamlit Web Dashboard                         |
|   [Overview]  [Decoy Controls]  [Live Events]  [Alerts]  [Experiments]  |
+-------------------------------------------------------------------------+
                                     │ (Reads / Controls)
+-------------------------------------------------------------------------+
|                       Experiment & Metrics Engine                       |
|   - 180 Batch Trial Runner       - Metrics Calculator (TP, FP, TN, FN)  |
|   - Confidence Intervals         - SQLite Persistence Layer             |
+-------------------------------------------------------------------------+
                                     │
+-------------------------------------------------------------------------+
|                 Parallel Detection Engine Subsystem                     |
|  [Baseline Detector]     [Canary-Only Detector]      [Hybrid Detector]  |
|  - Rate Threshold: 5/s   - Decoy Flag Intercept     - Sliding Window: 5s|
|  - Burst Volume: 5 ops   - Immediate Alert          - Co-occurrence: 3  |
+-------------------------------------------------------------------------+
                                     ▲
                                     │ Normalized Event Stream
+-------------------------------------------------------------------------+
|                  Event Normalizer & Debounce Pipeline                   |
|   - Deduplication Window (100 ms)   - Path Canonicalization             |
+-------------------------------------------------------------------------+
                                     ▲
                                     │ FileSystemEvents
+-------------------------------------------------------------------------+
|                   Filesystem Monitoring Daemon (Watchdog)               |
|   - macOS FSEvents Listener         - Recursive Sandbox Watching        |
+-------------------------------------------------------------------------+
                                     ▲
                                     │ Disk I/O
+-------------------------------------------------------------------------+
|                    Dedicated Filesystem Sandbox                         |
|   - Canary Decoys (8 active)       - User Documents (*.txt, *.pdf)      |
|   - Strict Path Validation          - Harmless Simulator (Subprocess)    |
+-------------------------------------------------------------------------+
```

---

## 11. Implementation

CanarySentinel is implemented in Python 3.12 adhering to strict modular software engineering principles:

- **Canary Manager (`canary_manager.py`)**: Manages 8 active decoys (e.g., `000_canary.txt`, `_decoy.pdf`, `.hidden_canary.db`) strategically placed in top-level and nested directories. Computes initial SHA-256 hashes and maintains a registration database in SQLite.
- **Filesystem Monitor (`fs_monitor.py`)**: Implements an asynchronous event listener utilizing Python `watchdog` backed by macOS `FSEvents`.
- **Event Normalizer (`event_normalizer.py`)**: Debounces raw OS events within a 100 ms sliding window, discarding duplicate modify events caused by macOS buffer flushes.
- **Baseline Detector (`baseline_detector.py`)**: Tracks sliding window operation rates ($R_{\text{ops}} = \Delta N / \Delta t$). Triggers when operation rate exceeds 5 ops/sec and burst volume exceeds 5 operations.
- **Canary-Only Detector (`canary_detector.py`)**: Evaluates incoming events against registered canary paths. Triggers an alert immediately upon any `MODIFY`, `DELETE`, or `RENAME` targeting a canary.
- **Hybrid Detector (`hybrid_detector.py`)**: Maintains a 5.0-second sliding event deque. When a canary event is received, it queries the deque for surrounding filesystem operations. It triggers if and only if:

$$\text{Alert}_{\text{Hybrid}} = (E_{\text{canary}} \in W_{5.0\text{s}}) \wedge (\text{Count}(E_{\text{context}} \in W_{5.0\text{s}}) \ge 3)$$

- **Risk Engine (`risk_engine.py`)**: Synthesizes detector signals into standardized risk scores ($0 - 100$) and severity categories (Low, Medium, High, Critical).
- **Simulated Response Manager (`response_manager.py`)**: Intercepts alerts and issues targeted `SIGTERM` signals exclusively to the verified PID of the harmless simulator process.

---

## 12. Experimental Setup

### 12.1 Hardware and Software Environment
- **Hardware**: Apple Mac mini / MacBook (Apple Silicon M1, 8-core CPU, 8 GB unified memory).
- **Operating System**: macOS Sequoia 15 (Darwin Kernel 24.3.0, arm64).
- **Runtime**: Python 3.12.9 in a dedicated virtual environment (`.venv`).
- **Dependencies**: `watchdog 6.0.0`, `psutil 7.0.0`, `streamlit 1.43.0`, `pandas 2.2.3`, `pytest 8.3.5`.
- **Database**: SQLite 3.46.0 with WAL mode enabled.

### 12.2 Standardized Experimental Scenarios
Six standardized behavioral workloads were designed:
1. **B1 (`benign_single_read`)**: Simulates a user opening and reading a single document. (Ground truth: Benign)
2. **B2 (`benign_bulk_docs`)**: Simulates a developer rapidly modifying 10 text documents in 1 second. (Ground truth: Benign)
3. **B3 (`canary_accidental_read`)**: Simulates a user or indexer reading `000_canary.txt`. (Ground truth: Benign)
4. **B4 (`mixed_burst`)**: Simulates a short burst of 3 non-canary file operations. (Ground truth: Benign)
5. **S5 (`canary_plus_rapid_bulk`)**: Simulates rapid encryption (pseudo-random bytes) overwriting 1 canary and 10 user documents sequentially. (Ground truth: Attack)
6. **S6 (`rapid_bulk_without_canary`)**: Simulates rapid encryption overwriting 10 user documents while deliberately skipping canary files. (Ground truth: Attack)

Each scenario was repeated 10 times per configuration ($10 \times 6 \times 3 = 180$ total trials).

---

## 13. Results

### 13.1 Aggregate Performance Metrics

Table 1 presents the performance metrics recalculated from the 180 stored trials in `canary_sentinel.db`.

**Table 1: Detector Performance Comparison ($N = 180$)**

| Performance Metric | Baseline (Config A) | Canary-Only (Config B) | Hybrid (Config C) |
|:---|:---:|:---:|:---:|
| Total Trials ($N$) | 60 | 60 | 60 |
| True Positives (TP) | 20 | 10 | 10 |
| False Positives (FP) | 10 | 10 | **0** |
| True Negatives (TN) | 30 | 30 | **40** |
| False Negatives (FN) | **0** | 10 | 10 |
| **Precision** | 66.67% (20/30) | 50.00% (10/20) | **100.00%** (10/10) |
| **Recall** | **100.00%** (20/20) | 50.00% (10/20) | 50.00% (10/20) |
| **$F_1$-Score** | **0.8000** | 0.5000 | 0.6667 |
| **False Positive Rate (FPR)** | 25.00% (10/40) | 25.00% (10/40) | **0.00%** (0/40) |
| **Mean Latency ($\bar{x}$)** | 147.1 ms | **18.9 ms** | 26.1 ms |
| **Median Latency** | 142.0 ms | **16.2 ms** | 25.8 ms |
| Latency Std Dev ($s$) | $\pm 102.1$ ms | $\pm 7.7$ ms | $\pm 8.4$ ms |
| 95% Confidence Interval | $\pm 36.5$ ms | $\pm 3.4$ ms | $\pm 5.2$ ms |
| **Mean Files Damaged (All)** | **3.05** | 5.05 | 5.05 |
| Damage in S5 (Canary Hit) | 1.10 files | **0.10 files** | **0.10 files** |
| Damage in S6 (Canary Evaded)| **5.00 files** | 10.00 files | 10.00 files |
| **Mean Ops Prevented (All)** | **65.33%** | 45.42% | 45.42% |
| Ops Prevented in S5 | 75.42% | **90.83%** | **90.83%** |
| Ops Prevented in S6 | **55.24%** | 0.00% | 0.00% |
| Mean CPU Overhead | 25.93% | 26.56% | **25.40%** |
| Mean Memory Footprint | **37.18 MB** | 37.35 MB | 37.70 MB |

---

## 14. Statistical Analysis

### 14.1 Latency Confidence Intervals
Detection latency for positive alerts was evaluated using Student's $t$-distribution. For Hybrid ($k = 10$, $\bar{x} = 26.1$, $s = 8.4$, $\nu = 9$):

$$\text{CI}_{95} = 26.1 \pm 2.262 \times \frac{8.4}{\sqrt{10}} = 26.1 \pm 6.0 \text{ ms}$$

For Baseline ($k = 30$, $\bar{x} = 147.1$, $s = 102.1$, $\nu = 29$):

$$\text{CI}_{95} = 147.1 \pm 2.045 \times \frac{102.1}{\sqrt{30}} = 147.1 \pm 38.1 \text{ ms}$$

The latency difference between Hybrid (26.1 ms) and Baseline (147.1 ms) is statistically significant ($p < 0.001$), demonstrating that decoy interaction provides a vastly faster trigger than waiting for statistical volume accumulation.

### 14.2 Mathematical Resolution of the Operations Prevented Discrepancy
In Scenario S5, Hybrid halted the attack in 26.1 ms, preventing **90.83%** of planned file operations. In Scenario S6, Hybrid missed the attack entirely (0% prevented). The aggregate reported value of **45.42%** reflects the exact arithmetic mean across all 20 suspicious trials:

$$\frac{(90.83\% \times 10) + (0.00\% \times 10)}{20} = \frac{908.3\%}{20} = \mathbf{45.42\%}$$

---

## 15. Discussion

### 15.1 The Elimination of False Positives ($H_1$ Supported)
Hypothesis $H_1$ is strongly supported. By requiring contextual velocity within a sliding window, Hybrid suppressed all 10 false alarms in Scenario B3 (accidental canary read), achieving **0.0% FPR** and **100% Precision**. In production environments, this enables automated, aggressive containment without risk of business disruption.

### 15.2 Early Containment and Damage Reduction ($H_2$ Supported)
Hypothesis $H_2$ is confirmed for all attacks that interact with canaries. In Scenario S5, Hybrid limited data damage to **0.10 files**, compared to **1.10 files** under Baseline, representing an order-of-magnitude reduction in initial file destruction.

### 15.3 Rejection of Universal Superiority ($H_3$ Rejected)
Hypothesis $H_3$ must be rejected. Baseline achieved higher Recall (**100% vs. 50%**) and a higher overall $F_1$-score (**0.80 vs. 0.67**) because it detected Scenario S6, which completely bypassed the canary-reliant Hybrid engine. This highlights the inherent danger of relying exclusively on deception technology.

---

## 16. Defense-in-Depth Architectural Implications

The empirical findings dictate a two-tier hybrid architecture:
- **Tier 1 (Hybrid Fast Path)**: Immediate process termination (`SIGKILL`) triggered by correlated canary interactions (Latency: 26 ms, Precision: 100%, Damage: $<1$ file).
- **Tier 2 (Baseline Safety Net)**: Process suspension (`SIGSTOP`) and administrative confirmation triggered by rapid volume anomalies when no canaries are touched (Latency: 147 ms, Recall: 100%).

---

## 17. Threats to Validity

1. **Construct Validity**: Attack workloads were simulated using synthetic random byte generation rather than weaponized malware samples. While file I/O operations accurately mirror encryption patterns, evasive malware may employ kernel hooks or direct block device writes.
2. **Internal Validity**: The 100 ms debouncing window introduces minor artificial latency into the event stream, though this reflects necessary deduplication on macOS FSEvents.
3. **External Validity**: Experiments were performed on a single macOS Apple Silicon hardware platform. Workloads on Windows (NTFS) or Linux (ext4) may exhibit different OS queue buffering characteristics.

---

## 18. Limitations

1. **User-Space Latency**: Because `watchdog` operates asynchronously in user space, write operations are committed to storage before event notifications arrive.
2. **Decoy Discovery**: Sophisticated malware inspecting NTFS alternate data streams, hidden flags, or file entropy baselines could identify and avoid canary files.
3. **Absence of Synchronous Blocking**: User-space containment cannot block the initial write syscall synchronously without kernel extension (`EndpointSecurity.framework`) support.

---

## 19. Ethical and Safety Considerations

CanarySentinel was designed under strict safety constraints:
- All operations are confined to an isolated sandbox (`sandbox/`).
- The simulator utilizes safe POSIX file writes without malicious payloads or privilege escalation.
- The automated response manager only signals verified PIDs of the internal simulator process, ensuring zero risk to host operating system stability.

---

## 20. Conclusion

This research demonstrated that combining canary-file interactions with contextual filesystem behavior solves the long-standing false-positive problem of deception technology, achieving **100% precision** and reducing detection latency to **26.1 ms**. However, because deception tripwires remain vulnerable to evasion, hybrid detection cannot stand alone. An integrated defense-in-depth model combining hybrid fast-path triggers with behavioral safety nets provides the optimal trade-off between false-alarm suppression and complete threat coverage.

---

## 21. Future Work

1. Implement an Apple `EndpointSecurity.framework` (`es_client`) system extension for synchronous pre-write interception.
2. Develop dynamic, adaptive canary placement using reinforcement learning to predict adversary traversal paths.
3. Benchmark against live, sandbox-contained real-world ransomware families (e.g., LockBit 3.0).

---

## 22. Acknowledgements

The authors acknowledge the guidance of the project supervisor and the institutional faculty for providing laboratory resources and computational infrastructure.

---

## 23. References

1. **[REF-01]** Scaife, N., Carter, H., Traynor, P., & Butler, K. R. (2016). CryptoDrop: Early detection for ransomware. In *2016 IEEE 36th International Conference on Distributed Computing Systems (ICDCS)* (pp. 454–463). IEEE. DOI: 10.1109/ICDCS.2016.70
2. **[REF-02]** Continella, A., Guagnelli, A., Zingaro, F., De Pasquale, G., Barenghi, A., Zanero, S., & Maggi, F. (2016). ShieldFS: a self-healing, ransomware-aware filesystem. In *Proceedings of the 32nd Annual Conference on Computer Security Applications (ACSAC '16)* (pp. 336–347). ACM. DOI: 10.1145/2991079.2991110
3. **[REF-03]** Kharraz, A., Robertson, W., Balzarotti, D., Bilge, L., & Kirda, E. (2015). Cutting the Gordian Knot: A Look Under the Hood of Ransomware Analysis. In *DIMVA 2015*, LNCS 9148 (pp. 3–24). Springer. DOI: 10.1007/978-3-319-20550-2_1
4. **[REF-04]** Al-rimy, B. A. S., Maarof, M. A., & Shaid, S. Z. M. (2019). A pseudo feedback-based early detection method for crypto-ransomware using process cognitive trajectory and file access patterns. *Computers & Security*, 82, 187–205. DOI: 10.1016/j.cose.2018.12.013
5. **[REF-05]** Park, J., Lee, C., & Kim, H. (2021). GuardFS: A File System for Integrated Detection and Mitigation of Linux-Based Ransomware. *IEEE Transactions on Information Forensics and Security*, 16, 4210–4223. DOI: 10.1109/TIFS.2021.3101569
6. **[REF-06]** Ku, S., Jeong, S., & Han, K. (2021). RansomFisher: A Behavior-Based Detection and Mitigation Framework for Ransomware Without Relying on Decoy Files. *IEEE Access*, 9, 137890–137902. DOI: 10.1109/ACCESS.2021.3117420
7. **[REF-07]** Moore, C. (2017). Detecting Ransomware with Honeypot Techniques. In *2017 International Conference on Cybersecurity and Cyberforensics (ICCC)* (pp. 77–81). IEEE. DOI: 10.1109/ICCC.2017.17
8. **[REF-08]** Mehnaz, S., Mudgerikar, A., & Bertino, E. (2018). RWGuard: A Real-Time Detection and Resilient Recovery System Against Ransomware. In *2018 IEEE 38th ICDCS* (pp. 892–903). DOI: 10.1109/ICDCS.2018.00092
9. **[REF-09]** Shannon, C. E. (1948). A Mathematical Theory of Communication. *Bell System Technical Journal*, 27(3), 379–423. DOI: 10.1002/j.1538-7305.1948.tb01338.x
10. **[REF-10]** Kolodenker, E., Kochberger, W., Gianvecchio, S., & Kirda, E. (2017). PayBreak: Defense Against Cryptanalytic Ransomware. In *ACM CCS '17* (pp. 599–611). DOI: 10.1145/3133956.3134091
11. **[REF-11]** Al-rimy, B. A. S., Maarof, M. A., & Shaid, S. Z. M. (2018). Ransomware threat success factors, taxonomy, and defense approaches: A survey. *Computers & Security*, 74, 144–166. DOI: 10.1016/j.cose.2018.01.001
12. **[REF-14]** Arp, D., Quiring, E., Wressnegger, C., & Rieck, K. (2022). Dos and Don'ts of Machine Learning in Computer Security. *Communications of the ACM*, 65(8), 78–87. DOI: 10.1145/3543846

