# CanarySentinel — Actual Implementation Architecture Overview

**Auditor**: Independent Technical Audit Team  
**Project**: CanarySentinel: Deception-Based Ransomware Detection, Behavioral Analysis and Risk-Aware Response System  
**Document**: `research_dossier/01_PROJECT_INVENTORY/PROJECT_ARCHITECTURE_OVERVIEW.md`  
**Execution Context**: Local Python 3.12 / Darwin macOS on Apple Silicon M1 (arm64)  

---

## 1. End-to-End System Lifecycle

The actual CanarySentinel codebase implements a clean, modular, user-space pipeline. The system lifecycle proceeds through ten discrete stages:

```
[1. Filesystem Sandbox]
         │ (Configured root directory: ./sandbox)
         ▼
[2. Canary Manager Deployment]
         │ (Writes 8 decoy files: !00_*, aaa_*, 0_*, .env, etc. & SHA-256 baseline)
         ▼
[3. Filesystem Monitor (Watchdog)]
         │ (Asynchronous OS callbacks via macOS FSEvents)
         ▼
[4. Event Normalizer & Debouncer]
         │ (50ms debounce window, path canonicalization, entropy calculation)
         ▼
[5. Parallel Detection Engines]
    ├── Configuration A: Baseline Detector (Velocity & mass rename heuristics)
    ├── Configuration B: Canary-Only Detector (Immediate decoy breach tripwire)
    └── Configuration C: Hybrid Detector (Temporal sliding-window correlation)
         │
         ▼
[6. Risk & Severity Engine]
         │ (Weighted additive scoring: 0 - 100, maps to Low/Med/High/Critical)
         ▼
[7. Simulated Response Manager]
         │ (Internal simulator block flag: self._blocked = True)
         ▼
[8. SQLite Persistence Layer]
         │ (canary_sentinel.db: WAL mode, ACID transactions)
         ▼
[9. Interactive Streamlit Dashboard]
         │ (Port 8501: 6 multi-page views, live charts, CSV/ZIP export)
         ▼
[10. Experiment Evaluation & Metrics Engine]
           (180 batch trials, precision/recall/F1/FPR calculation, latency CIs)
```

---

## 2. Granular Stage-by-Stage Implementation Trace

### Stage 1: Filesystem Sandbox Isolation (`canary_sentinel/core/sandbox.py`)
- **Implemented Class**: `SandboxManager`
- **Core Functionality**:
  - Enforces boundary restrictions around `./sandbox` using `Path.resolve()` and `is_relative_to()`.
  - Forbids execution if the sandbox root points to sensitive OS directories (`/`, `/bin`, `/System`, `/Library`, `/Users`, `Path.home()`).
  - Verifies targets against directory traversal (`../`) and null-byte injection (`\0`).
  - Validates symlink resolution to prevent symlink traversal escapes.
  - Provides `safe_reset()` to purge ephemeral test artifacts while maintaining sandbox directory structure.

### Stage 2: Canary Decoy Deployment (`canary_sentinel/canary/manager.py`)
- **Implemented Class**: `CanaryManager`
- **Core Functionality**:
  - Provisions 8 strategic decoy files across configured subdirectories (`documents/`, `backup/`, `projects/`).
  - Uses lexicographically prioritized templates (`!00_corporate_passwords.xlsx`, `aaa_employee_salaries.csv`, `0_database_backup_production.sql`, `aaa_api_secret_keys.env`) to intercept alphabetical directory traversal.
  - Computes initial SHA-256 hashes and persists metadata to SQLite table `canaries`.
  - Maintains in-memory lookup sets (`self._canary_paths`) for $O(1)$ fast lookup during high-throughput event processing.
  - Provides `verify_integrity()` to detect modified, deleted, or missing canaries.

### Stage 3: Filesystem Monitoring (`canary_sentinel/monitoring/monitor.py`)
- **Implemented Class**: `FilesystemMonitor`
- **Core Functionality**:
  - Encapsulates Python `watchdog.observers.Observer` running a background daemon thread.
  - Registers `_WatchdogHandler` extending `FileSystemEventHandler`.
  - Captures raw OS events (`FileCreatedEvent`, `FileModifiedEvent`, `FileDeletedEvent`, `FileMovedEvent`).
  - Dispatches raw events to the normalizer callback queue asynchronously.

### Stage 4: Event Normalization & Debouncing (`canary_sentinel/monitoring/normalizer.py`)
- **Implemented Class**: `EventNormalizer`
- **Core Functionality**:
  - Resolves OS-specific paths to canonical sandbox-relative POSIX paths.
  - Implements a configurable debouncing window (`debounce_ms = 50`) using a `(path, event_type) -> timestamp` hash map to suppress redundant macOS buffer-flush modify events.
  - Computes Shannon entropy on files up to 10 MB in real time using byte histogram frequency analysis.
  - Flags `is_canary = True` if path matches `CanaryManager._canary_paths`.
  - Emits clean `NormalizedEvent` dataclass instances.

### Stage 5: Parallel Detection Engines (`canary_sentinel/detection/`)
- **Configuration A: Baseline Detector (`baseline_detector.py`)**:
  - Operates on operation velocity and burst volume over a sliding window (default 2.0s).
  - Triggers if `total_ops >= burst_threshold` (8 ops) across $\ge 3$ files, or if mass rename operations $\ge 4$, or if suspicious extensions (`.locked`, `.crypto`) are encountered.
  - Strictly ignores canary flags (`event.is_canary` is never inspected).
- **Configuration B: Canary-Only Detector (`canary_detector.py`)**:
  - Evaluates only `event.is_canary == True`.
  - Triggers immediately upon `MODIFY`, `DELETE`, or `MOVE` on any registered decoy path.
  - Ignores surrounding velocity and contextual file operations.
- **Configuration C: Hybrid Detector (`hybrid_detector.py`)**:
  - Maintains an observation window (default 3.0s or 5.0s).
  - When a canary decoy is touched, buffers candidate event (`self._pending_canary_event`).
  - Evaluates contextual filesystem activity surrounding the canary breach. Requires at least one confirmation criterion:
    1. High-entropy modification on $\ge 2$ companion user files.
    2. High operation velocity across $\ge 4$ operations and $\ge 3$ companion files.
    3. Mass file churn sequence ($\ge 6$ operations across $\ge 4$ files).
  - Suppresses isolated canary reads (Scenario B3) when no companion file damage occurs.

### Stage 6: Risk & Severity Engine (`canary_sentinel/detection/risk_engine.py`)
- **Implemented Class**: `RiskEngine`
- **Core Functionality**:
  - Normalizes multi-detector evidence into a standardized risk score ($0 - 100$).
  - Maps scores to categorical severities: `LOW` (0–29), `MEDIUM` (30–59), `HIGH` (60–84), `CRITICAL` (85–100).
  - Generates comprehensive human-readable explanation strings with triggering and supporting event IDs.

### Stage 7: Simulated Response Manager (`canary_sentinel/simulation/response_manager.py`)
- **Implemented Class**: `SimulatedResponseManager`
- **Core Functionality**:
  - Thread-safe containment controller (`threading.Lock`).
  - Evaluates alert severity against `ResponseConfig.minimum_severity` (default `HIGH`) or risk score ($\ge 70$).
  - **Actual Mechanism**: Sets an **internal simulator block flag** (`self._blocked = True`, `self._block_time = time.time()`).
  - **Audited Safety Guarantee**: It does **not** dispatch POSIX signals (`SIGTERM`, `SIGKILL`, `SIGSTOP`) to host OS processes. The harmless activity simulator inspects `self.response_manager.is_blocked()` before each operation and breaks early if blocked.

### Stage 8: Storage & Database Layer (`canary_sentinel/storage/db.py`)
- **Implemented Class**: `Database`
- **Core Functionality**:
  - SQLite 3 database (`canary_sentinel.db`) with Write-Ahead Logging (`PRAGMA journal_mode=WAL;`) and 5,000 ms busy timeout.
  - Implements 5 structured tables: `canaries`, `events`, `alerts`, `scenarios`, `system_metrics`.
  - Thread-safe connection context managers with automatic commit/rollback.

### Stage 9: Dashboard Presentation Tier (`canary_sentinel/dashboard/app.py`)
- **Streamlit Web Dashboard**: Running on port 8501.
- Features 6 functional views: Overview & Telemetry, Decoy & Sandbox Controls, Live Event Stream, Incidents & Evidence Alerts, Simulation & Experiments, Comparative Research Analysis.
- Features direct CSV and ZIP export controls for empirical research dissemination.

### Stage 10: Experiment Evaluation & Metrics (`canary_sentinel/experiments/`)
- **`ExperimentRunner` (`runner.py`)**: Executes 180 controlled benchmark trials (10 repetitions $\times$ 6 scenarios $\times$ 3 configurations), recording start/end timestamps, executed operations, prevented operations, files damaged, and detection latency.
- **`MetricsCalculator` (`metrics.py`)**: Computes precision, recall, F1-score, false positive rate, detection latency distributions, standard deviations, and 95% confidence intervals directly from database records.

---

## 3. Discrepancies Between Documentation and Actual Implementation

The technical audit revealed four significant discrepancies between previously generated reports and the real codebase:

| Discrepancy ID | Architectural Area | Previously Reported / Claimed | Actual Implementation Finding | Audit Impact |
|:---|:---|:---|:---|:---:|
| **DISC-01** | Response Mechanism | "Dispatches POSIX `SIGTERM`/`SIGKILL` to simulator PID." | Uses an internal Python boolean flag (`self._blocked = True`, checked via `is_blocked()`). Never calls `os.kill()`. | **High**: Eliminates OS process risk, but prior claims of POSIX signaling were inaccurate. |
| **DISC-02** | Baseline False Alarm Scenario | "Scenario B2 (`benign_bulk_docs`) triggered Baseline false alarms." | In the SQLite database, Scenario B2 (`Bulk Copying`) had 0 false alarms. The actual scenario that triggered 10 Baseline false alarms was Scenario B4 (`Bulk Renaming`) due to mass rename thresholds. | **High**: Must be corrected in all scenario attribution tables. |
| **DISC-03** | System Metrics Attribution | "Detector-specific CPU and RAM measurements." | Samples host Python process (`psutil.Process(os.getpid())`) at trial completion. Reflects total runtime overhead (Python + Watchdog + SQLite), not isolated detector threads. | **Medium**: Clarifies why CPU (25.4–26.6%) and RAM (37.2–37.7 MB) are very close across configurations. |
| **DISC-04** | Operations Prevented Math | "Hybrid prevented 45.4% overall vs 90.8% in S5." | 45.42% is the unweighted arithmetic mean of per-trial ratios: $(90.83\% \times 10 + 0.0\% \times 10) / 20$. Ratio of total prevented sums yields 49.55%. | **Medium**: Both formulas are mathematically documented and reconciled. |

---

## 4. Code Redundancies and Unused Code Analysis

1. **Unused Code**:
   - `canary_sentinel/core/utils.py:calculate_entropy()`: A standalone string/byte entropy function exists in `utils.py`, while `calculate_file_entropy()` is used by the event normalizer. Both implementations are mathematically identical Shannon formulations.
   - `canary_sentinel/simulation/scenarios.py:ScenarioHelper.generate_low_entropy_text()`: Defined as a utility helper but the simulator scenarios directly format structured document strings.
2. **Missing Components**:
   - No native kernel-space authorization client (e.g., Apple `EndpointSecurity.framework`). The system relies entirely on user-space `watchdog` and `FSEvents`, which is consistent with its lightweight, non-root design specification.

