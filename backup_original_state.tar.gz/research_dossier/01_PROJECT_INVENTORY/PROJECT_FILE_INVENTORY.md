# CanarySentinel — Complete Project File Inventory

**Auditor**: Independent Technical Audit Team  
**Project**: CanarySentinel — Endpoint Ransomware Behavioral Detection & Decoy System  
**Scope**: Comprehensive inventory of all source, test, configuration, database, and documentation files.  

| File Path | Size (Bytes) | Lines | Relevant Module / Layer | Primary Purpose | Audit Status |
|:---|---:|---:|:---|:---|:---:|
| `.gitignore` | 336 | 34 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `ACADEMIC_REPORT.md` | 17,627 | 271 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `ARCHITECTURE.md` | 10,706 | 182 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `CONTRIBUTIONS.md` | 5,136 | 53 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `CanarySentinel.zip` | 124,048 | 900 | Release Archive | Packaged distributable research dossier ZIP. | **VERIFIED** |
| `CanarySentinel_Research_Dossier.zip` | 124,048 | 900 | Release Archive | Packaged distributable research dossier ZIP. | **VERIFIED** |
| `EXPERIMENT_METHODOLOGY.md` | 7,584 | 133 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `FINAL_AUDIT_REPORT.md` | 14,844 | 209 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `LITERATURE_REVIEW.md` | 6,042 | 64 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `PRESENTATION_OUTLINE.md` | 13,497 | 169 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `PROJECT_SCOPE.md` | 6,179 | 77 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `README.md` | 15,365 | 234 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `RESEARCH_GAP_AND_NOVELTY.md` | 5,033 | 45 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `RESEARCH_LIMITATIONS.md` | 5,689 | 59 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `RESEARCH_RESULTS.md` | 10,224 | 126 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `RESEARCH_SUMMARY.md` | 5,442 | 63 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `TESTING_REPORT.md` | 6,500 | 74 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `USER_GUIDE.md` | 8,365 | 181 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `canary_sentinel.db` | 782,336 | 5704 | Storage / SQLite | Authoritative experimental database storing 180 trials, 1,691 events, 60 alerts, and 8 canaries. | **VERIFIED** |
| `config.json` | 1,324 | 69 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `requirements.txt` | 77 | 6 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `run_sentinel.py` | 10,958 | 274 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `tests/__init__.py` | 41 | 2 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_canary_manager.py` | 2,212 | 80 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_cli_and_exports.py` | 4,299 | 128 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_database.py` | 2,801 | 106 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_detectors.py` | 4,251 | 127 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_integration_flow.py` | 3,444 | 85 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_metrics.py` | 4,589 | 134 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_monitor_normalizer.py` | 2,517 | 78 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_performance.py` | 3,058 | 84 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_risk_engine.py` | 4,154 | 134 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_sandbox_safety.py` | 4,596 | 136 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `tests/test_scenarios.py` | 2,865 | 78 | Automated Verification | Pytest suite covering all subsystems (45 unit and integration tests). | **VERIFIED** |
| `docs/diagrams/data_flow.mmd` | 887 | 18 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/database_er.mmd` | 1,472 | 69 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/deployment.mmd` | 1,541 | 41 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/detection_workflow.mmd` | 1,006 | 20 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/experiment_workflow.mmd` | 1,095 | 22 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/hybrid_correlation.mmd` | 1,210 | 26 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/response_workflow.mmd` | 1,288 | 28 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/sequence.mmd` | 1,604 | 40 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/system_architecture.mmd` | 1,883 | 52 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `docs/diagrams/use_case.mmd` | 1,071 | 31 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `exports/alerts.csv` | 88,709 | 941 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `exports/events.csv` | 330,610 | 1692 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `exports/metrics_summary.csv` | 788 | 4 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `exports/scenario_breakdown.csv` | 2,543 | 19 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `exports/trials.csv` | 31,887 | 181 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/!00_corporate_passwords.xlsx` | 537 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/_urgent_merger_acquisition_terms.docx` | 517 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/0_database_backup_production.sql` | 557 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_01.txt` | 2,048 | 18 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_02.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_03.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_04.txt` | 2,048 | 28 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_05.txt` | 2,048 | 21 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/projects/user_doc_06.txt` | 2,048 | 18 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/aaa_api_secret_keys.env` | 542 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/aaa_employee_salaries.csv` | 497 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_01.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_02.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_03.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_04.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_05.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/finance/user_doc_06.txt` | 440 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/!00_master_financials_2026.pdf` | 562 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/00_client_contracts_signed.pdf` | 547 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_01.txt` | 2,048 | 10 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_02.txt` | 2,048 | 19 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_03.txt` | 2,048 | 17 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_04.txt` | 2,048 | 18 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_05.txt` | 2,048 | 16 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/documents/user_doc_06.txt` | 2,048 | 15 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `sandbox/backups/!aa_cryptocurrency_cold_wallet.txt` | 542 | 7 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `canary_sentinel/__init__.py` | 121 | 4 | Root / Configuration | Top-level orchestration, environment configuration, or documentation. | **VERIFIED** |
| `canary_sentinel/core/__init__.py` | 492 | 16 | Core Architecture & Sandbox | Enforces sandbox filesystem isolation, configuration models, and path validation. | **VERIFIED** |
| `canary_sentinel/core/config.py` | 3,793 | 122 | Core Architecture & Sandbox | Enforces sandbox filesystem isolation, configuration models, and path validation. | **VERIFIED** |
| `canary_sentinel/core/sandbox.py` | 6,166 | 164 | Core Architecture & Sandbox | Enforces sandbox filesystem isolation, configuration models, and path validation. | **VERIFIED** |
| `canary_sentinel/core/utils.py` | 2,323 | 80 | Core Architecture & Sandbox | Enforces sandbox filesystem isolation, configuration models, and path validation. | **VERIFIED** |
| `canary_sentinel/canary/__init__.py` | 127 | 6 | Deception & Honeyfiles | Deploys, monitors, registers, and validates SHA-256 integrity of canary decoys. | **VERIFIED** |
| `canary_sentinel/canary/manager.py` | 6,291 | 163 | Deception & Honeyfiles | Deploys, monitors, registers, and validates SHA-256 integrity of canary decoys. | **VERIFIED** |
| `canary_sentinel/experiments/__init__.py` | 336 | 12 | Experiments & Metrics | Automated 180-trial runner, metrics calculator, and statistical confidence intervals. | **VERIFIED** |
| `canary_sentinel/experiments/metrics.py` | 19,087 | 402 | Experiments & Metrics | Automated 180-trial runner, metrics calculator, and statistical confidence intervals. | **VERIFIED** |
| `canary_sentinel/experiments/runner.py` | 8,160 | 221 | Experiments & Metrics | Automated 180-trial runner, metrics calculator, and statistical confidence intervals. | **VERIFIED** |
| `canary_sentinel/simulation/__init__.py` | 441 | 14 | Simulation & Containment | Executes 6 harmless filesystem scenarios and manages simulated containment via internal block flag. | **VERIFIED** |
| `canary_sentinel/simulation/response_manager.py` | 2,728 | 79 | Simulation & Containment | Executes 6 harmless filesystem scenarios and manages simulated containment via internal block flag. | **VERIFIED** |
| `canary_sentinel/simulation/scenarios.py` | 2,288 | 67 | Simulation & Containment | Executes 6 harmless filesystem scenarios and manages simulated containment via internal block flag. | **VERIFIED** |
| `canary_sentinel/simulation/simulator.py` | 16,387 | 429 | Simulation & Containment | Executes 6 harmless filesystem scenarios and manages simulated containment via internal block flag. | **VERIFIED** |
| `canary_sentinel/storage/__init__.py` | 382 | 20 | Persistence & Database | SQLite thread-safe database storage, models, and migrations. | **VERIFIED** |
| `canary_sentinel/storage/db.py` | 18,231 | 469 | Persistence & Database | SQLite thread-safe database storage, models, and migrations. | **VERIFIED** |
| `canary_sentinel/storage/models.py` | 2,502 | 96 | Persistence & Database | SQLite thread-safe database storage, models, and migrations. | **VERIFIED** |
| `canary_sentinel/dashboard/__init__.py` | 45 | 2 | Presentation Layer | Multi-view interactive Streamlit web dashboard for telemetry, controls, and research analysis. | **VERIFIED** |
| `canary_sentinel/dashboard/app.py` | 40,400 | 889 | Presentation Layer | Multi-view interactive Streamlit web dashboard for telemetry, controls, and research analysis. | **VERIFIED** |
| `canary_sentinel/monitoring/__init__.py` | 230 | 7 | Filesystem Telemetry | Monitors OS filesystem via Watchdog/FSEvents and debounces events into NormalizedEvent schema. | **VERIFIED** |
| `canary_sentinel/monitoring/monitor.py` | 5,517 | 170 | Filesystem Telemetry | Monitors OS filesystem via Watchdog/FSEvents and debounces events into NormalizedEvent schema. | **VERIFIED** |
| `canary_sentinel/monitoring/normalizer.py` | 4,292 | 123 | Filesystem Telemetry | Monitors OS filesystem via Watchdog/FSEvents and debounces events into NormalizedEvent schema. | **VERIFIED** |
| `canary_sentinel/detection/__init__.py` | 539 | 17 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
| `canary_sentinel/detection/base.py` | 1,871 | 55 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
| `canary_sentinel/detection/baseline_detector.py` | 4,253 | 101 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
| `canary_sentinel/detection/canary_detector.py` | 2,232 | 63 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
| `canary_sentinel/detection/hybrid_detector.py` | 6,087 | 139 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
| `canary_sentinel/detection/risk_engine.py` | 4,132 | 109 | Detection Engines & Risk | Implements Baseline, Canary-Only, and Hybrid sliding-window detectors and risk scoring. | **VERIFIED** |
