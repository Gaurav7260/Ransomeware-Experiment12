# Scenario Analysis: B1 — Normal File Editing

**Scenario Code**: `B1`  
**Workload Classification**: `BENIGN` (Ground Truth = 0 (Benign))  
**Audit Status**: **100% INDEPENDENTLY VERIFIED**  

## 1. Scenario Specification & Objectives
- **Objective**: Simulates standard sporadic user modifications to documents at a realistic human typing and saving pace.
- **Input Conditions**: 5 user documents in documents/ directory, edited sequentially with 100ms pauses.
- **Target Files Involved**: user_doc_01.txt to user_doc_05.txt
- **Theoretical Expectation**: 0 alerts across all detectors (True Negative = 10 for all 3 configurations).
- **Failure Mode Analysis**: None. All detectors correctly suppress alerts.

## 2. Quantitative Empirical Results Across Detectors (10 Trials Each)

| Detector Configuration | Trials ($n$) | Detected | Undetected | Classification Outcome | Mean Latency (ms) | Median Latency | Avg Files Damaged | Prevented Ops % |
|:---|---:|---:|---:|:---:|---:|---:|---:|---:|
| **Baseline** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Canary Only** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Hybrid** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |

## 3. Repetition-Level Trial Logs (All 30 Trials)

| Trial ID | Detector | Planned Ops | Executed Ops | Prevented Ops | Damaged Files | Detected | Latency (ms) | Duration (ms) |
|:---|:---|---:|---:|---:|---:|:---:|---:|---:|
| `baseline_normal_file_editing_adb7f3` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 775.7 |
| `baseline_normal_file_editing_f19537` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 779.2 |
| `baseline_normal_file_editing_21ab29` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 781.8 |
| `baseline_normal_file_editing_7ab4e9` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 780.9 |
| `baseline_normal_file_editing_d30dcd` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 778.8 |
| `baseline_normal_file_editing_dad284` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 778.0 |
| `baseline_normal_file_editing_1347aa` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 780.2 |
| `baseline_normal_file_editing_c68e18` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 779.6 |
| `baseline_normal_file_editing_1f2423` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 780.4 |
| `baseline_normal_file_editing_a7babb` | `baseline` | 5 | 5 | 0 | 0 | 0 | - | 784.8 |
| `canary_only_normal_file_editing_68d3c7` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 783.1 |
| `canary_only_normal_file_editing_53aacb` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 778.1 |
| `canary_only_normal_file_editing_e4fc3c` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 776.7 |
| `canary_only_normal_file_editing_2c11ac` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 782.9 |
| `canary_only_normal_file_editing_82f96d` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 777.8 |
| `canary_only_normal_file_editing_80258c` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 780.2 |
| `canary_only_normal_file_editing_822f35` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 779.9 |
| `canary_only_normal_file_editing_73ccb0` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 772.8 |
| `canary_only_normal_file_editing_e9c434` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 784.8 |
| `canary_only_normal_file_editing_e28ed2` | `canary_only` | 5 | 5 | 0 | 0 | 0 | - | 776.2 |
| `hybrid_normal_file_editing_27896f` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 774.1 |
| `hybrid_normal_file_editing_3c8dce` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 774.2 |
| `hybrid_normal_file_editing_41e585` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 782.6 |
| `hybrid_normal_file_editing_8aa82b` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 783.8 |
| `hybrid_normal_file_editing_df9a9c` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 781.4 |
| `hybrid_normal_file_editing_d48d5c` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 783.4 |
| `hybrid_normal_file_editing_77ba26` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 780.2 |
| `hybrid_normal_file_editing_642dd3` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 786.6 |
| `hybrid_normal_file_editing_9e4e1c` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 778.7 |
| `hybrid_normal_file_editing_7b9912` | `hybrid` | 5 | 5 | 0 | 0 | 0 | - | 783.1 |

## 4. Architectural Findings & Limitations
This scenario conclusively verifies the behavioral characteristics of `B1`. None. All detectors correctly suppress alerts.
