# Scenario Analysis: S6 — Rapid Bulk Modifications Without Canary

**Scenario Code**: `S6`  
**Workload Classification**: `SUSPICIOUS` (Ground Truth = 1 (Attack))  
**Audit Status**: **100% INDEPENDENTLY VERIFIED**  

## 1. Scenario Specification & Objectives
- **Objective**: Simulates an evasive ransomware attack: rapidly encrypts 10 user documents with high-entropy bytes while deliberately avoiding all canary decoys.
- **Input Conditions**: 10 planned operations: overwrites 10 user documents with high-entropy random bytes; zero canary interactions.
- **Target Files Involved**: 10 user_doc_*.txt files strictly outside canary decoy paths
- **Theoretical Expectation**: Baseline: 10 alerts (TP). Canary-Only: 0 alerts (FN). Hybrid: 0 alerts (FN).
- **Failure Mode Analysis**: Canary-Only and Hybrid suffer 100% false negatives (FN=10) due to decoy evasion. Baseline successfully detects burst via volume heuristics.

## 2. Quantitative Empirical Results Across Detectors (10 Trials Each)

| Detector Configuration | Trials ($n$) | Detected | Undetected | Classification Outcome | Mean Latency (ms) | Median Latency | Avg Files Damaged | Prevented Ops % |
|:---|---:|---:|---:|:---:|---:|---:|---:|---:|
| **Baseline** | 10 | 10 | 0 | **10 TP** (Detected) | 144.0 ms | 142.0 ms | 6.10 | 39.0% |
| **Canary Only** | 10 | 0 | 10 | **10 FN** (Missed) | N/A | N/A | 10.00 | 0.0% |
| **Hybrid** | 10 | 0 | 10 | **10 FN** (Missed) | N/A | N/A | 10.00 | 0.0% |

## 3. Repetition-Level Trial Logs (All 30 Trials)

| Trial ID | Detector | Planned Ops | Executed Ops | Prevented Ops | Damaged Files | Detected | Latency (ms) | Duration (ms) |
|:---|:---|---:|---:|---:|---:|:---:|---:|---:|
| `baseline_rapid_bulk_without_canary_0f23c0` | `baseline` | 10 | 6 | 4 | 6 | 1 | 140.0 | 306.9 |
| `baseline_rapid_bulk_without_canary_56bea7` | `baseline` | 10 | 6 | 4 | 6 | 1 | 141.6 | 310.8 |
| `baseline_rapid_bulk_without_canary_bc08b1` | `baseline` | 10 | 6 | 4 | 6 | 1 | 141.6 | 306.2 |
| `baseline_rapid_bulk_without_canary_7b884d` | `baseline` | 10 | 6 | 4 | 6 | 1 | 140.2 | 308.9 |
| `baseline_rapid_bulk_without_canary_e2745f` | `baseline` | 10 | 6 | 4 | 6 | 1 | 144.0 | 312.6 |
| `baseline_rapid_bulk_without_canary_09856d` | `baseline` | 10 | 6 | 4 | 6 | 1 | 138.7 | 304.4 |
| `baseline_rapid_bulk_without_canary_215ea2` | `baseline` | 10 | 7 | 3 | 7 | 1 | 148.3 | 344.6 |
| `baseline_rapid_bulk_without_canary_dc42bb` | `baseline` | 10 | 6 | 4 | 6 | 1 | 159.9 | 326.9 |
| `baseline_rapid_bulk_without_canary_3716b8` | `baseline` | 10 | 6 | 4 | 6 | 1 | 142.3 | 311.0 |
| `baseline_rapid_bulk_without_canary_7d9bb6` | `baseline` | 10 | 6 | 4 | 6 | 1 | 144.0 | 312.7 |
| `canary_only_rapid_bulk_without_canary_0faffa` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 427.3 |
| `canary_only_rapid_bulk_without_canary_0e8cd4` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 407.9 |
| `canary_only_rapid_bulk_without_canary_933230` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 403.8 |
| `canary_only_rapid_bulk_without_canary_f159a2` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 400.4 |
| `canary_only_rapid_bulk_without_canary_c218ea` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 407.2 |
| `canary_only_rapid_bulk_without_canary_32b5ff` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 405.4 |
| `canary_only_rapid_bulk_without_canary_613478` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 407.4 |
| `canary_only_rapid_bulk_without_canary_25c4f1` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 410.6 |
| `canary_only_rapid_bulk_without_canary_96ab8e` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 403.3 |
| `canary_only_rapid_bulk_without_canary_d00400` | `canary_only` | 10 | 10 | 0 | 10 | 0 | - | 395.1 |
| `hybrid_rapid_bulk_without_canary_57954a` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 409.4 |
| `hybrid_rapid_bulk_without_canary_4727db` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 391.4 |
| `hybrid_rapid_bulk_without_canary_e2c113` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 404.6 |
| `hybrid_rapid_bulk_without_canary_2f94d3` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 411.7 |
| `hybrid_rapid_bulk_without_canary_12188d` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 403.2 |
| `hybrid_rapid_bulk_without_canary_e68038` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 399.1 |
| `hybrid_rapid_bulk_without_canary_e50ec4` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 405.8 |
| `hybrid_rapid_bulk_without_canary_3a5e79` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 409.7 |
| `hybrid_rapid_bulk_without_canary_f47164` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 409.8 |
| `hybrid_rapid_bulk_without_canary_eefa16` | `hybrid` | 10 | 10 | 0 | 10 | 0 | - | 407.4 |

## 4. Architectural Findings & Limitations
This scenario conclusively verifies the behavioral characteristics of `S6`. Canary-Only and Hybrid suffer 100% false negatives (FN=10) due to decoy evasion. Baseline successfully detects burst via volume heuristics.
