# CanarySentinel — Comprehensive Cross-Scenario Comparison

**Auditor**: Independent Technical and Statistical Quality Team  
**Document**: `research_dossier/04_SCENARIO_ANALYSIS/SCENARIO_COMPARISON.md`  

## 1. Master Cross-Scenario Performance Matrix ($N = 180$)

| Scenario Code | Scenario Name | Category | Planned Ops | Baseline Outcome | Canary-Only Outcome | Hybrid Outcome | Key Scientific Takeaway |
|:---:|:---|:---:|---:|:---:|:---:|:---:|:---|
| **B1** | `Normal File Editing` | Benign | 5 | **10 TN (0 FP)** | **10 TN (0 FP)** | **10 TN (0 FP)** | Quiet workloads cleanly passed by all detectors. |
| **B2** | `Bulk Copying` | Benign | 6 | **10 TN (0 FP)** | **10 TN (0 FP)** | **10 TN (0 FP)** | Sequential file copies stay below rate thresholds. |
| **B3** | `Canary Touch Without Follow-up` | Benign | 4 | **10 TN (0 FP)** | **10 FP (100% Alert)**| **10 TN (0 FP)** | **Hybrid suppresses false alarms** from innocent canary reads. |
| **B4** | `Bulk Renaming` | Benign | 6 | **10 FP (100% Alert)**| **10 TN (0 FP)** | **10 TN (0 FP)** | **Baseline fails** on rapid non-canary renaming bursts. |
| **S5** | `Canary Touch + Rapid Bulk` | Attack | 12 | **10 TP (100% Catch)**| **10 TP (100% Catch)**| **10 TP (100% Catch)**| All catch attack; Hybrid contains in 26.1ms (90.8% ops saved). |
| **S6** | `Rapid Bulk Without Canary` | Attack | 10 | **10 TP (100% Catch)**| **10 FN (100% Miss)** | **10 FN (100% Miss)** | **Deception evasion blindspot**: Baseline only engine to catch. |

## 2. In-Depth Attribution of System Errors
- **Baseline False Positives (Scenario B4)**: Caused by rename rate heuristic (>= 4 renames in 2.0s).
- **Canary-Only False Positives (Scenario B3)**: Caused by naive uncorroborated tripwire trigger on benign canary touch.
- **Hybrid False Negatives (Scenario S6)**: Caused by mandatory prerequisite of canary breach; when attacker evades decoys, hybrid engine never activates.
- **Baseline Resilience (Scenario S6)**: Proves that behavioral volume heuristics must remain active as a fallback tier.
