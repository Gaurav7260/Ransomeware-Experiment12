# Scenario Analysis: B2 — Bulk Copying

**Scenario Code**: `B2`  
**Workload Classification**: `BENIGN` (Ground Truth = 0 (Benign))  
**Audit Status**: **100% INDEPENDENTLY VERIFIED**  

## 1. Scenario Specification & Objectives
- **Objective**: Duplicates a set of files to a backup directory with modest inter-copy delays, modeling backup scripts or manual folder duplication.
- **Input Conditions**: 6 user files copied from documents/ to backup/ directory.
- **Target Files Involved**: user_doc_01.txt to user_doc_06.txt replicated to backup/
- **Theoretical Expectation**: 0 alerts across all detectors (True Negative = 10 for all 3 configurations).
- **Failure Mode Analysis**: None. Delays between copies keep event rates below Baseline velocity threshold.

## 2. Quantitative Empirical Results Across Detectors (10 Trials Each)

| Detector Configuration | Trials ($n$) | Detected | Undetected | Classification Outcome | Mean Latency (ms) | Median Latency | Avg Files Damaged | Prevented Ops % |
|:---|---:|---:|---:|:---:|---:|---:|---:|---:|
| **Baseline** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Canary Only** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Hybrid** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |

## 3. Repetition-Level Trial Logs (All 30 Trials)

| Trial ID | Detector | Planned Ops | Executed Ops | Prevented Ops | Damaged Files | Detected | Latency (ms) | Duration (ms) |
|:---|:---|---:|---:|---:|---:|:---:|---:|---:|
| `baseline_bulk_copying_f06fc6` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 667.0 |
| `baseline_bulk_copying_043471` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 668.0 |
| `baseline_bulk_copying_7a24c3` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 675.5 |
| `baseline_bulk_copying_101418` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 669.1 |
| `baseline_bulk_copying_bebac0` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 671.9 |
| `baseline_bulk_copying_335f2d` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 671.0 |
| `baseline_bulk_copying_c3df15` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 667.1 |
| `baseline_bulk_copying_0aba04` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 668.8 |
| `baseline_bulk_copying_5caad1` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 670.3 |
| `baseline_bulk_copying_5fcc02` | `baseline` | 6 | 6 | 0 | 0 | 0 | - | 662.9 |
| `canary_only_bulk_copying_3902f7` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 678.9 |
| `canary_only_bulk_copying_9e1f30` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 673.6 |
| `canary_only_bulk_copying_ba1f83` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 673.2 |
| `canary_only_bulk_copying_ec0b5f` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 670.6 |
| `canary_only_bulk_copying_64c40a` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 670.0 |
| `canary_only_bulk_copying_329bc7` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 669.1 |
| `canary_only_bulk_copying_ad62e7` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 687.9 |
| `canary_only_bulk_copying_be0e2f` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 666.5 |
| `canary_only_bulk_copying_6eac67` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 670.1 |
| `canary_only_bulk_copying_6a4b80` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 673.5 |
| `hybrid_bulk_copying_849eb5` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 666.9 |
| `hybrid_bulk_copying_f3fdda` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 679.7 |
| `hybrid_bulk_copying_731056` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 675.2 |
| `hybrid_bulk_copying_84be50` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 677.2 |
| `hybrid_bulk_copying_7a7ec1` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 669.9 |
| `hybrid_bulk_copying_96be1a` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 670.5 |
| `hybrid_bulk_copying_5145ce` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 665.7 |
| `hybrid_bulk_copying_a65097` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 669.0 |
| `hybrid_bulk_copying_137c3b` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 670.6 |
| `hybrid_bulk_copying_a7216b` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 672.4 |

## 4. Architectural Findings & Limitations
This scenario conclusively verifies the behavioral characteristics of `B2`. None. Delays between copies keep event rates below Baseline velocity threshold.
