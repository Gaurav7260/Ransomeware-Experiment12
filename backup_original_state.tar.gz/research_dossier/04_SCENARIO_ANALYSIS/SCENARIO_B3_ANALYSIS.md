# Scenario Analysis: B3 — Canary Touch Without Suspicious Follow-up

**Scenario Code**: `B3`  
**Workload Classification**: `BENIGN` (Ground Truth = 0 (Benign))  
**Audit Status**: **100% INDEPENDENTLY VERIFIED**  

## 1. Scenario Specification & Objectives
- **Objective**: Simulates an innocent indexer, antivirus scanner, or curious user opening and modifying a canary decoy file, with zero subsequent burst activity.
- **Input Conditions**: Single canary file !00_corporate_passwords.xlsx touched/modified, followed by 3 isolated non-canary reads.
- **Target Files Involved**: !00_corporate_passwords.xlsx and 3 user documents
- **Theoretical Expectation**: Baseline: 0 alerts (TN). Canary-Only: 10 alerts (FP). Hybrid: 0 alerts (TN).
- **Failure Mode Analysis**: Canary-Only triggers 100% false alarms due to naive tripwire logic. Hybrid suppresses alerts because context velocity is zero.

## 2. Quantitative Empirical Results Across Detectors (10 Trials Each)

| Detector Configuration | Trials ($n$) | Detected | Undetected | Classification Outcome | Mean Latency (ms) | Median Latency | Avg Files Damaged | Prevented Ops % |
|:---|---:|---:|---:|:---:|---:|---:|---:|---:|
| **Baseline** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Canary Only** | 10 | 10 | 0 | **10 FP** / 0 TN | 13.5 ms | 15.1 ms | 0.00 | 75.0% |
| **Hybrid** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |

## 3. Repetition-Level Trial Logs (All 30 Trials)

| Trial ID | Detector | Planned Ops | Executed Ops | Prevented Ops | Damaged Files | Detected | Latency (ms) | Duration (ms) |
|:---|:---|---:|---:|---:|---:|:---:|---:|---:|
| `baseline_canary_touch_benign_ed7706` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1372.9 |
| `baseline_canary_touch_benign_14f006` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1373.3 |
| `baseline_canary_touch_benign_3e7d4e` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1377.7 |
| `baseline_canary_touch_benign_bdd31b` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1381.4 |
| `baseline_canary_touch_benign_041414` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1379.5 |
| `baseline_canary_touch_benign_cd6ffc` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1371.5 |
| `baseline_canary_touch_benign_203f9e` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1374.0 |
| `baseline_canary_touch_benign_e9ef08` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1373.3 |
| `baseline_canary_touch_benign_12b984` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1373.8 |
| `baseline_canary_touch_benign_a25fe3` | `baseline` | 4 | 4 | 0 | 0 | 0 | - | 1372.0 |
| `canary_only_canary_touch_benign_9bdca3` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 14.5 | 458.9 |
| `canary_only_canary_touch_benign_afb74d` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 5.5 | 457.0 |
| `canary_only_canary_touch_benign_69b997` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 15.9 | 458.6 |
| `canary_only_canary_touch_benign_fe65b1` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 15.1 | 462.3 |
| `canary_only_canary_touch_benign_1e878d` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 15.3 | 459.5 |
| `canary_only_canary_touch_benign_6f47a9` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 15.1 | 461.3 |
| `canary_only_canary_touch_benign_d4c868` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 11.9 | 462.2 |
| `canary_only_canary_touch_benign_9cfcee` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 6.8 | 457.6 |
| `canary_only_canary_touch_benign_7d8bcd` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 16.4 | 459.8 |
| `canary_only_canary_touch_benign_fe029d` | `canary_only` | 4 | 1 | 3 | 0 | 1 | 18.2 | 465.3 |
| `hybrid_canary_touch_benign_042c62` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1374.7 |
| `hybrid_canary_touch_benign_dcb604` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1374.4 |
| `hybrid_canary_touch_benign_5e805d` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1379.3 |
| `hybrid_canary_touch_benign_8d3321` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1368.3 |
| `hybrid_canary_touch_benign_d151e6` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1375.3 |
| `hybrid_canary_touch_benign_74ed23` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1369.9 |
| `hybrid_canary_touch_benign_93c4be` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1375.3 |
| `hybrid_canary_touch_benign_4f8482` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1381.0 |
| `hybrid_canary_touch_benign_3fc5f0` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1378.0 |
| `hybrid_canary_touch_benign_108570` | `hybrid` | 4 | 4 | 0 | 0 | 0 | - | 1376.3 |

## 4. Architectural Findings & Limitations
This scenario conclusively verifies the behavioral characteristics of `B3`. Canary-Only triggers 100% false alarms due to naive tripwire logic. Hybrid suppresses alerts because context velocity is zero.
