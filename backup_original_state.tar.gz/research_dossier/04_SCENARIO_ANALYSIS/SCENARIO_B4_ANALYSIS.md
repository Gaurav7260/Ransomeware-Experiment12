# Scenario Analysis: B4 — Bulk Renaming

**Scenario Code**: `B4`  
**Workload Classification**: `BENIGN` (Ground Truth = 0 (Benign))  
**Audit Status**: **100% INDEPENDENTLY VERIFIED**  

## 1. Scenario Specification & Objectives
- **Objective**: Renames a batch of user documents with standard numbering prefixes, modeling benign developer refactoring or file reorganization.
- **Input Conditions**: 6 user documents rapidly renamed in succession.
- **Target Files Involved**: user_doc_01.txt through user_doc_06.txt renamed to archive_doc_*.txt
- **Theoretical Expectation**: Baseline: 10 alerts (FP). Canary-Only: 0 alerts (TN). Hybrid: 0 alerts (TN).
- **Failure Mode Analysis**: Baseline triggers 100% false alarms because 6 rapid renames exceed mass-rename threshold. Canary-Only and Hybrid correctly ignore.

## 2. Quantitative Empirical Results Across Detectors (10 Trials Each)

| Detector Configuration | Trials ($n$) | Detected | Undetected | Classification Outcome | Mean Latency (ms) | Median Latency | Avg Files Damaged | Prevented Ops % |
|:---|---:|---:|---:|:---:|---:|---:|---:|---:|
| **Baseline** | 10 | 10 | 0 | **10 FP** / 0 TN | 271.3 ms | 271.6 ms | 0.00 | 33.3% |
| **Canary Only** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |
| **Hybrid** | 10 | 0 | 10 | **10 TN** (Clean) | N/A | N/A | 0.00 | 0.0% |

## 3. Repetition-Level Trial Logs (All 30 Trials)

| Trial ID | Detector | Planned Ops | Executed Ops | Prevented Ops | Damaged Files | Detected | Latency (ms) | Duration (ms) |
|:---|:---|---:|---:|---:|---:|:---:|---:|---:|
| `baseline_bulk_renaming_fe7673` | `baseline` | 6 | 4 | 2 | 0 | 1 | 274.7 | 497.3 |
| `baseline_bulk_renaming_9144ec` | `baseline` | 6 | 4 | 2 | 0 | 1 | 264.6 | 493.2 |
| `baseline_bulk_renaming_e37edc` | `baseline` | 6 | 4 | 2 | 0 | 1 | 275.7 | 492.7 |
| `baseline_bulk_renaming_6769c0` | `baseline` | 6 | 4 | 2 | 0 | 1 | 276.5 | 502.1 |
| `baseline_bulk_renaming_9d7ffe` | `baseline` | 6 | 4 | 2 | 0 | 1 | 263.6 | 485.5 |
| `baseline_bulk_renaming_ab5efe` | `baseline` | 6 | 4 | 2 | 0 | 1 | 274.9 | 498.8 |
| `baseline_bulk_renaming_ac817d` | `baseline` | 6 | 4 | 2 | 0 | 1 | 270.6 | 492.8 |
| `baseline_bulk_renaming_425bd9` | `baseline` | 6 | 4 | 2 | 0 | 1 | 271.6 | 495.9 |
| `baseline_bulk_renaming_2bff6c` | `baseline` | 6 | 4 | 2 | 0 | 1 | 271.6 | 492.9 |
| `baseline_bulk_renaming_79d3f9` | `baseline` | 6 | 4 | 2 | 0 | 1 | 269.0 | 499.9 |
| `canary_only_bulk_renaming_b0ecbd` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 665.6 |
| `canary_only_bulk_renaming_2bb078` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 664.4 |
| `canary_only_bulk_renaming_86cf0f` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 660.3 |
| `canary_only_bulk_renaming_799b1f` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 656.1 |
| `canary_only_bulk_renaming_e713b3` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 666.8 |
| `canary_only_bulk_renaming_27da67` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 663.5 |
| `canary_only_bulk_renaming_c5bc72` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 666.7 |
| `canary_only_bulk_renaming_6261c1` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 666.0 |
| `canary_only_bulk_renaming_8c34c2` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 659.4 |
| `canary_only_bulk_renaming_c61707` | `canary_only` | 6 | 6 | 0 | 0 | 0 | - | 662.7 |
| `hybrid_bulk_renaming_cf0492` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 664.7 |
| `hybrid_bulk_renaming_b8d029` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 673.1 |
| `hybrid_bulk_renaming_d70947` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 664.1 |
| `hybrid_bulk_renaming_c29dcd` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 665.3 |
| `hybrid_bulk_renaming_32d68f` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 664.5 |
| `hybrid_bulk_renaming_679603` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 665.2 |
| `hybrid_bulk_renaming_c39426` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 666.7 |
| `hybrid_bulk_renaming_e2cd08` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 678.8 |
| `hybrid_bulk_renaming_22ed14` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 667.1 |
| `hybrid_bulk_renaming_7c2745` | `hybrid` | 6 | 6 | 0 | 0 | 0 | - | 664.1 |

## 4. Architectural Findings & Limitations
This scenario conclusively verifies the behavioral characteristics of `B4`. Baseline triggers 100% false alarms because 6 rapid renames exceed mass-rename threshold. Canary-Only and Hybrid correctly ignore.
