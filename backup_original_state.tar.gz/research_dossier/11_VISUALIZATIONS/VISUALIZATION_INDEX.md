# Publication Visualizations & Chart Inventory

**Document**: `research_dossier/11_VISUALIZATIONS/VISUALIZATION_INDEX.md`  
**Dataset**: Full 180-trial experimental execution stored in `canary_sentinel.db`  

---

## Master Inventory of Verified Visualizations

| Figure Number | Image Filename | Title | Data Source | Calculation Method | Key Scientific Interpretation |
|:---:|:---|:---|:---|:---|:---|
| **Figure 1** | `fig01_overall_performance.svg` | Overall Detector Metric Comparison | `scenarios` table | Macro-averaging across 60 trials per configuration | Illustrates the trade-off: Hybrid maximizes precision (100%) and minimizes false alarms (0%), but sacrifices recall (50%). |
| **Figure 2** | `fig02_precision_comparison.svg` | Precision by Detection Configuration | `CONFUSION_MATRICES.csv` | $\text{TP} / (\text{TP} + \text{FP})$ | Hybrid achieves perfect 100.0% precision, compared to 66.7% in Baseline and 50.0% in Canary-Only. |
| **Figure 3** | `fig03_recall_comparison.svg` | Recall (Sensitivity) Across Configurations | `CONFUSION_MATRICES.csv` | $\text{TP} / (\text{TP} + \text{FN})$ | Baseline catches 100% of attacks, whereas Canary-Only and Hybrid miss 50% due to decoy evasion in Scenario S6. |
| **Figure 4** | `fig04_f1_score_comparison.svg` | F1-Score Across Configurations | `DETECTOR_METRICS.csv` | Harmonic mean: $2PR / (P+R)$ | Baseline achieves higher F1 (0.80) than Hybrid (0.67) due to its superior recall. |
| **Figure 5** | `fig05_fpr_comparison.svg` | False Positive Rate Across Benign Workloads | `CONFUSION_MATRICES.csv` | $\text{FP} / (\text{FP} + \text{TN})$ | Hybrid completely suppresses false alarms (0.0%), compared to 25.0% in Baseline and Canary-Only. |
| **Figure 6** | `fig06_confusion_matrices.svg` | Side-by-Side Confusion Matrices (60 Trials) | `CONFUSION_MATRICES.csv` | 2x2 contingency matrix per detector | Visualizes exact TP, FP, TN, and FN cell counts across all 180 trials. |
| **Figure 7** | `fig07_latency_distribution.svg` | Mean Detection Latency on Alerted Trials | `scenarios.detection_latency_ms` | Arithmetic mean across alerted trials | Canary-assisted detection (18.9–26.1 ms) is an order of magnitude faster than Baseline (147.1 ms). |
| **Figure 8** | `fig08_latency_by_scenario.svg` | Detection Latency Across Alerting Scenarios | `scenarios` grouped | Mean latency per scenario | Shows multimodality: S5 alerts in 25.8 ms, S6 in 144.0 ms, and B4 (false positive) in 271.3 ms. |
| **Figure 9** | `fig09_files_damaged_by_detector.svg` | Mean Files Damaged During Attack Trials | `scenarios.files_damaged` | Arithmetic mean across 20 attack trials | Baseline damages 3.05 files on average; Canary-Only and Hybrid damage 5.05 files due to S6 misses. |
| **Figure 10**| `fig10_operations_prevented.svg` | Operations Prevented Percentage | `scenarios.prevented_ops` | Mean of per-trial prevented percentages | Baseline halts 65.3% of attack operations; Hybrid halts 45.4% overall (90.8% in S5, 0.0% in S6). |
| **Figure 11**| `fig11_s5_vs_s6_comparison.svg` | Hybrid Prevention: Standard (S5) vs Evasive (S6)| `SCENARIO_RESULTS.csv` | Scenario-level breakdown of Hybrid ops | Directly explains the 45.4% vs 90.8% discrepancy: 90.8% prevented when hit, 0.0% when evaded. |
| **Figure 12**| `fig12_cpu_comparison.svg` | Host CPU Utilization by Configuration | `system_metrics.cpu_percent` | Mean CPU % of host Python process | CPU footprint is statistically indistinguishable (~25.4% to 26.6%) across all configurations. |
| **Figure 13**| `fig13_memory_comparison.svg` | Resident Process Memory Usage (RAM) | `system_metrics.memory_mb` | Mean RSS memory in megabytes | Process memory remains strictly bounded below 38 MB across all 180 runs. |
| **Figure 14**| `fig14_scenario_detection_outcomes.svg`| Detection Rates Across All 6 Scenarios | `SCENARIO_RESULTS.csv` | Scenario detection rate (0% or 100%) | Highlights exact scenario failure modes: Baseline fails in B4; Canary-Only fails in B3; Hybrid misses S6. |
| **Figure 15**| `fig15_hypothesis_evaluation.svg` | Formal Evaluation of Research Hypotheses | `07_RESEARCH_VALIDITY/` | Synthesis of empirical hypothesis testing | Visual summary showing H1 Confirmed, H2 Conditionally Confirmed, and H3 Rejected. |

