# CanarySentinel — Experiment Data Dictionary

**Document**: `research_dossier/03_EXPERIMENTAL_DATA/EXPERIMENT_DATA_DICTIONARY.md`  
**Dataset**: `research_dossier/03_EXPERIMENTAL_DATA/RAW_EXPERIMENT_DATA.csv`  
**Source Database**: `canary_sentinel.db` (Tables: `scenarios`, `alerts`, `system_metrics`)  

---

## 1. Field Definitions and Types

| Field Name | Data Type | Permitted Values / Range | Description | Authoritative Source Table |
|:---|:---:|:---:|:---|:---|
| `trial_id` | String | `[config]_[scenario]_[hex]` | Globally unique identifier for the individual trial run. | `scenarios.scenario_id` |
| `experiment_id` | String | E.g., `batch_2026_01` | Batch execution run identifier grouping the 180 trials. | Generated Batch Identifier |
| `detector` | String | `baseline`, `canary_only`, `hybrid` | The detection configuration active during the trial. | `scenarios.detector_config` |
| `scenario_name` | String | 6 scenario names | Human-readable name of the simulated workload. | `scenarios.scenario_name` |
| `ground_truth` | String | `benign`, `suspicious` | True class label of the workload according to experimental design. | `scenarios.scenario_type` |
| `alert_generated` | Integer (0/1) | `0` (No), `1` (Yes) | Whether the detector triggered a security alert during the trial. | `scenarios.detected` |
| `alert_id` | String / Null | UUID or empty | Foreign key referencing the primary alert record if triggered. | `scenarios.alert_id` |
| `detection_timestamp`| String / Null| ISO-8601 UTC | Timestamp when the first alert was recorded. | `alerts.iso_timestamp` |
| `detection_latency_ms`| Float / Null | $>0.0$ or NULL | Measured time difference in milliseconds between trial start and alert. | `scenarios.detection_latency_ms` |
| `operations_planned` | Integer | $4 - 12$ | Total planned file operations defined in the scenario catalog. | `scenarios.planned_ops` |
| `operations_executed`| Integer | $1 - 12$ | Actual file operations executed by the simulator before termination. | `scenarios.executed_ops` |
| `operations_prevented`| Integer | $0 - 11$ | Number of operations halted by simulated containment: `planned - executed`. | `scenarios.prevented_ops` |
| `files_damaged` | Integer | $0 - 10$ | Number of user documents corrupted with simulated high-entropy ciphertext. | `scenarios.files_damaged` |
| `files_targeted` | Integer | $4 - 12$ | Total target files specified in the scenario definition. | Scenario Definition Catalog |
| `files_modified` | Integer | $1 - 12$ | Actual files touched during the trial. | `scenarios.executed_ops` |
| `cpu_usage` | Float | $0.0 - 100.0\%$ | Host Python process CPU percentage during the trial run. | `system_metrics.cpu_percent` |
| `memory_usage` | Float | $>0.0$ MB | Host Python process Resident Set Size (RSS) memory in megabytes. | `system_metrics.memory_mb` |
| `response_triggered` | Integer (0/1) | `0` (No), `1` (Yes) | Whether the response manager activated simulated containment. | `scenarios.response_triggered` |
| `response_type` | String | `internal_block_flag`, `none` | Containment mechanism utilized (`internal_block_flag` verified). | Derived from `SimulatedResponseManager` |
| `trial_status` | String | `Completed`, `Failed` | Final execution status of the trial (`Completed` for all 180). | System Execution Log |
| `start_time` | Float | Unix Epoch Seconds | High-resolution timestamp marking the start of scenario simulation. | `scenarios.start_time` |
| `end_time` | Float | Unix Epoch Seconds | High-resolution timestamp marking the conclusion of the trial. | `scenarios.end_time` |
| `duration_ms` | Float | $>0.0$ ms | Total elapsed wall-clock duration of the trial in milliseconds. | `scenarios.duration_ms` |
| `evidence_source` | String | Text | Primary repository location from which row data was extracted. | Audit Register |

---

## 2. Null Value Handling Rules

1. `detection_latency_ms`: Evaluates to `NULL` (empty in CSV) for trials where `alert_generated == 0`. Undetected trials must **never** be coded as `0.0 ms`.
2. `alert_id` and `detection_timestamp`: Evaluate to `NULL` for trials where no alert was generated.
3. All operational counts (`operations_planned`, `operations_executed`, `operations_prevented`, `files_damaged`) are non-nullable integers.

