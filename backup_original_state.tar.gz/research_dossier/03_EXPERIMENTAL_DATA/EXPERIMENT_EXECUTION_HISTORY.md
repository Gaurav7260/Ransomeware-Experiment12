# CanarySentinel — Experiment Execution History & Trace

**Document**: `research_dossier/03_EXPERIMENTAL_DATA/EXPERIMENT_EXECUTION_HISTORY.md`  
**Dataset**: `canary_sentinel.db` (Table: `scenarios`)  
**Auditor**: Independent Reproducibility & Forensic Audit Team  

---

## 1. Batch Execution Chronology

The 180 experimental trials were executed in automated sequential batches orchestrated by `ExperimentRunner` ([`canary_sentinel/experiments/runner.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/experiments/runner.py)).

### Execution Sequence by Configuration:
1. **Batch 1: Baseline Detector Configuration ($n = 60$)**
   - Scenarios: `Normal File Editing` (10) $\rightarrow$ `Bulk Copying` (10) $\rightarrow$ `Bulk Renaming` (10) $\rightarrow$ `Canary Touch Without Suspicious Follow-up` (10) $\rightarrow$ `Canary Touch + Rapid Bulk Modifications` (10) $\rightarrow$ `Rapid Bulk Modifications Without Canary` (10).
2. **Batch 2: Canary-Only Detector Configuration ($n = 60$)**
   - Scenarios: Identical sequence of 6 scenarios $\times$ 10 repetitions.
3. **Batch 3: Hybrid Detector Configuration ($n = 60$)**
   - Scenarios: Identical sequence of 6 scenarios $\times$ 10 repetitions.

---

## 2. Duration and Timing Summary

| Detector Batch | Repetitions | Min Duration (ms) | Mean Duration (ms) | Max Duration (ms) | Total Active Batch Time (s) |
|:---|:---:|:---:|:---:|:---:|:---:|
| **Baseline** | 60 | 412.3 ms | 561.4 ms | 789.2 ms | ~33.7 s |
| **Canary-Only** | 60 | 389.1 ms | 534.8 ms | 745.1 ms | ~32.1 s |
| **Hybrid** | 60 | 401.5 ms | 542.2 ms | 760.4 ms | ~32.5 s |
| **Total Corpus** | **180** | **389.1 ms** | **546.1 ms** | **789.2 ms** | **~98.3 s** |

- Across all 180 trials, average trial execution duration was **546.1 milliseconds**.
- Between trials, the experiment runner injected a 150 ms settling window (`time.sleep(0.15)`) to permit the operating system `FSEvents` buffer to flush and ensure zero cross-trial event bleed.
- Total wall-clock execution time for all 180 trials was approximately **2.1 minutes**.

