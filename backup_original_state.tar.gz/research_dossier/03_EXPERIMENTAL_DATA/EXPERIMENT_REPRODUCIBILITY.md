# CanarySentinel — Experiment Reproducibility Protocol

**Document**: `research_dossier/03_EXPERIMENTAL_DATA/EXPERIMENT_REPRODUCIBILITY.md`  
**Scope**: Exact replication instructions to reproduce the 180-trial experimental dataset.  

---

## 1. Prerequisites and Environment Setup

Replication requires macOS (tested on Apple Silicon M1, macOS 15.x Sequoia) with Python 3.12+ installed:

```bash
# 1. Clone repository and navigate to root
cd CanarySentinel

# 2. Initialize clean virtual environment
python3 -m venv .venv
source .venv/bin/activate

# 3. Install pinned dependencies
pip install -r requirements.txt
```

---

## 2. Automated Benchmark Execution Command

The experiment suite can be triggered either via the CLI runner or the Streamlit dashboard:

### Method A: Direct Python Execution via Script / CLI
```bash
# To run the complete 180-trial benchmark suite:
python3 -c "
from canary_sentinel.core.sandbox import SandboxManager
from canary_sentinel.canary.manager import CanaryManager
from canary_sentinel.storage.db import Database
from canary_sentinel.monitoring.monitor import FilesystemMonitor
from canary_sentinel.simulation.response_manager import SimulatedResponseManager
from canary_sentinel.experiments.runner import ExperimentRunner

db = Database('canary_sentinel.db')
sandbox = SandboxManager('./sandbox')
canary_mgr = CanaryManager(sandbox, db)
canary_mgr.deploy_canaries()
monitor = FilesystemMonitor(sandbox.sandbox_path)
monitor.start()
response_mgr = SimulatedResponseManager()

runner = ExperimentRunner(sandbox, canary_mgr, monitor, db, response_mgr)
results = runner.run_full_benchmark(repetitions=10)
print(f'Successfully completed {len(results)} trials!')
monitor.stop()
"
```

### Method B: Streamlit Web Dashboard Execution
1. Launch dashboard: `source .venv/bin/activate && streamlit run canary_sentinel/dashboard/app.py`
2. Navigate to tab: **"Simulation & Experiments"**
3. Select repetition count: `10`
4. Click: **"🚀 Run Complete Comparative Benchmark Suite (180 Trials)"**
5. Monitor real-time execution progress bar until 100% completion.

---

## 3. Post-Run Verification Command
To verify that the newly generated database matches the verified metrics:
```bash
python3 -c "
from canary_sentinel.storage.db import Database
from canary_sentinel.experiments.metrics import MetricsCalculator
db = Database('canary_sentinel.db')
calc = MetricsCalculator(db)
rep = calc.generate_comparison_report()
for k, m in rep.metrics_by_detector.items():
    print(f'{k.upper()}: TP={m.true_positives}, FP={m.false_positives}, TN={m.true_negatives}, FN={m.false_negatives}, Prec={m.precision:.2%}, Rec={m.recall:.2%}, FPR={m.false_positive_rate:.2%}')
"
```
Output must reproduce:
- `BASELINE`: TP=20, FP=10, TN=30, FN=0, Prec=66.67%, Rec=100.00%, FPR=25.00%
- `CANARY_ONLY`: TP=10, FP=10, TN=30, FN=10, Prec=50.00%, Rec=50.00%, FPR=25.00%
- `HYBRID`: TP=10, FP=0, TN=40, FN=10, Prec=100.00%, Rec=50.00%, FPR=0.00%

