# Master Academic Research Dossier Index & Verification Register

**Project Title**: CanarySentinel — Deception-Based Ransomware Detection, Behavioral Analysis and Risk-Aware Response System  
**Research Title**: Evaluating Canary-Triggered Behavioral Corroboration for Early Ransomware Detection and Damage Reduction  
**Auditor**: Multidisciplinary Academic, Software Architecture, and Security Audit Team  
**Document**: `research_dossier/FINAL_RESEARCH_DOSSIER_INDEX.md`  

---

## 1. Master Dossier Directory Architecture

The complete, evidence-based research dossier is organized into 13 dedicated numbered audit directories and root documents:

```
research_dossier/
├── 01_PROJECT_INVENTORY/
│   ├── PROJECT_FILE_INVENTORY.md              # Full inventory of all 129 repository files
│   └── PROJECT_ARCHITECTURE_OVERVIEW.md       # Trace of 10-stage lifecycle & code inspection
├── 02_TECHNICAL_AUDIT/
│   ├── TECHNICAL_AUDIT_REPORT.md              # Synthesis of security, telemetry, and engine audit
│   ├── SECURITY_AND_SANDBOX_AUDIT.md          # In-depth path resolution and containment audit
│   ├── DETECTION_LOGIC_AUDIT.md               # Audited rules, thresholds, and trigger logic
│   └── DATABASE_SCHEMA_AND_DATA_INTEGRITY.md  # Schema definitions, WAL mode, relational integrity
├── 03_EXPERIMENTAL_DATA/
│   ├── RAW_EXPERIMENT_DATA.csv                # Complete 180-trial joined database export
│   ├── EXPERIMENT_DATA_DICTIONARY.md          # Precise field definitions, types, and sources
│   ├── DATA_QUALITY_AUDIT.md                  # Verification of sample completeness and uniqueness
│   ├── EXPERIMENT_EXECUTION_HISTORY.md        # Execution trace and batch durations
│   └── EXPERIMENT_REPRODUCIBILITY.md          # Standard replication commands and protocols
├── 04_SCENARIO_ANALYSIS/
│   ├── SCENARIO_B1_ANALYSIS.md                # B1: Normal File Editing (10/10 TN across all)
│   ├── SCENARIO_B2_ANALYSIS.md                # B2: Bulk Copying (10/10 TN across all)
│   ├── SCENARIO_B3_ANALYSIS.md                # B3: Canary Touch Benign (Canary-Only FP=10, Hybrid TN=10)
│   ├── SCENARIO_B4_ANALYSIS.md                # B4: Bulk Renaming (Baseline FP=10, Hybrid TN=10)
│   ├── SCENARIO_S5_ANALYSIS.md                # S5: Canary Touch + Rapid Bulk (10/10 TP across all)
│   ├── SCENARIO_S6_ANALYSIS.md                # S6: Evasive Attack (Baseline TP=10, Hybrid FN=10)
│   └── SCENARIO_COMPARISON.md                 # Cross-scenario performance and attribution matrix
├── 05_METRICS_AND_STATISTICS/
│   ├── DETECTOR_METRICS.csv                   # Recalculated performance metrics across detectors
│   ├── CONFUSION_MATRICES.csv                 # Granular TP, FP, TN, FN matrix across configurations
│   ├── SCENARIO_METRICS.csv                   # Scenario-level breakdown of latency and damage
│   ├── METRICS_CALCULATION_METHODOLOGY.md     # Formulas, denominators, and edge-case guards
│   ├── INDEPENDENT_METRICS_VALIDATION.md      # Side-by-side numerical recalculations
│   ├── STATISTICAL_ANALYSIS.md                # Welch t-test, Mann-Whitney U, Fisher exact, effect sizes
│   ├── STATISTICAL_TEST_RESULTS.csv           # Tabular export of all hypothesis test statistics
│   └── STATISTICAL_LIMITATIONS.md             # Normality deviations and power considerations
├── 06_DISCREPANCY_REGISTER/
│   └── DISCREPANCY_REGISTER.md                # Audited register of 7 discrepancies and resolutions
├── 07_RESEARCH_VALIDITY/
│   ├── RESEARCH_GAP_AND_NOVELTY_AUDIT.md      # Conservative evaluation of genuine research gap
│   ├── THREATS_TO_VALIDITY.md                 # Construct, internal, external, and conclusion validity
│   ├── RESEARCH_CONTRIBUTION.md               # Clear articulation of verified academic contribution
│   └── HYPOTHESIS_EVALUATION.md               # Formal verdicts on H1, H2, and H3
├── 08_LITERATURE_REVIEW/
│   ├── LITERATURE_REVIEW.md                   # 12-section literature review covering all paradigms
│   ├── REFERENCE_VERIFICATION_MATRIX.csv      # Verification matrix of all 14 academic citations
│   ├── RESEARCH_COMPARISON_MATRIX.md          # 10 prior systems compared across 10 dimensions
│   └── FINAL_REFERENCES.md                    # Bibliographic references with verified DOIs
├── 09_REPRODUCIBILITY/
│   ├── REPRODUCIBILITY_GUIDE.md               # Quick-start reproduction commands
│   ├── ENVIRONMENT_SPECIFICATION.md           # Pinned hardware, OS, and Python dependencies
│   ├── EXPERIMENT_EXECUTION_PROTOCOL.md       # Standard operating procedure for benchmark runs
│   └── REPRODUCIBILITY_CHECKLIST.md           # Formal verification checklist
├── 10_TESTING/
│   ├── TEST_EXECUTION_REPORT.md               # 45 passed tests log and execution times
│   ├── TEST_COVERAGE_ANALYSIS.md              # Coverage breakdown across subsystems (~94.5%)
│   ├── SECURITY_TEST_RESULTS.md               # 10 dedicated security boundary test outcomes
│   └── KNOWN_DEFECTS.md                       # Audited register of minor defects and resolutions
├── 11_VISUALIZATIONS/
│   ├── fig01_overall_performance.svg          # Figure 1: Overall Metric Comparison
│   ├── fig02_precision_comparison.svg         # Figure 2: Precision by Configuration
│   ├── fig03_recall_comparison.svg            # Figure 3: Recall (Sensitivity) Across Configurations
│   ├── fig04_f1_score_comparison.svg          # Figure 4: F1-Score Across Configurations
│   ├── fig05_fpr_comparison.svg               # Figure 5: False Positive Rate on Benign Workloads
│   ├── fig06_confusion_matrices.svg           # Figure 6: Side-by-Side 2x2 Confusion Matrices
│   ├── fig07_latency_distribution.svg         # Figure 7: Detection Latency with 95% CIs
│   ├── fig08_latency_by_scenario.svg          # Figure 8: Latency Breakdown across Alerting Scenarios
│   ├── fig09_files_damaged_by_detector.svg    # Figure 9: Mean Files Damaged During Attacks
│   ├── fig10_operations_prevented.svg         # Figure 10: Percentage Operations Prevented
│   ├── fig11_s5_vs_s6_comparison.svg          # Figure 11: Hybrid Damage Prevention (S5 vs S6)
│   ├── fig12_cpu_comparison.svg               # Figure 12: Host CPU Overhead by Configuration
│   ├── fig13_memory_comparison.svg            # Figure 13: Resident Memory Footprint (RAM)
│   ├── fig14_scenario_detection_outcomes.svg  # Figure 14: Detection Rates Across All 6 Scenarios
│   ├── fig15_hypothesis_evaluation.svg        # Figure 15: Formal Evaluation of Research Hypotheses
│   └── VISUALIZATION_INDEX.md                 # Metadata, sources, and captions for all 15 figures
├── 12_FINAL_DOCUMENTS/
│   ├── CANARYSENTINEL_FINAL_RESEARCH_PAPER.md # 28-section formal academic research paper
│   ├── CANARYSENTINEL_FINAL_PROJECT_REPORT.md # 30-section university B.Tech capstone report
│   ├── CANARYSENTINEL_TECHNICAL_DOCUMENTATION.md# Complete developer and architecture guide
│   ├── RESEARCH_METHODOLOGY_AND_EXPERIMENT_DESIGN.md # Variables, ground truth, and protocol
│   ├── CANARYSENTINEL_PRESENTATION_CONTENT.md # 25-slide final defence deck with full speaker notes
│   └── VIVA_QUESTIONS_AND_ANSWERS.md          # 110 rigorous viva questions & authoritative answers
├── 13_EVIDENCE_AND_AUDIT/
│   ├── EVIDENCE_REGISTER.csv                  # 15 empirical claims mapped to source code & tests
│   ├── CLAIM_VERIFICATION_MATRIX.md           # Claim-by-claim verification and permitted wording
│   └── FINAL_INDEPENDENT_AUDIT_REPORT.md      # Comprehensive audit verdict and executive sign-off
├── FINAL_RESEARCH_DOSSIER_INDEX.md            # This index document
└── FINAL_COMPLETION_REPORT.md                 # Summary of all audit findings and commands
```

---

## 2. Key Empirical Findings Summary ($N = 180$)

- **Baseline Behavioral**: Precision = 66.67%, Recall = **100.00%**, F1 = **0.80**, FPR = 25.00%, Mean Latency = 147.05 ms (84.92 ms on TP attacks), Files Damaged = **3.05**, Ops Prevented = **65.33%**.
- **Canary-Only**: Precision = 50.00%, Recall = 50.00%, F1 = 0.50, FPR = 25.00%, Mean Latency = **18.88 ms**, Files Damaged = 5.05, Ops Prevented = 45.42%.
- **Hybrid Correlated**: Precision = **100.00%**, Recall = 50.00%, F1 = 0.67, FPR = **0.00%**, Mean Latency = 26.10 ms, Files Damaged = 5.05, Ops Prevented = 45.42% (90.83% in S5, 0.0% in S6).

---

## 3. Reconciled Discrepancies Summary

1. **Containment Mechanism**: Implemented via an internal thread-safe software block flag (`self._blocked = True`), ensuring 100% host OS safety. Does not dispatch POSIX signals.
2. **Baseline False Alarms**: Occurred during Scenario B4 (`Bulk Renaming`) due to mass-rename heuristic, not Scenario B2.
3. **Operations Prevented Aggregation**: 45.42% is the unweighted arithmetic mean of trial ratios: $(90.83\% \times 10 + 0.0\% \times 10) / 20$. Ratio of total sums is 49.55%.
4. **Hypothesis H3 (Universal Superiority)**: Formally **rejected** because Baseline achieved higher recall (100% vs 50%) and F1 (0.80 vs 0.67). A two-tier defense-in-depth model is prescribed.
