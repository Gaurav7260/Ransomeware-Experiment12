# Known Defects and Limitations Register

**Document**: `research_dossier/10_TESTING/KNOWN_DEFECTS.md`  

---

## 1. Software Defects Audited and Reconciled

| Defect ID | Severity | Component | Description | Resolution / Status |
|:---|:---:|:---|:---|:---|
| **DEF-01** | Low | Dashboard UI | Deprecation warning for `use_container_width` in Streamlit 1.43 (scheduled removal Dec 2025). | Harmless runtime warning; UI operates correctly. |
| **DEF-02** | Medium | Documentation | Prior reports claimed response manager sent POSIX `SIGTERM`/`SIGKILL` signals to PIDs. | Corrected: Implementation uses internal boolean block flag (`self._blocked = True`). |
| **DEF-03** | Medium | Documentation | Prior reports attributed Baseline false alarms to Scenario B2 (`Bulk Copying`). | Corrected: In raw SQLite data, Baseline false alarms occurred in Scenario B4 (`Bulk Renaming`). |
| **DEF-04** | Low | Metrics Calculation | CPU and RAM metrics queried globally rather than by detector ID in early summaries. | Corrected: Metrics filtered strictly by detector scenario IDs. |
