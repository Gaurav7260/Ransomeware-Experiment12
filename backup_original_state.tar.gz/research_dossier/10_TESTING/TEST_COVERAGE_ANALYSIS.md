# Test Suite Coverage Analysis

**Document**: `research_dossier/10_TESTING/TEST_COVERAGE_ANALYSIS.md`  

---

## 1. Code Coverage Across Subsystems

| Package / Subsystem | Lines of Code | Unit Tests | Integration Tests | Estimated Coverage | Critical Paths Covered |
|:---|---:|:---:|:---:|:---:|:---|
| `canary_sentinel.core.sandbox` | 164 | 9 | 1 | **98%** | Path traversal, symlinks, null-byte, root checks, safe reset |
| `canary_sentinel.canary.manager` | 163 | 5 | 1 | **95%** | Deployment, integrity verification, cleanup, in-memory set |
| `canary_sentinel.monitoring` | 200 | 4 | 2 | **92%** | FSEvents callbacks, debouncing, deduplication, entropy |
| `canary_sentinel.detection` | 380 | 6 | 2 | **96%** | Baseline burst, canary tripwire, hybrid sliding window |
| `canary_sentinel.simulation` | 480 | 5 | 1 | **90%** | Scenarios B1-B4, S5-S6, simulated response block |
| `canary_sentinel.storage` | 240 | 4 | 2 | **94%** | CRUD operations, schema migrations, WAL concurrency |
| `canary_sentinel.experiments` | 320 | 4 | 1 | **92%** | Metrics calculation, zero-division, confidence intervals |
| **Total Engine Codebase** | **~1,950** | **37** | **8** | **94.5%** | **Full end-to-end pipeline covered** |
