# Research Gap and Novelty Audit

**Auditor**: Senior Cybersecurity Researcher & Academic Integrity Auditor  
**Document**: `research_dossier/07_RESEARCH_VALIDITY/RESEARCH_GAP_AND_NOVELTY_AUDIT.md`  

---

## 1. Conservative Evaluation of Novelty

Scientific integrity requires stating what the project **does not invent**:
- CanarySentinel did **not** invent canary or honeypot files (formalized by Moore, 2017; Spitzner, 2003).
- CanarySentinel did **not** invent behavioral ransomware detection (pioneered by Scaife et al., CryptoDrop, 2016).
- CanarySentinel did **not** invent sliding-window event correlation (standard distributed systems technique).
- CanarySentinel did **not** invent automated containment (Continella et al., ShieldFS, 2016).

---

## 2. The Genuine Research Gap

Prior academic systems focused heavily on either:
1. **Isolated Honeypots**: Deployed decoy files without behavioral context, suffering high false alarm rates during administrative scans or indexing (e.g., Moore, 2017).
2. **Heavyweight Kernel/Driver Architectures**: Systems such as ShieldFS (Windows minifilter) and GuardFS (Linux VFS/FUSE) introduced significant kernel complexity (12–18% CPU overhead), requiring privileged kernel extensions that are increasingly deprecated on modern operating systems (e.g., Apple's deprecation of KEXTs in macOS).
3. **Decoy-Evasion Blindness**: Many deception evaluations tested only naive alphabetical traversal, failing to benchmark performance when an attacker deliberately evades honeypots.

### The Research Gap Addressed by CanarySentinel:
There was a distinct lack of controlled empirical benchmarks on modern Unix/macOS platforms evaluating:
- Whether **user-space temporal sliding-window correlation** can suppress 100% of false alarms from accidental decoy access without requiring kernel extensions or hardware performance counters.
- The exact performance trade-offs (Precision, Recall, Latency, Damage) when **identical, debounced event streams** are fed concurrently into Baseline, Canary-Only, and Hybrid models under both standard and evasive ransomware workloads.

---

## 3. Validated Research Contribution

CanarySentinel makes three verifiable academic and engineering contributions:
1. **The Correlated Context Empirical Proof**:
   Provides empirical proof ($N = 180$) that requiring contextual filesystem velocity ($\ge 3$ ops in sliding window) around a canary touch reduces False Positive Rate from **25.0% to 0.0%** ($p = 0.0011$, Fisher's exact test).
2. **Decoy-Evasion Quantification**:
   Quantifies the catastrophic failure of pure deception under evasion: when malware skips canaries (Scenario S6), Hybrid and Canary-Only achieve **0% detection** (10.0 files damaged), whereas Baseline achieves **100% detection** (preventing 55.2% of operations).
3. **The Defense-in-Depth Architectural Cascade**:
   Demonstrates that Hybrid detection cannot serve as a solitary replacement for behavioral heuristics. Instead, it proves the necessity of a two-tier cascade: Hybrid fast-path for zero-false-alarm automated killing, backed by Baseline behavioral monitoring for evasive attack safety.

