# Academic and Engineering Research Contribution

**Document**: `research_dossier/07_RESEARCH_VALIDITY/RESEARCH_CONTRIBUTION.md`  
**Focus**: Rigorous articulation of CanarySentinel's verified academic contribution.  

---

## 1. Primary Research Contribution

The primary research contribution of CanarySentinel is an **empirically validated proof that temporal sliding-window corroboration solves the false-alarm dilemma of deception security while demonstrating why deception cannot serve as a standalone defense**.

### Detailed Contributions:

1. **Resolution of the Honeypot False-Positive Dilemma**:
   - Demonstrated that uncorroborated honeypots suffer an unacceptable **25.0% False Positive Rate** on non-malicious user inspection (Scenario B3).
   - Formulated a multi-criteria temporal sliding-window correlation algorithm that requires contextual filesystem velocity ($\ge 3$ ops in 3.0s) surrounding a canary touch, successfully driving false alarms to **0.0%** ($p = 0.0011$).
2. **Empirical Benchmarking of Decoy Evasion (Scenario S6)**:
   - Proved that when an adversary circumvents canaries through selective traversal, deception-only and hybrid engines fail completely (**0.0% Recall**, 10.0 files damaged).
   - In contrast, pure behavioral volume heuristics successfully detected 100% of evasion attacks in 144.0 ms, preventing 39.0% of operations.
3. **The Defense-in-Depth Architectural Cascade**:
   - Conclusively proved that Hybrid detection cannot replace Baseline behavioral monitoring.
   - Prescribed an integrated two-tier architecture:
     - **Tier 1 (Fast-Path Containment - Hybrid Engine)**: Latency 26 ms, 100% Precision, 0.0% FPR. Binds automated process termination.
     - **Tier 2 (Safety-Net Fallback - Baseline Behavioral Engine)**: Latency 85–144 ms, 100% Recall. Binds process suspension (`SIGSTOP`) and administrative review for evasive attacks.
4. **Lightweight User-Space Portability**:
   - Implemented an entire end-to-end detection, normalizer, and simulation pipeline in pure user space on macOS (Apple Silicon M1) consuming **< 38 MB of RAM** and **~25% of one CPU core**, demonstrating that effective behavioral protection does not require unstable kernel drivers.

