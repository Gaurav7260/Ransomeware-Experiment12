# Threats to Validity Audit

**Auditor**: Independent Scientific Methodology & Quality Team  
**Document**: `research_dossier/07_RESEARCH_VALIDITY/THREATS_TO_VALIDITY.md`  

---

## 1. Construct Validity (Do measurements reflect real-world concepts?)

1. **Synthetic Random Bytes vs. Real Cryptography**:
   - The simulator writes pseudo-random byte buffers (`random.getrandbits(8)`) rather than invoking AES/RSA cryptographic primitives.
   - *Threat*: Does synthetic writing accurately simulate ransomware?
   - *Mitigation & Defense*: From the filesystem's perspective, both operations execute identical POSIX `open()`, `write()`, and `close()` syscalls with high Shannon entropy ($\approx 7.8\text{ bits/byte}$). However, real malware may incur slightly higher CPU overhead during encryption key derivation.
2. **File Damage Metric**:
   - File damage is quantified as the count of user documents modified before containment.
   - *Threat*: In real attacks, partial encryption of a database header can destroy the entire file.
   - *Mitigation*: Our evaluation treats any modified file as 100% damaged, representing a conservative worst-case metric.

---

## 2. Internal Validity (Are observed effects genuinely caused by the independent variables?)

1. **Asynchronous Notification Delay**:
   - macOS `FSEvents` delivers batches with 10–25 ms of operating system latency.
   - *Mitigation*: The Event Normalizer debounces duplicate events within 50 ms. While this introduces minor artificial latency, it is uniform across all three detectors due to equi-telemetry.
2. **Inter-Trial Event Bleed**:
   - *Threat*: Could events from Trial 1 bleed into Trial 2?
   - *Mitigation*: The experiment runner implements an explicit 150 ms settling window (`time.sleep(0.15)`), resets detector history between runs, and validates that `len(captured_alerts) == 0` at the start of each trial.

---

## 3. External Validity (Can results be generalized?)

1. **Operating System and Architecture Specificity**:
   - Evaluated exclusively on macOS Darwin 24.x (Apple Silicon M1).
   - *Threat*: Filesystem event queues on Windows (NTFS minifilters) or Linux (inotify/eBPF) exhibit different buffering characteristics.
   - *Mitigation*: The mathematical principles of sliding-window correlation and canary lexicographical placement apply universally across filesystems, though specific timing thresholds must be re-calibrated.
2. **Adversary Adaptation & Evasion**:
   - Advanced adversaries who reverse-engineer CanarySentinel can identify canaries by inspecting file metadata, hardcoded filenames (`!00_corporate_passwords.xlsx`), or process names.
   - *Conclusion*: Static canary placement is vulnerable to targeted adversary adaptation; dynamic canary randomization is required in production.

---

## 4. Conclusion Validity (Are statistical conclusions justified?)

1. **Sample Size ($n = 10$ per scenario)**:
   - Evaluated across 10 repetitions per scenario. While sufficient for large effect sizes ($d = 1.35$), subtle differences in sub-millisecond ranges require larger sample sizes.
2. **Statistical Corrections Applied**:
   - Parametric $t$-tests were corroborated with non-parametric Mann-Whitney U tests due to non-normality ($p < 0.05$).
   - Categorical classification differences were validated via Fisher's exact test ($p < 0.0012$).

