# Major Research Claim Verification Matrix

**Document**: `research_dossier/13_EVIDENCE_AND_AUDIT/CLAIM_VERIFICATION_MATRIX.md`  

---

| Claim ID | Original Research Claim | Evidence Required | Evidence Found | Verification Result | Final Permitted Scientific Wording |
|:---:|:---|:---|:---|:---:|:---|
| **CLM-01** | "Hybrid eliminates false positives." | Benign trial records across all configurations. | Across 40 benign trials, Hybrid generated 0 alerts (FP=0, FPR=0.0%). | **VERIFIED** | "Under controlled experimental evaluations across 40 benign trials, Hybrid achieved a 0.0% False Positive Rate." |
| **CLM-02** | "Hybrid is universally superior to baseline." | F1-scores, recall, and evasion trials. | Baseline achieved 100% recall vs Hybrid 50% recall. Baseline F1 (0.80) > Hybrid F1 (0.67). | **REFUTED** | "Hybrid is superior in precision and false-positive suppression, but inferior in recall and F1 due to decoy evasion in Scenario S6." |
| **CLM-03** | "Canary assistance slashes detection latency." | Timestamps and latency logs. | Hybrid alerted in 26.1 ms vs Baseline 147.1 ms overall (84.9 ms on TP attacks). | **VERIFIED** | "Canary-assisted detection detects attacks significantly faster than baseline behavioral heuristics (p < 0.0001, Cohen d = 1.35)." |
| **CLM-04** | "System prevents 90.8% of damage in attacks." | Prevented operations across S5 and S6. | S5 prevented 90.83% of ops. S6 prevented 0.0% of ops. Mean across attacks is 45.42%. | **CONDITIONALLY VERIFIED** | "Hybrid prevented 90.83% of planned operations when canaries were struck (S5), but prevented 0.0% when canaries were evaded (S6), yielding an overall mean of 45.42% across attack trials." |
| **CLM-05** | "Response manager terminates malicious process." | Implementation code and process management. | Code sets internal software block flag `self._blocked = True`. Never terminates OS processes. | **RECONCILED DISCREPANCY** | "Response manager safely simulates containment by setting an internal software block flag that halts subsequent simulator operations, without terminating host OS processes." |
| **CLM-06** | "All 180 trials are fully completed and unique." | Database rows and IDs. | 180 unique scenario records in SQLite; zero duplicate UUIDs. | **VERIFIED** | "The experimental dataset comprises 180 fully executed and verified trials stored in SQLite." |
