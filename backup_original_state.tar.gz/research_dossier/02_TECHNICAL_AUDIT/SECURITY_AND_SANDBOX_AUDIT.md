# Technical Security and Sandbox Isolation Audit

**Auditor**: Independent Technical Security and Forensic Audit Team  
**Component**: Sandbox Isolation Boundary, Path Validation, and Containment  
**Primary Source**: [`canary_sentinel/core/sandbox.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py)  
**Document**: `research_dossier/02_TECHNICAL_AUDIT/SECURITY_AND_SANDBOX_AUDIT.md`  

---

## 1. Executive Security Assessment

The sandbox boundary implementation in `canary_sentinel/core/sandbox.py` was audited against common filesystem escape vulnerabilities, including path traversal, symlink spoofing, null-byte injection, and accidental system-root targeting. 

**Overall Verdict**: **ROBUST AND SECURE FOR LOCAL USER-SPACE DEVELOPMENT**.  
The module enforces strict containment guarantees that prevent any simulated activity from reading, modifying, or deleting files outside the dedicated `./sandbox` hierarchy.

---

## 2. Granular Vulnerability and Boundary Analysis

### A. Path Traversal Protection (`../` Directory Traversal)
- **Code Reference**: [`sandbox.py:90-104`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py#L90-L104)
- **Mechanism**:
  ```python
  path_obj = Path(target_path)
  if not path_obj.is_absolute():
      resolved = (self.sandbox_path / path_obj).resolve()
  else:
      resolved = path_obj.resolve()
  
  try:
      is_inside = resolved.is_relative_to(self.sandbox_path)
  except AttributeError:
      is_inside = str(resolved).startswith(str(self.sandbox_path))
  
  if not is_inside:
      raise SandboxSecurityError(f"Access denied: path '{target_path}' resolves outside sandbox")
  ```
- **Audit Findings**:
  - `Path.resolve()` resolves all symbolic links and canonicalizes `.` and `..` segments before containment verification.
  - `is_relative_to(self.sandbox_path)` strictly verifies that `self.sandbox_path` is a true ancestor of `resolved`.
  - Attempts to pass `../../etc/passwd` or `documents/../../sensitive.txt` resolve outside `./sandbox` and trigger immediate `SandboxSecurityError`.
- **Test Verification**: Verified by automated test [`tests/test_sandbox_safety.py:test_sandbox_rejects_directory_traversal`](file:///Users/gouravsingh/Downloads/CanarySentinel/tests/test_sandbox_safety.py#L25) (PASSED).

### B. Symlink Traversal and Escape Protection
- **Code Reference**: [`sandbox.py:106-114`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py#L106-L114)
- **Mechanism**:
  ```python
  if check_symlink and (target_path_str := str(target_path)):
      p = Path(target_path_str)
      if p.is_symlink():
          real_target = Path(os.path.realpath(p))
          if not real_target.is_relative_to(self.sandbox_path):
              raise SandboxSecurityError(f"Symlink breach attempt: '{p}' points outside sandbox")
  ```
- **Audit Findings**:
  - Both the symlink file itself and its real link destination (`os.path.realpath`) are verified to reside within the sandbox boundary.
  - Pointing a symlink inside the sandbox to `/etc` or `/Users` raises an immediate security error.
- **Test Verification**: Verified by automated test [`tests/test_sandbox_safety.py:test_sandbox_rejects_symlink_escape`](file:///Users/gouravsingh/Downloads/CanarySentinel/tests/test_sandbox_safety.py#L55) (PASSED).

### C. Null-Byte Injection Protection
- **Code Reference**: [`sandbox.py:86-88`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py#L86-L88)
- **Mechanism**:
  ```python
  if "\0" in str(target_path):
      raise SandboxSecurityError("Path contains null byte injection attempt")
  ```
- **Audit Findings**: Positively filters C-string termination attacks that could bypass path validation checks.
- **Test Verification**: Verified by automated test [`tests/test_sandbox_safety.py:test_sandbox_rejects_null_byte_injection`](file:///Users/gouravsingh/Downloads/CanarySentinel/tests/test_sandbox_safety.py#L48) (PASSED).

### D. System Directory Protection (Accidental Root Targeting)
- **Code Reference**: [`sandbox.py:17-66`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py#L17-L66)
- **Mechanism**:
  The `SandboxManager.__init__` maintains an explicit blacklist of sensitive operating system roots:
  - System Trees: `/bin`, `/sbin`, `/etc`, `/private/etc`, `/System`, `/Library`.
  - Exact Forbidden: `/`, `/usr`, `/var`, `/private`, `/private/var`, `/Users`, `str(Path.home())`.
  - If a user configures `sandbox_dir = "/"`, `"/Users"`, or `"/Library"`, `SandboxManager` refuses initialization with:
    `SandboxSecurityError("Refusing to use sensitive system or home directory as sandbox")`.
- **Test Verification**: Verified by automated test [`tests/test_sandbox_safety.py:test_refusal_to_use_system_root_as_sandbox`](file:///Users/gouravsingh/Downloads/CanarySentinel/tests/test_sandbox_safety.py#L80) (PASSED).

### E. Safe Reset Functionality
- **Code Reference**: [`sandbox.py:126-151`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/core/sandbox.py#L126-L151)
- **Mechanism**:
  `safe_reset()` purges the contents of `self.sandbox_path` by unlinking files and removing child directories, then immediately recreates standard subdirectories (`documents/`, `backup/`, `projects/`).
  It verifies that `self.sandbox_path.exists()` and that its parent path is strictly valid before executing `shutil.rmtree()`, preventing arbitrary deletion.

---

## 3. Simulator Confinement Verification

In [`canary_sentinel/simulation/simulator.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/simulation/simulator.py), every scenario implementation exclusively accesses paths validated via `self.sandbox.validate_path()`:
- `ScenarioHelper.create_user_files()`: Validates target paths before calling `open()`.
- `ScenarioHelper.generate_high_entropy_bytes()`: Generates synthetic random byte buffers (`random.getrandbits(8)`) rather than cryptographic encryption routines.
- `_run_canary_plus_rapid_bulk()` and `_run_rapid_bulk_without_canary()`: All file writes, renames, and deletions execute exclusively inside the validated sandbox directory.

**Conclusion**: The simulator is technically incapable of damaging or modifying any file outside `./sandbox`.

