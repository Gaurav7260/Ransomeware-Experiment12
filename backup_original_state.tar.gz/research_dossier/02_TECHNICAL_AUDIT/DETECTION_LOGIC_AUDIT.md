# Technical Audit of Detection Logic and Alert Engines

**Auditor**: Independent Technical Audit Team  
**Components**: `BaselineDetector`, `CanaryDetector`, `HybridDetector`, `RiskEngine`  
**Source Files**: 
- [`canary_sentinel/detection/baseline_detector.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/baseline_detector.py)
- [`canary_sentinel/detection/canary_detector.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/canary_detector.py)
- [`canary_sentinel/detection/hybrid_detector.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/hybrid_detector.py)
- [`canary_sentinel/detection/risk_engine.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/risk_engine.py)  
**Document**: `research_dossier/02_TECHNICAL_AUDIT/DETECTION_LOGIC_AUDIT.md`  

---

## 1. Equi-Telemetry Verification

An essential prerequisite for scientific validity is verifying whether all three detector configurations consume **equivalent normalized event streams**.

### Audit Finding:
- In [`canary_sentinel/experiments/runner.py:90-132`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/experiments/runner.py#L90-L132), the experiment runner attaches a callback to the shared `FilesystemMonitor`:
  ```python
  def event_handler(event: NormalizedEvent):
      decision = detector.process_event(event)
      if decision and decision.is_suspicious and decision.alert:
          captured_alerts.append(decision.alert)
          if self.response_manager:
              self.response_manager.evaluate_and_respond(decision.alert)
  ```
- All three detectors inherit from `BaseDetector` ([`canary_sentinel/detection/base.py`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/base.py)) and implement the uniform signature:
  `process_event(self, event: NormalizedEvent) -> Optional[DetectionDecision]`
- The event normalizer operates upstream of detector dispatch. Therefore, the sequence, timing, and attribute payload of `NormalizedEvent` objects are **100% identical** across all three configurations.

---

## 2. Granular Engine-by-Engine Rule Audit

### A. Configuration A: Baseline Detector
- **Code Reference**: [`baseline_detector.py:11-100`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/baseline_detector.py#L11-L100)
- **Threshold Parameters**:
  - `burst_window_seconds`: Default `2.0s`
  - `burst_count_threshold`: Default `8` operations
  - `entropy_threshold`: Default `7.2` bits/byte
  - `mass_rename_threshold`: Default `4` operations
  - `base_risk_score`: Default `50`
- **Rule Logic**:
  1. **Rapid Operation Burst**: If total operations in window $\ge 8$ and unique targets $\ge 3$, adds $+45$ risk score.
  2. **High-Entropy Modification**: If modified/created files exhibit entropy $\ge 7.2$, adds $+35$ risk score.
  3. **Mass Renaming**: If rename operations in window $\ge 4$, adds $+30$ risk score.
  4. **Suspicious Extension**: If file extension matches known ransomware extensions (`.locked`, `.crypto`, etc.), adds $+35$ risk score.
  - Fires an alert if cumulative `risk_score >= base_risk_score` (50).
- **False-Positive Analysis**:
  In Scenario B4 (`Bulk Renaming`), 6 harmless files are renamed within 0.3s. This satisfies Rule 3 ($\ge 4$ renames, $+30$) and Rule 1 ($\ge 6$ operations across $\ge 3$ files), pushing risk score to $75 \ge 50$. This triggers an alert, resulting in **10 false positives out of 10 trials** (FPR = 25.0%).
- **False-Negative Analysis**:
  Baseline has **zero false negatives** (Recall = 100%). It detected both Scenario S5 (Canary + Rapid Bulk) and Scenario S6 (Rapid Bulk Without Canary) because the rapid modification bursts exceeded volume thresholds regardless of file names.

### B. Configuration B: Canary-Only Detector
- **Code Reference**: [`canary_detector.py:11-63`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/canary_detector.py#L11-L63)
- **Threshold Parameters**:
  - `monitored_events`: `{"MODIFY", "DELETE", "MOVE"}`
  - `base_risk_score`: Default `85`
- **Rule Logic**:
  - Evaluates `if not event.is_canary: return None`.
  - If target path matches any of the 8 registered canary files and event type is in `monitored_events`, fires an immediate alert with `risk_score = 85` (HIGH/CRITICAL severity) and `confidence = 0.85`.
- **False-Positive Analysis**:
  In Scenario B3 (`canary_touch_benign`), an indexer or user innocently touches/reads `000_canary.txt`. Because Canary-Only has zero contextual corroboration, it triggers an alert immediately, resulting in **10 false positives out of 10 trials** (FPR = 25.0%).
- **False-Negative Analysis**:
  In Scenario S6 (`rapid_bulk_without_canary`), the attacker encrypts 10 user documents while deliberately avoiding canary files. Because `event.is_canary` is `False` for all operations, Canary-Only remains completely silent, resulting in **10 false negatives out of 10 trials** (Recall = 50.0%).

### C. Configuration C: Hybrid Detector
- **Code Reference**: [`hybrid_detector.py:11-139`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/detection/hybrid_detector.py#L11-L139)
- **Threshold Parameters**:
  - `observation_window_seconds`: Default `3.0s` (pruning window $2 \times 3.0 = 6.0\text{s}$)
  - `burst_velocity_threshold`: Default `3.0` ops/sec
  - `entropy_threshold`: Default `7.2` bits/byte
  - `base_risk_score`: Default `90`
- **Rule Logic**:
  - When a canary file is modified/moved/deleted, it buffers `self._pending_canary_event = event`.
  - It queries surrounding non-canary events within `[t_canary - 3.0s, t_canary + 3.0s]`.
  - Generates an alert if and only if at least one corroboration criterion is met:
    1. High-entropy modification ($\ge 7.2$) on $\ge 2$ companion user files.
    2. Operation velocity $\ge 3.0\text{ ops/sec}$ across $\ge 4$ events and $\ge 3$ companion files.
    3. Mass file churn sequence ($\ge 6$ operations across $\ge 4$ files).
- **False-Positive Analysis**:
  In Scenario B3, `000_canary.txt` is touched, but zero companion files are modified. Because none of the 3 corroboration criteria are met, `self._pending_canary_event` expires without alerting. Hybrid achieved **0 false positives across all 40 benign trials** (FPR = 0.0%).
- **False-Negative Analysis**:
  In Scenario S6, because malware avoids canaries entirely, `self._pending_canary_event` is never set. As a result, Hybrid never evaluates context and emits no alert, suffering **10 false negatives out of 10 trials** (Recall = 50.0%).

---

## 3. Detection Latency Calculation Audit

In [`canary_sentinel/experiments/runner.py:154-157`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/experiments/runner.py#L154-L157):
```python
if detected:
    first_alert = captured_alerts[0]
    alert_id = first_alert.alert_id
    latency_ms = max(1.0, (first_alert.timestamp - trial_start_time) * 1000.0)
```
- **Audit Verification**:
  - Latency is calculated as: $t_{\text{alert}} - t_{\text{trial\_start}}$.
  - In undetected trials (`detected == 0`), `detection_latency_ms` is stored as `None` (`NULL` in SQLite).
  - This confirms that undetected attacks are **never falsely recorded as 0.0 ms**, maintaining mathematical integrity.

