# Master Discrepancy Register and Scientific Audit Log

**Auditor**: Multidisciplinary Forensic Audit Team  
**Scope**: Complete investigation and resolution of all technical, mathematical, and architectural discrepancies discovered in prior CanarySentinel documentation.  
**Document**: `research_dossier/06_DISCREPANCY_REGISTER/DISCREPANCY_REGISTER.md`  

---

## 1. Executive Discrepancy Summary

The independent audit investigated seven specific discrepancies. Every issue has been audited against raw database records, Python source code, and mathematical principles.

---

## 2. Comprehensive Discrepancy Matrix

| Issue ID | Architectural Area | Previously Reported / Claimed | Independently Verified Finding | Empirical Evidence | Required Correction | Audit Status |
|:---:|:---|:---|:---|:---|:---|:---:|
| **DISC-01** | **Response Mechanism** | Claims system terminates processes via POSIX `SIGTERM`/`SIGKILL` signals to target PID. | System uses an **internal simulator block flag** (`self._blocked = True`). Never calls `os.kill()` or POSIX signal APIs. | [`simulated/response_manager.py:68`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/simulation/response_manager.py#L68), [`simulator.py:156`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/simulation/simulator.py#L156) | Correct all documentation to state that containment is simulated via internal thread-safe blocking flags, ensuring 100% host OS safety. | **RESOLVED** |
| **DISC-02** | **Baseline FP Scenario Attribution** | Claims Baseline false alarms occurred during Scenario B2 (`benign_bulk_docs` / `Bulk Copying`). | In raw SQLite, `Bulk Copying` had 0 false alarms. The actual scenario triggering 10 Baseline false alarms was **Scenario B4 (`Bulk Renaming`)**. | SQLite query: `SELECT * FROM scenarios WHERE scenario_name='Bulk Renaming';` (10 alerts) | Re-attribute Baseline false alarms strictly to `Bulk Renaming` due to mass-rename threshold ($\ge 4$ renames). | **RESOLVED** |
| **DISC-03** | **Operations Prevented Aggregation** | Hybrid reports 45.42% ops prevented overall, but Scenario S5 reports 90.83%. | Both numbers are mathematically correct under different aggregation methods. 45.42% is the **unweighted arithmetic mean of trial ratios**: $(90.83\% \times 10 + 0.0\% \times 10) / 20$. Ratio of total sums is 49.55%. | Formula: $\frac{\sum \text{Prev}}{\sum \text{Plan}} = \frac{109}{220} = 49.55\%$; $\text{Mean}(\text{Ratios}) = 45.42\%$. | Disclose both aggregation formulas and explain why unweighted mean of ratios was chosen. | **RESOLVED** |
| **DISC-04** | **System Metrics Attribution** | CPU (~25.9%) and RAM (~37.2 MB) described as isolated detector-specific measurements. | Metrics measure the **host Python test runner process** (`psutil.Process(os.getpid())`) during the trial. They reflect the combined engine overhead. | [`canary_sentinel/experiments/runner.py:136-148`](file:///Users/gouravsingh/Downloads/CanarySentinel/canary_sentinel/experiments/runner.py#L136-L148) | Clarify that system metrics capture host application runtime footprint rather than isolated detector thread CPU. | **RESOLVED** |
| **DISC-05** | **Confidence Interval Methodology** | Latency 95% CIs reported as Baseline $\pm 36.5\text{ ms}$, Canary $\pm 3.4\text{ ms}$, Hybrid $\pm 5.2\text{ ms}$. | Audited formulas show Student's $t$ with $k-1$ degrees of freedom: Baseline ($k=30, t=2.045, s=102.1$) yields $\pm 38.1\text{ ms}$. Normal $z$ ($z=1.96$) yields $\pm 36.5\text{ ms}$. | Python `scipy.stats.t.ppf(0.975, df=k-1)` | Explicitly document whether normal $z$ ($\pm 36.5\text{ ms}$) or Student's $t$ ($\pm 38.1\text{ ms}$) is reported. | **RESOLVED** |
| **DISC-06** | **Latency Denominator Handling** | Aggregated Baseline latency reported as 147.1 ms. | 147.05 ms includes 10 false positive alerts from Bulk Renaming (mean 271.3 ms). When evaluated across **True Positives only ($k=20$)**, Baseline mean latency is **84.92 ms**! | SQLite `scenarios` table: S5 (25.8 ms) + S6 (144.0 ms) | Report both the all-alerts latency (147.05 ms) and the true-positives-only latency (84.92 ms). | **RESOLVED** |
| **DISC-07** | **Universal Superiority Hypothesis** | Early completion summaries claimed Hybrid was universally superior. | Baseline achieved superior Recall (100% vs 50%) and higher overall F1-score (0.80 vs 0.67). Hybrid is superior in Precision (100%) and FPR (0%). | `research_dossier/05_METRICS_AND_STATISTICS/DETECTOR_METRICS.csv` | **Reject Hypothesis H3**. Prescribe a two-tier defense-in-depth model combining Hybrid fast-path with Baseline fallback. | **RESOLVED** |

---

## 3. Detailed Technical Resolutions

### Deep Dive on DISC-01 (Response Mechanism):
- **Finding**: In `canary_sentinel/simulation/response_manager.py:68-76`, containment is executed via:
  ```python
  self._blocked = True
  self._block_time = time.time()
  self._triggering_alert = alert
  alert.response_status = "BLOCKED"
  ```
  And in `canary_sentinel/simulation/simulator.py`:
  ```python
  if self.response_manager.is_blocked():
      break
  ```
- **Audit Conclusion**: This design is an **internal software block flag**. It completely prevents any accidental harm to host processes, making it ideal for safe educational and research demonstrations. Previous documentation describing POSIX `SIGTERM`/`SIGKILL` signals was inaccurate and has been corrected throughout this dossier.

### Deep Dive on DISC-06 (Baseline Latency Breakdown):
- In `Bulk Renaming` (Scenario B4), Baseline alerted in **271.30 ms** (10 trials).
- In `Canary Touch + Rapid Bulk` (Scenario S5), Baseline alerted in **25.80 ms** (10 trials).
- In `Rapid Bulk Without Canary` (Scenario S6), Baseline alerted in **144.05 ms** (10 trials).
- The pooled average across all 30 alerts is:
  $$\frac{271.30 \times 10 + 25.80 \times 10 + 144.05 \times 10}{30} = \mathbf{147.05\text{ ms}}$$
- If we restrict latency strictly to genuine attacks (TP trials only, $k = 20$):
  $$\frac{25.80 \times 10 + 144.05 \times 10}{20} = \frac{1,698.43}{20} = \mathbf{84.92\text{ ms}}$$
- Both numbers are scientifically valuable: 147.05 ms represents the mean time to raise any alert, while 84.92 ms represents the mean time to intercept real ransomware.

