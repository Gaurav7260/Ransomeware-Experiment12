# Standardized Experiment Execution Protocol

**Document**: `research_dossier/09_REPRODUCIBILITY/EXPERIMENT_EXECUTION_PROTOCOL.md`  

---

## Protocol Steps for Each Batch Run:
1. **Sandbox Reset**: Purge all files in `./sandbox` using `SandboxManager.safe_reset()`.
2. **Canary Deployment**: Invoke `CanaryManager.deploy_canaries()`. Verify 8 active canaries in SQLite.
3. **Monitor Start**: Initialize and start `FilesystemMonitor` on `./sandbox`.
4. **Detector Attachment**: Instantiate target detector (`BaselineDetector`, `CanaryDetector`, or `HybridDetector`).
5. **Workload Execution**: Trigger target scenario function via `ActivitySimulator`.
6. **Telemetry Ingestion**: Ingest and debounce normalized events.
7. **Containment Evaluation**: If alert fires, record latency and activate simulator block flag.
8. **Settling Window**: Sleep 150 ms to ensure all filesystem events are drained from OS queue.
9. **Persistence**: Write scenario run row to SQLite `scenarios` table and CPU/RAM to `system_metrics`.
10. **Loop Iteration**: Repeat steps 1–9 across all 6 scenarios for 10 repetitions per configuration ($N = 180$).
