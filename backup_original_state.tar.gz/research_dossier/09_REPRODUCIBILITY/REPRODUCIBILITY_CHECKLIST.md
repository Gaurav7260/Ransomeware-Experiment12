# Scientific Reproducibility Verification Checklist

| Checklist Item | Requirement | Verification Method | Status |
|:---|:---|:---|:---:|
| **Code Availability** | All modules available in repository | `ls canary_sentinel/` | **PASS** |
| **Clean Install** | Installs cleanly into empty `.venv` | `pip install -r requirements.txt` | **PASS** |
| **Deterministic Data** | 180 trials stored with unique IDs | SQLite query `SELECT COUNT(DISTINCT scenario_id)` | **PASS** |
| **All Tests Pass** | 45 / 45 unit and integration tests pass | `pytest -v` | **PASS** |
| **Metrics Reproducible** | Recalculated values match published tables | `MetricsCalculator.generate_comparison_report()` | **PASS** |
| **Dashboard Operable** | Web UI loads on port 8501 without crashes | Browser access `http://localhost:8501` | **PASS** |
| **Export Integrity** | CSV and ZIP exports generate complete files | Inspection of exported archives | **PASS** |
