# Exact Operating Environment Specification

**Document**: `research_dossier/09_REPRODUCIBILITY/ENVIRONMENT_SPECIFICATION.md`  

---

## 1. Host Hardware Environment
- **Processor**: Apple Silicon M1 (8 cores: 4 performance + 4 efficiency)
- **Memory**: 8 GB Unified Memory (LPDDR4X)
- **Architecture**: `arm64` / 64-bit
- **Storage**: Apple APFS Solid-State Drive

## 2. Software & Operating System
- **OS**: macOS Sequoia 15.3 (Darwin Kernel Version 24.3.0)
- **Python Version**: Python 3.12.9 (and verified on 3.14.0)
- **Database Engine**: SQLite 3.46.0

## 3. Pinned Dependency Manifest (`requirements.txt`)
- `watchdog==6.0.0` (Darwin FSEvents listener)
- `psutil==7.0.0` (Host process resource telemetry)
- `streamlit==1.43.0` (Interactive dashboard)
- `pandas==2.2.3` (Dataframe manipulation)
- `pytest==8.3.5` (Automated testing framework)
