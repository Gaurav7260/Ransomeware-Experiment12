# CanarySentinel — Master Experiment Reproducibility Guide

**Auditor**: Scientific Reproducibility & Data Integrity Team  
**Document**: `research_dossier/09_REPRODUCIBILITY/REPRODUCIBILITY_GUIDE.md`  

---

## 1. Quick-Start Replication Commands

```bash
# Clone and enter directory
cd CanarySentinel

# Set up Python virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run full automated test suite (45 passing tests)
pytest -v

# Run the 180-trial benchmark suite via CLI runner
python3 run_sentinel.py --benchmark --repetitions 10

# Launch interactive Streamlit dashboard
streamlit run canary_sentinel/dashboard/app.py
```

---

## 2. Directory and Sandbox Preparation
Before running experiments, ensure the sandbox directory exists and is initialized:
```bash
mkdir -p sandbox/documents sandbox/backup sandbox/projects
```
The application autonomously validates and provisions canary decoy files upon boot.
