# CanarySentinel — Final Independent Research & Engineering Audit Report

**Audit Date**: November 2026  
**Auditor**: Independent Software Architect & Security Engineering Review  
**Platform**: macOS Apple Silicon M1 (ARM64), Python 3.14, 8 GB RAM  
**Repository**: `/Users/gouravsingh/Downloads/CanarySentinel`  
**Database**: `canary_sentinel.db` (SQLite 3 with Write-Ahead Logging)  
**Status**: ✅ AUDIT PASSED WITH ALL VERIFIED CORRECTIONS  

---

## 1. Executive Audit Summary

This independent audit conducted a comprehensive, evidence-based inspection of CanarySentinel across its database records, mathematical models, statistical assertions, test coverage, and documentation.

### Core Audit Outcomes:
1. **Database & Trial Integrity**: Verified exactly **180 unique, non-null, completed experiment runs** in `canary_sentinel.db` (60 trials per detector; exactly 10 repetitions across all 6 scenarios).
2. **Mathematical Consistency**: Independently recalculated all confusion matrices, precision, recall, F1-scores, false positive rates, latencies, and file damage metrics directly from trial records. All values match the dashboard and exported CSVs.
3. **Discrepancy Investigation & Corrections**:
   - **Operations Prevented Discrepancy**: Explained and resolved the apparent divergence between Hybrid's overall prevented operations ($45.4\%$) and its Scenario S5 performance ($90.8\%$). The overall metric reflects the combined cohort of S5 ($90.8\%$ prevented) and S6 ($0.0\%$ prevented due to decoy evasion).
   - **Shared CPU & Memory Overhead**: Identified that `MetricsCalculator` was originally querying global system metrics without filtering by scenario ID. Corrected the calculation to report detector-specific expenditures: Baseline ($25.93\%$), Canary-Only ($26.56\%$), and Hybrid ($25.40\%$).
   - **95% Confidence Interval Methodology**: Documented the normal approximation method ($z^* = 1.96$) and small-sample Student's $t$ correction ($t_9 = 2.262$ for Hybrid).
   - **Nuanced Verdict**: Corrected prior claims of "universal superiority" to reflect that while Hybrid achieves perfect precision ($100.0\%$) and zero false alarms ($0.0\%$), Baseline achieves higher overall recall ($100.0\%$ vs. $50.0\%$) and F1-score ($0.80$ vs. $0.67$) on attacks that evade decoys.
4. **Technical Verification**: Re-executed the complete automated test suite (**45/45 passed** in 4.58s) and verified sandbox containment, CLI commands, CSV exports, and the live Streamlit dashboard on port 8501.

---

## 2. Experimental Data Audit (Section A)

### Database Query Commands Executed:
```sql
SELECT COUNT(*) FROM scenarios;       -- Returned: 180
SELECT COUNT(*) FROM events;          -- Returned: 1,691
SELECT COUNT(*) FROM alerts;          -- Returned: 60
SELECT COUNT(*) FROM canaries;        -- Returned: 8
SELECT COUNT(*) FROM system_metrics;  -- Returned: 180
SELECT COUNT(DISTINCT scenario_id) FROM scenarios; -- Returned: 180 (100% Unique)
```

### Breakdown by Detector & Scenario ($N = 180$):

| Scenario ID & Name | Ground Truth | Baseline (Config A) | Canary-Only (Config B) | Hybrid (Config C) | Total Completed Trials |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **S1: Normal File Editing** | Benign | 10 | 10 | 10 | **30** |
| **S2: Bulk Copying** | Benign | 10 | 10 | 10 | **30** |
| **S3: Bulk Renaming** | Benign | 10 | 10 | 10 | **30** |
| **S4: Canary Touch Benign** | Benign | 10 | 10 | 10 | **30** |
| **S5: Canary + Rapid Bulk** | Suspicious | 10 | 10 | 10 | **30** |
| **S6: Rapid Bulk Without Canary** | Suspicious | 10 | 10 | 10 | **30** |
| **Total Completed Trials** | — | **60** | **60** | **60** | **180** |

- **Incomplete / Failed Trials**: **0**. Every record contains valid start/end timestamps, planned/executed operations, and boolean detection flags.
- **Duplicate Run IDs**: **0**. All 180 `scenario_id` strings are distinct UUID-tagged strings.

---

## 3. Mathematical Consistency & Metric Recalculation (Section B)

All metrics were independently recalculated directly from raw SQL rows using Python (`sqlite3` and `pandas`):

### Independent Confusion Matrix Recalculation:
- **Baseline (Behavior-Only)**:
  - $\text{TP} = 20$ (10 S5 + 10 S6)
  - $\text{FP} = 10$ (10 S3 bulk renaming)
  - $\text{TN} = 30$ (10 S1 + 10 S2 + 10 S4)
  - $\text{FN} = 0$
- **Canary-Only (Decoy Tripwire)**:
  - $\text{TP} = 10$ (10 S5)
  - $\text{FP} = 10$ (10 S4 canary touch benign)
  - $\text{TN} = 30$ (10 S1 + 10 S2 + 10 S3)
  - $\text{FN} = 10$ (10 S6 missed attack)
- **Hybrid (Correlated Context)**:
  - $\text{TP} = 10$ (10 S5)
  - $\text{FP} = 0$ (Zero false alarms across S1, S2, S3, S4!)
  - $\text{TN} = 40$ (10 S1 + 10 S2 + 10 S3 + 10 S4)
  - $\text{FN} = 10$ (10 S6 missed attack)

### Mathematical Formula Verification:

$$\text{Precision} = \frac{\text{TP}}{\text{TP} + \text{FP}}, \quad \text{Recall} = \frac{\text{TP}}{\text{TP} + \text{FN}}, \quad F_1 = \frac{2 \cdot P \cdot R}{P + R}, \quad \text{FPR} = \frac{\text{FP}}{\text{FP} + \text{TN}}$$

| Metric | Independently Calculated Value | Dashboard / Report Value | Discrepancy |
| :--- | :---: | :---: | :---: |
| **Baseline Precision** | $20 / 30 = 66.67\%$ | $66.67\%$ | None (Exact) |
| **Baseline Recall** | $20 / 20 = 100.00\%$ | $100.00\%$ | None (Exact) |
| **Baseline F1-Score** | $0.8000$ | $0.80$ | None (Exact) |
| **Baseline FPR** | $10 / 40 = 25.00\%$ | $25.00\%$ | None (Exact) |
| **Canary-Only Precision** | $10 / 20 = 50.00\%$ | $50.00\%$ | None (Exact) |
| **Canary-Only Recall** | $10 / 20 = 50.00\%$ | $50.00\%$ | None (Exact) |
| **Canary-Only F1-Score** | $0.5000$ | $0.50$ | None (Exact) |
| **Canary-Only FPR** | $10 / 40 = 25.00\%$ | $25.00\%$ | None (Exact) |
| **Hybrid Precision** | $10 / 10 = 100.00\%$ | $100.00\%$ | None (Exact) |
| **Hybrid Recall** | $10 / 20 = 50.00\%$ | $50.00\%$ | None (Exact) |
| **Hybrid F1-Score** | $0.6667$ | $0.67$ | None (Exact) |
| **Hybrid FPR** | $0 / 40 = 0.00\%$ | $0.00\%$ | None (Exact) |
| **Baseline Mean Latency** | $147.05$ ms | $147.1$ ms | None (Rounding) |
| **Baseline Median Latency** | $141.96$ ms | $142.0$ ms | None (Rounding) |
| **Canary-Only Mean Latency** | $18.88$ ms | $18.9$ ms | None (Rounding) |
| **Canary-Only Median Latency** | $16.17$ ms | $16.2$ ms | None (Rounding) |
| **Hybrid Mean Latency** | $26.10$ ms | $26.1$ ms | None (Rounding) |
| **Hybrid Median Latency** | $25.78$ ms | $25.8$ ms | None (Rounding) |

---

## 4. Discrepancy Investigations & Resolutions (Section C)

### 1. Operations Prevented Discrepancy ($45.4\%$ vs. $90.8\%$)
- **Investigation**: The overall metric `mean_ops_prevented_pct` is computed exclusively across the **suspicious scenario cohort** ($N = 20$ trials, comprising 10 trials of S5 and 10 trials of S6).
- **Mathematical Derivation**:
  - In Scenario S5 (`canary_plus_rapid_bulk`), Hybrid triggered containment within 26.1 ms, neutralizing 10.9 of 12 planned operations: $\frac{10.9}{12.0} \times 100\% = \mathbf{90.83\%}$.
  - In Scenario S6 (`rapid_bulk_without_canary`), the attack evaded all canaries. Hybrid never triggered; all 10 planned operations executed: $\frac{0}{10.0} \times 100\% = \mathbf{0.00\%}$.
  - Weighted average across all 20 suspicious trials:
    $$\text{Mean Prevented Ops} = \frac{10 \times 90.83\% + 10 \times 0.00\%}{20} = \mathbf{45.42\%}$$
- **Resolution**: Fully documented in `RESEARCH_RESULTS.md`, `RESEARCH_SUMMARY.md`, and `ACADEMIC_REPORT.md` so readers understand that $45.4\%$ represents the combined suspicious cohort, while $90.8\%$ represents attacks that hit canary files.

### 2. CPU and Memory Footprint Attribution
- **Investigation**: Previous reports displayed identical values ($26.0\%$ CPU and $37.4$ MB RAM) across Baseline, Canary-Only, and Hybrid. Inspection of `canary_sentinel/experiments/metrics.py` revealed that `sys_metrics = self.db.get_system_metrics()` was querying all table rows globally without filtering by detector scenario IDs.
- **Fix Implemented**: Updated `metrics.py` to filter system metrics strictly by `{s.scenario_id for s in scenarios}` belonging to each detector.
- **Corrected Detector-Specific Metrics**:
  - **Baseline**: $25.93\%$ CPU, $37.18$ MB RAM
  - **Canary-Only**: $26.56\%$ CPU, $37.35$ MB RAM
  - **Hybrid**: $25.40\%$ CPU, $37.70$ MB RAM
- **Finding**: In-memory contextual correlation adds negligible resource overhead compared to the baseline Watchdog observer.

### 3. 95% Confidence Interval Verification
- **Statistical Method Used**: Standard large-sample normal approximation:
  $$\text{CI}_{95} = \pm z^* \cdot \frac{s}{\sqrt{n}}, \quad z^* = 1.96$$
  - Baseline ($n=30$): $s = 102.07$ ms $\implies \text{CI}_{95} = \pm 1.96 \cdot \frac{102.07}{\sqrt{30}} = \pm \mathbf{36.52}$ ms.
  - Canary-Only ($n=20$): $s = 7.71$ ms $\implies \text{CI}_{95} = \pm 1.96 \cdot \frac{7.71}{\sqrt{20}} = \pm \mathbf{3.38}$ ms.
  - Hybrid ($n=10$): $s = 8.43$ ms $\implies \text{CI}_{95} = \pm 1.96 \cdot \frac{8.43}{\sqrt{10}} = \pm \mathbf{5.23}$ ms.
- **Small-Sample Note Disclosed**: For Hybrid ($n=10$), Student's $t$-distribution ($t_{9, 0.975} = 2.2622$) yields a conservative confidence interval of $\pm \mathbf{6.03}$ ms ($\text{CI}_{95} = [20.07, 32.13]$ ms).

### 4. Hybrid 100% Precision and 50% Recall Representation
- Confirmed that Hybrid's $100.0\%$ Precision and $50.0\%$ Recall are accurately represented. Hybrid achieves $100\%$ precision because it produces zero false alarms ($0/40$). However, because it relies on decoy interaction, it achieves only $50\%$ recall on the benchmark suite because it misses attacks that completely avoid canaries (Scenario S6).

### 5. Research Verdict & Defense-in-Depth Nuance
- Corrected prior verdict strings that claimed Hybrid possessed a "superior F1-score". Baseline achieved a higher F1-score ($0.80$ vs. $0.67$) due to its $100\%$ recall. The verdict now clearly states that Hybrid is superior in **Precision** ($100\%$ vs. $66.7\%$) and **False Positive Rate** ($0\%$ vs. $25\%$), and emphasizes that CanarySentinel demonstrates the necessity of deploying Hybrid detection alongside Baseline behavioral tracking as a defense-in-depth architecture.

---

## 5. Reproducibility Audit (Section D)

| Verification Item | Audit Procedure | Result |
| :--- | :--- | :---: |
| **Unique Run IDs** | Verified `SELECT COUNT(DISTINCT scenario_id) == COUNT(*)` in SQLite. | ✅ 180 / 180 Unique |
| **Monotonic Timestamps** | Verified timestamps increase monotonically across trials from $1793604508.4$ to $1793604668.9$. | ✅ Verified (Span: 160.5s) |
| **Equivalent Event Streams** | Checked event counts per scenario across all detectors: `Bulk Copying` (12.0 events each), `Normal File Editing` (5.0 events each), `Canary Touch + Rapid Bulk` (17.0 events each). | ✅ Identical Ground Truth Streams |
| **Fixed Thresholds** | Verified that detection thresholds (Baseline burst $\ge 6$/2s, entropy $\ge 7.0$; Hybrid window 3.0s, entropy $\ge 6.8$) were fixed in `config.json` before benchmarking. | ✅ Fixed Before Evaluation |
| **No Old Trial Reuse** | Verified that `python run_sentinel.py reset --all` cleanly wiped all tables before the 180-trial run. | ✅ Zero Stale Trial Reuse |

---

## 6. Technical Verification Audit (Section E)

### 1. Test Suite Re-Execution
Re-executed the complete automated test suite via `pytest -v`:
- **Results**: 45 passed, 0 failed, 0 skipped in 4.58 seconds.
- Test modules verified:
  - `test_sandbox_safety.py` (9 tests)
  - `test_canary_manager.py` (5 tests)
  - `test_detectors.py` (6 tests)
  - `test_risk_engine.py` (5 tests)
  - `test_scenarios.py` (5 tests)
  - `test_metrics.py` (4 tests)
  - `test_database.py` (4 tests)
  - `test_monitor_normalizer.py` (4 tests)
  - `test_integration_flow.py` (1 test)
  - `test_cli_and_exports.py` (1 test)
  - `test_performance.py` (1 test)

### 2. Sandbox Security Checks
- Submitting path traversal sequences (`../../`, `../`, nested relative paths) raises `SandboxSecurityError`.
- External absolute paths (`/tmp`, `/etc/passwd`, `/Users/Shared`) are strictly blocked.
- Null-byte path injection strings (`file.txt\x00.pdf`) are intercepted.
- External symlinks outside `./sandbox` are rejected via `Path.resolve()`.
- System roots (`/`, `/bin`, `/sbin`, `/etc`, `/System`, `/Library`, `/Users`, `~`) cannot be used as sandboxes.

### 3. Response & Simulator Safety
- In-memory atomic cancellation token (`is_blocked = True`) verified; zero OS processes terminated (`os.kill` is never called).
- Activity simulator operates strictly on generated text/random bytes inside `./sandbox`.

### 4. CLI Commands & CSV Data Export
- Verified `python run_sentinel.py status`: reports 8 active canaries, 1691 events, 60 alerts, 180 trials.
- Verified `python run_sentinel.py export`: outputs valid CSV files to `./exports/` (`events.csv`, `alerts.csv`, `trials.csv`, `metrics_summary.csv`, `scenario_breakdown.csv`).
- Verified `python run_sentinel.py report`: generates updated `RESEARCH_SUMMARY.md`.

### 5. Streamlit Dashboard
- Running live as a daemon on port 8501 (`task-537`).
- Verified defensive attribute access (`getattr(m, "std_latency_ms", 0.0)`) preventing any UI `AttributeError`.

---

## 7. Remaining Limitations

1. **User-Space File Monitoring**: Relies on user-space Watchdog/FSEvents; kernel rootkits or direct disk block modifications could bypass user-space notification queues.
2. **Synthetic Ransomware Workload**: Evaluates high-entropy random byte overwrites rather than live asymmetric-symmetric cryptographic handshakes.
3. **Decoy Placement Heuristics**: Alphabetical naming conventions (`!00_`, `aaa_`) are static; targeted ransomware designed to bypass known honeypots could evade detection without Baseline behavior tracking.

---

## 8. Final GitHub Readiness Assessment

- **Clean Repository Structure**: Modular architecture separating `core`, `canary`, `monitoring`, `detection`, `simulation`, `storage`, `experiments`, and `dashboard`.
- **Git Hygiene**: Strict `.gitignore` prevents committing `.venv/`, `.pytest_cache/`, `sandbox/`, `exports/`, `*.db`, `*.log`, `.env`, and OS/IDE metadata.
- **Dependencies**: Minimal, standard `requirements.txt` (`watchdog`, `psutil`, `streamlit`, `pandas`, `pytest`).
- **Complete Academic Deliverables**: All 14 markdown documents (`ACADEMIC_REPORT.md`, `RESEARCH_RESULTS.md`, `FINAL_AUDIT_REPORT.md`, `TESTING_REPORT.md`, `RESEARCH_GAP_AND_NOVELTY.md`, `PRESENTATION_OUTLINE.md`, `CONTRIBUTIONS.md`, `ARCHITECTURE.md`, `EXPERIMENT_METHODOLOGY.md`, `LITERATURE_REVIEW.md`, `PROJECT_SCOPE.md`, `USER_GUIDE.md`, `RESEARCH_LIMITATIONS.md`, `README.md`) are accurate and fully reconciled.

**Audit Certification**: The CanarySentinel project is technically complete, mathematically verified, experimentally reproducible, and ready for academic capstone presentation and GitHub publication.

