# CanarySentinel — Final Project Audit Report

**Report Generation Date:** 2026-11-03 18:13:52  
**Auditor / Specialist:** Antigravity Research & Independent Engineering Audit Team  
**Project Classification:** Research Prototype — Endpoint Ransomware Behavioral Detection & Deception System  
**Overall Status:** AUDIT COMPLETE — FULLY OPERATIONAL & RECONCILED  

---

## 1. Executive Status
CanarySentinel is an endpoint security research prototype that investigates whether combining canary-file interactions with contextual filesystem behavior improves ransomware detection quality and reduces simulated file damage compared with canary-only and behavior-only detection.

- **Automated Test Suite:** 56 passing automated unit, integration, boundary, and security tests (zero failures).
- **Interactive Dashboard:** 10 functional modules including live interactive Test Lab and Reports Centre.
- **Evidence Provenance:** Successfully identified and reconciled the 180-trial benchmark dataset with the 77-trial operational database.

---

## 2. Completed vs Incomplete Features Matrix

| Feature Module | Implementation Status | Verification Details |
|---|:---:|---|
| **Canary Decoy Manager** | ✅ COMPLETED | Deploys 8 multi-extension decoy files across directories with hash tracking. |
| **Filesystem Monitor** | ✅ COMPLETED | Operating-system event capture using `watchdog` notification pipeline. |
| **Event Normalizer & Debouncer** | ✅ COMPLETED | Normalizes events, calculates Shannon byte entropy, and debounces duplicate notifications. |
| **Baseline Behavioral Detector** | ✅ COMPLETED | Volume/velocity bursts (\ge 6 ops/2s), mass renames (\ge 4 ops/2s), and high-entropy detection. |
| **Canary-Only Decoy Detector** | ✅ COMPLETED | Zero-tolerance tripwire triggering on any canary decoy access/modification. |
| **Hybrid Corroborated Detector** | ✅ COMPLETED | Dual-predicate corroboration requiring canary breach + companion user file churn (\Delta t \le 3.0s). |
| **Detection Explanation Engine** | ✅ COMPLETED | Rule-based engine providing plain-English breakdowns of evidence, inferences, and actions. |
| **Simulated Response Manager** | ✅ COMPLETED | Thread-safe cooperative containment (`is_blocked()`). Halts internal simulated attack loop without terminating OS processes. |
| **Live Test Lab** | ✅ COMPLETED | Interactive UI executing all 6 scenarios against individual detectors or comparative benchmark. |
| **SQLite Transactional Storage** | ✅ COMPLETED | Full relational persistence for events, alerts, scenarios, and system metrics with batch provenance tags. |
| **Kernel Pre-Write Interception** | ⚠️ OUT OF SCOPE | User-space research prototype; kernel filesystem filter drivers are not implemented. |
| **Host Process Termination** | ⚠️ OUT OF SCOPE | By design, host OS processes (`SIGKILL`) are not terminated for sandbox safety. |

---

## 3. Verified, Unverified, and Failed Checks

1. **Database-to-CSV Provenance (RECONSTRUCTED & SUPPORTED BY ARTIFACTS):**
   - The original academic benchmark dataset consisting of **180 trials**, **1,691 events**, and **60 alerts** was executed during the benchmark epoch (`2026-11-02 12:58:28` to `13:01:08`) and frozen in `exports/trials.csv` and `RAW_EXPERIMENT_DATA.csv`.
   - The current SQLite database contains **77 scenario trials** generated during subsequent operational testing and UI verification (`2026-11-02 16:13:24` to `16:41:26`).
   - The distinct historical extracted database snapshot (`backup_state_extracted/canary_sentinel.db`, 76 scenarios, unmigrated schema) is clearly differentiated from the preserved 77-trial operational database (`canary_sentinel.db`, migrated schema with `batch_id`).
   - The lack of scenario ID overlap is explained by the database reset performed prior to the second test suite. Both datasets are genuine, uncorrupted, and preserved.
2. **Mathematical Metrics & Statistical Consistency (VERIFIED):**
   - Hybrid achieved 100.0% Precision (10 TP, 0 FP) and 0.0% False Positive Rate in tested trials. The false positive reduction is statistically significant (Fisher's exact test $p = 0.00102966$).
   - Baseline achieved 100.0% Recall (20 TP, 0 FN) and 25.0% False Positive Rate.
   - On matched Scenario S5 attacks touching decoys, Hybrid ($26.10$ ms) and Baseline ($25.80$ ms) exhibit no statistically significant latency difference ($t = 0.1067, p = 0.9168$). Equivalence was not established.
   - Overall attack latency comparisons ($84.92$ ms vs $26.10$ ms) reflect scenario composition asymmetry (Baseline detected evasive S6 attacks, whereas Hybrid did not).
   - In Scenario S5 (Canary-Trapped Ransomware), Hybrid halted attacks in 26.1 ms, limiting damage to 0.10 files out of 11 targeted operations (99.09% user data prevented). In Scenario S6 (Canary-Blind Ransomware), decoys were avoided (0.0% prevented), resulting in an unweighted scenario-level mean of 49.55% (and a per-trial planned operations ratio mean of 45.42%).
3. **Sandbox Boundary Enforcement (VERIFIED):**
   - Path traversal attempts (`../../`), symlink escapes, and root traversals are strictly blocked with explicit `SandboxSecurityError` exceptions.

---

## 4. Remaining Limitations
- **Notification Latency Floor:** Due to user-space event delivery (`watchdog`), a minimum of 1-2 files are touched prior to signal dispatch.
- **Canary Avoidance Evasion:** Attackers who avoid decoy naming conventions bypass pure canary and hybrid detectors, necessitating Baseline volume heuristics for defense-in-depth.
- **Cooperative Containment Model:** Containment relies on synthetic loop evaluation (`is_blocked()`) rather than kernel-level driver blocking.
