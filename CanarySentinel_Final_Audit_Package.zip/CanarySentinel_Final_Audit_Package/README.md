# CanarySentinel — Complete Independent Research & Audit Package

**Generated On:** 2026-11-03 18:13:52  
**Classification:** Academic Research Prototype & Forensic Audit Dossier  

This archive contains the complete independent audit deliverables for **CanarySentinel**:

## Directory Structure:
- `01_Final_Audit_Report/`: Final Project Audit Report with feature matrix and reconciliation.
- `02_Database_Integrity/`: SQLite PRAGMA integrity check, table row counts, and schema verification.
- `03_Experiment_Provenance/`: Forensic reconstruction of the 180-trial benchmark vs 77-trial operational database.
- `04_Experimental_Results/`: All 180 trial-level records, metrics, and scenario breakdown tables.
- `05_Statistical_Analysis/`: Hypothesis tests (Welch's t, Mann-Whitney U, Fisher's Exact) and confidence intervals.
- `06_Test_Execution/`: Full execution log of 56 passing automated unit, integration, boundary, and security tests.
- `07_Detector_Evaluation/`: Comparative evaluation of Baseline, Canary-Only, and Hybrid detectors.
- `08_Sandbox_Safety/`: Verification of sandbox containment, path traversal defense, and non-destructive simulation.
- `09_Live_Test_Lab/`: Overview of the 6 interactive scenarios and local database records.
- `10_Research_Documentation/`: Updated research paper, B.Tech capstone thesis, and presentation content.
- `11_Project_Environment/`: System architecture, requirements, and deployment instructions.
- `12_Raw_Evidence/`: Actual SQLite database (`canary_sentinel.db`), benchmark CSVs, and cryptographic SHA-256 manifest.

Every claim is backed by reproducible records, passing automated tests, and verified evidence.
